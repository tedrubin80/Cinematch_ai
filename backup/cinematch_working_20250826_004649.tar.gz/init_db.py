#!/usr/bin/env python3
"""Initialize database with all tables"""

import os
import sys
sys.path.insert(0, '/var/www/cinematch')

from app import create_app
from models import *  # Import all models

def init_database():
    """Initialize the database with all tables"""
    app = create_app()
    
    with app.app_context():
        print("Creating database tables...")
        
        # Drop and recreate all tables (for development)
        db.drop_all()
        db.create_all()
        
        # Verify tables were created
        from sqlalchemy import inspect
        inspector = inspect(db.engine)
        tables = inspector.get_table_names()
        
        print(f"Successfully created tables: {', '.join(sorted(tables))}")
        
        # Create a default admin user if none exists
        admin_user = User.query.filter_by(is_admin=True).first()
        if not admin_user:
            admin_user = User(
                username='admin',
                email='admin@cinematch.local',
                is_admin=True,
                is_verified=True
            )
            admin_user.set_password('admin123!')  # Change this in production!
            db.session.add(admin_user)
            
            # Create free subscription for admin
            admin_subscription = UserSubscription(
                user_id=admin_user.id,
                tier='premium',  # Give admin premium access
                status='active'
            )
            db.session.add(admin_subscription)
            
            db.session.commit()
            print(f"Created admin user: {admin_user.username}")
        
        print("Database initialization complete!")

if __name__ == '__main__':
    init_database()