# stripe_webhooks.py - Stripe webhook handling for Cinematch

import os
import stripe
import logging
from datetime import datetime
from flask import Blueprint, request, jsonify, current_app
from models import db, SubscriptionEvent
from subscription_system import SubscriptionManager, validate_stripe_signature

logger = logging.getLogger(__name__)

# Configure Stripe
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY')

# Create webhook blueprint
webhooks_bp = Blueprint('webhooks', __name__, url_prefix='/webhooks')

class WebhookProcessor:
    """Process Stripe webhook events"""
    
    @staticmethod
    def log_webhook_event(event_id, event_type, event_data, processing_result=None, error=None):
        """Log webhook events for tracking"""
        try:
            webhook_event = SubscriptionEvent(
                stripe_event_id=event_id,
                event_type=event_type,
                event_data=event_data,
                processed=processing_result is not None,
                processing_error=str(error) if error else None,
                processed_at=datetime.utcnow() if processing_result is not None else None
            )
            db.session.add(webhook_event)
            db.session.commit()
        except Exception as e:
            logger.error(f"Failed to log webhook event: {e}")
    
    @staticmethod
    def process_subscription_created(event_data):
        """Process subscription.created webhook"""
        try:
            subscription_data = event_data['data']['object']
            result = SubscriptionManager.handle_subscription_created(subscription_data)
            
            if result:
                logger.info(f"Successfully processed subscription.created: {subscription_data['id']}")
                return {'status': 'success', 'message': 'Subscription created successfully'}
            else:
                logger.error(f"Failed to process subscription.created: {subscription_data['id']}")
                return {'status': 'error', 'message': 'Failed to process subscription creation'}
                
        except Exception as e:
            logger.error(f"Error processing subscription.created: {e}")
            return {'status': 'error', 'message': str(e)}
    
    @staticmethod
    def process_subscription_updated(event_data):
        """Process subscription.updated webhook"""
        try:
            subscription_data = event_data['data']['object']
            result = SubscriptionManager.handle_subscription_updated(subscription_data)
            
            if result:
                logger.info(f"Successfully processed subscription.updated: {subscription_data['id']}")
                return {'status': 'success', 'message': 'Subscription updated successfully'}
            else:
                logger.error(f"Failed to process subscription.updated: {subscription_data['id']}")
                return {'status': 'error', 'message': 'Failed to process subscription update'}
                
        except Exception as e:
            logger.error(f"Error processing subscription.updated: {e}")
            return {'status': 'error', 'message': str(e)}
    
    @staticmethod
    def process_subscription_deleted(event_data):
        """Process subscription.deleted webhook"""
        try:
            subscription_data = event_data['data']['object']
            result = SubscriptionManager.handle_subscription_deleted(subscription_data)
            
            if result:
                logger.info(f"Successfully processed subscription.deleted: {subscription_data['id']}")
                return {'status': 'success', 'message': 'Subscription cancelled successfully'}
            else:
                logger.error(f"Failed to process subscription.deleted: {subscription_data['id']}")
                return {'status': 'error', 'message': 'Failed to process subscription cancellation'}
                
        except Exception as e:
            logger.error(f"Error processing subscription.deleted: {e}")
            return {'status': 'error', 'message': str(e)}
    
    @staticmethod
    def process_invoice_payment_succeeded(event_data):
        """Process invoice.payment_succeeded webhook"""
        try:
            invoice_data = event_data['data']['object']
            subscription_id = invoice_data.get('subscription')
            
            if subscription_id:
                # Update subscription status to active
                from models import UserSubscription
                subscription = UserSubscription.query.filter_by(
                    stripe_subscription_id=subscription_id
                ).first()
                
                if subscription:
                    subscription.status = 'active'
                    db.session.commit()
                    
                    logger.info(f"Payment succeeded for subscription: {subscription_id}")
                    return {'status': 'success', 'message': 'Payment processed successfully'}
            
            return {'status': 'success', 'message': 'Invoice payment processed'}
            
        except Exception as e:
            logger.error(f"Error processing invoice.payment_succeeded: {e}")
            return {'status': 'error', 'message': str(e)}
    
    @staticmethod
    def process_invoice_payment_failed(event_data):
        """Process invoice.payment_failed webhook"""
        try:
            invoice_data = event_data['data']['object']
            result = SubscriptionManager.handle_invoice_payment_failed(invoice_data)
            
            if result:
                logger.warning(f"Payment failed for invoice: {invoice_data['id']}")
                return {'status': 'success', 'message': 'Payment failure processed'}
            else:
                logger.error(f"Failed to process payment failure: {invoice_data['id']}")
                return {'status': 'error', 'message': 'Failed to process payment failure'}
                
        except Exception as e:
            logger.error(f"Error processing invoice.payment_failed: {e}")
            return {'status': 'error', 'message': str(e)}
    
    @staticmethod
    def process_customer_subscription_trial_will_end(event_data):
        """Process customer.subscription.trial_will_end webhook"""
        try:
            subscription_data = event_data['data']['object']
            customer_id = subscription_data['customer']
            
            # Find user and send trial ending notification
            from models import UserSubscription
            subscription = UserSubscription.query.filter_by(
                stripe_customer_id=customer_id
            ).first()
            
            if subscription and subscription.user:
                # TODO: Send trial ending notification email
                logger.info(f"Trial ending for user: {subscription.user_id}")
                
                # You can implement email notification here
                # send_trial_ending_email(subscription.user)
                
                return {'status': 'success', 'message': 'Trial ending notification processed'}
            
            return {'status': 'success', 'message': 'No user found for trial ending notification'}
            
        except Exception as e:
            logger.error(f"Error processing trial_will_end: {e}")
            return {'status': 'error', 'message': str(e)}
    
    @staticmethod
    def process_checkout_session_completed(event_data):
        """Process checkout.session.completed webhook"""
        try:
            session_data = event_data['data']['object']
            
            if session_data['mode'] == 'subscription':
                customer_id = session_data['customer']
                subscription_id = session_data['subscription']
                
                # Update subscription with session info
                from models import UserSubscription
                subscription = UserSubscription.query.filter_by(
                    stripe_customer_id=customer_id
                ).first()
                
                if subscription:
                    subscription.stripe_subscription_id = subscription_id
                    db.session.commit()
                    
                    logger.info(f"Checkout completed for subscription: {subscription_id}")
                    return {'status': 'success', 'message': 'Checkout session processed'}
            
            return {'status': 'success', 'message': 'Checkout session completed'}
            
        except Exception as e:
            logger.error(f"Error processing checkout.session.completed: {e}")
            return {'status': 'error', 'message': str(e)}


# Webhook event handlers mapping
WEBHOOK_HANDLERS = {
    'subscription.created': WebhookProcessor.process_subscription_created,
    'subscription.updated': WebhookProcessor.process_subscription_updated,
    'subscription.deleted': WebhookProcessor.process_subscription_deleted,
    'invoice.payment_succeeded': WebhookProcessor.process_invoice_payment_succeeded,
    'invoice.payment_failed': WebhookProcessor.process_invoice_payment_failed,
    'customer.subscription.trial_will_end': WebhookProcessor.process_customer_subscription_trial_will_end,
    'checkout.session.completed': WebhookProcessor.process_checkout_session_completed,
}


@webhooks_bp.route('/stripe', methods=['POST'])
def stripe_webhook():
    """Main Stripe webhook endpoint"""
    payload = request.get_data()
    sig_header = request.headers.get('Stripe-Signature')
    endpoint_secret = os.environ.get('STRIPE_ENDPOINT_SECRET')
    
    if not endpoint_secret:
        logger.error("Stripe endpoint secret not configured")
        return jsonify({'error': 'Webhook secret not configured'}), 500
    
    try:
        # Verify webhook signature
        event = stripe.Webhook.construct_event(
            payload, sig_header, endpoint_secret
        )
    except ValueError:
        logger.error("Invalid payload in Stripe webhook")
        return jsonify({'error': 'Invalid payload'}), 400
    except stripe.error.SignatureVerificationError:
        logger.error("Invalid signature in Stripe webhook")
        return jsonify({'error': 'Invalid signature'}), 400
    
    # Get event details
    event_id = event['id']
    event_type = event['type']
    
    logger.info(f"Received Stripe webhook: {event_type} ({event_id})")
    
    # Check if event already processed
    existing_event = SubscriptionEvent.query.filter_by(
        stripe_event_id=event_id
    ).first()
    
    if existing_event and existing_event.processed:
        logger.info(f"Event {event_id} already processed")
        return jsonify({'status': 'already_processed'}), 200
    
    # Process the event
    processing_result = None
    error = None
    
    try:
        if event_type in WEBHOOK_HANDLERS:
            handler = WEBHOOK_HANDLERS[event_type]
            processing_result = handler(event)
            
            if processing_result['status'] == 'error':
                error = processing_result['message']
        else:
            logger.info(f"Unhandled webhook event type: {event_type}")
            processing_result = {'status': 'ignored', 'message': f'Event type {event_type} not handled'}
        
    except Exception as e:
        error = str(e)
        logger.error(f"Unexpected error processing webhook {event_id}: {e}")
        processing_result = {'status': 'error', 'message': str(e)}
    
    # Log the webhook event
    WebhookProcessor.log_webhook_event(
        event_id=event_id,
        event_type=event_type,
        event_data=event,
        processing_result=processing_result,
        error=error
    )
    
    # Return appropriate response
    if error:
        return jsonify({
            'status': 'error',
            'message': error,
            'event_id': event_id
        }), 500
    
    return jsonify({
        'status': 'success',
        'message': processing_result.get('message', 'Event processed successfully'),
        'event_id': event_id
    }), 200


@webhooks_bp.route('/stripe/test', methods=['POST'])
def test_webhook():
    """Test webhook endpoint for development"""
    if not current_app.debug:
        return jsonify({'error': 'Test endpoint only available in debug mode'}), 403
    
    event_type = request.json.get('type')
    event_data = request.json.get('data')
    
    if not event_type or not event_data:
        return jsonify({'error': 'Missing event_type or event_data'}), 400
    
    # Create a fake event for testing
    fake_event = {
        'id': f'test_{datetime.utcnow().strftime("%Y%m%d_%H%M%S")}',
        'type': event_type,
        'data': event_data
    }
    
    # Process the test event
    try:
        if event_type in WEBHOOK_HANDLERS:
            handler = WEBHOOK_HANDLERS[event_type]
            result = handler(fake_event)
            return jsonify(result), 200
        else:
            return jsonify({
                'status': 'ignored',
                'message': f'Event type {event_type} not handled'
            }), 200
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


# Admin endpoints for webhook management

@webhooks_bp.route('/admin/events', methods=['GET'])
def list_webhook_events():
    """List recent webhook events (admin only)"""
    # This should be protected with admin authentication in production
    from flask_login import current_user
    if not current_user.is_authenticated or not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    event_type = request.args.get('type')
    processed = request.args.get('processed')
    
    query = SubscriptionEvent.query
    
    if event_type:
        query = query.filter_by(event_type=event_type)
    
    if processed is not None:
        query = query.filter_by(processed=processed.lower() == 'true')
    
    events = query.order_by(SubscriptionEvent.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'events': [
            {
                'id': str(event.id),
                'stripe_event_id': event.stripe_event_id,
                'event_type': event.event_type,
                'processed': event.processed,
                'processing_error': event.processing_error,
                'created_at': event.created_at.isoformat(),
                'processed_at': event.processed_at.isoformat() if event.processed_at else None
            }
            for event in events.items
        ],
        'pagination': {
            'page': events.page,
            'pages': events.pages,
            'per_page': events.per_page,
            'total': events.total
        }
    })


@webhooks_bp.route('/admin/events/<event_id>/retry', methods=['POST'])
def retry_webhook_event(event_id):
    """Retry processing a failed webhook event (admin only)"""
    from flask_login import current_user
    if not current_user.is_authenticated or not current_user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    event = SubscriptionEvent.query.get_or_404(event_id)
    
    try:
        # Retry processing the event
        if event.event_type in WEBHOOK_HANDLERS:
            handler = WEBHOOK_HANDLERS[event.event_type]
            result = handler(event.event_data)
            
            # Update event record
            event.processed = result['status'] == 'success'
            event.processing_error = None if result['status'] == 'success' else result.get('message')
            event.processed_at = datetime.utcnow()
            db.session.commit()
            
            return jsonify({
                'status': 'success',
                'message': 'Event reprocessed successfully',
                'result': result
            })
        else:
            return jsonify({
                'status': 'error',
                'message': f'No handler for event type: {event.event_type}'
            }), 400
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


# Utility functions for webhook testing and management

def simulate_subscription_event(user_id, event_type, subscription_data=None):
    """Simulate a subscription event for testing purposes"""
    if not subscription_data:
        # Create default test subscription data
        subscription_data = {
            'id': f'sub_test_{datetime.utcnow().strftime("%Y%m%d%H%M%S")}',
            'customer': f'cus_test_{user_id}',
            'status': 'active',
            'current_period_start': int(datetime.utcnow().timestamp()),
            'current_period_end': int((datetime.utcnow() + timedelta(days=30)).timestamp()),
            'items': {
                'data': [{
                    'price': {
                        'id': 'price_test_basic_monthly'
                    }
                }]
            }
        }
    
    fake_event = {
        'id': f'evt_test_{datetime.utcnow().strftime("%Y%m%d%H%M%S")}',
        'type': event_type,
        'data': {
            'object': subscription_data
        }
    }
    
    if event_type in WEBHOOK_HANDLERS:
        handler = WEBHOOK_HANDLERS[event_type]
        return handler(fake_event)
    
    return {'status': 'error', 'message': f'No handler for event type: {event_type}'}


def get_webhook_statistics():
    """Get statistics about webhook processing"""
    from sqlalchemy import func
    
    # Total events by type
    events_by_type = db.session.query(
        SubscriptionEvent.event_type,
        func.count(SubscriptionEvent.id).label('count')
    ).group_by(SubscriptionEvent.event_type).all()
    
    # Processing success rate
    total_events = SubscriptionEvent.query.count()
    processed_events = SubscriptionEvent.query.filter_by(processed=True).count()
    success_rate = (processed_events / total_events * 100) if total_events > 0 else 0
    
    # Recent failed events
    failed_events = SubscriptionEvent.query.filter_by(processed=False).filter(
        SubscriptionEvent.processing_error.isnot(None)
    ).order_by(SubscriptionEvent.created_at.desc()).limit(5).all()
    
    return {
        'events_by_type': [
            {
                'event_type': event.event_type,
                'count': event.count
            }
            for event in events_by_type
        ],
        'total_events': total_events,
        'processed_events': processed_events,
        'success_rate': round(success_rate, 2),
        'recent_failures': [
            {
                'id': str(event.id),
                'event_type': event.event_type,
                'error': event.processing_error,
                'created_at': event.created_at.isoformat()
            }
            for event in failed_events
        ]
    }