# subscription_integration.py - Integration module for subscription system

"""
Integration module for Cinematch subscription and authentication system.
This module provides the main integration functions to add the new
authentication and subscription features to the existing application.
"""

import os
import logging
from flask import Flask
from flask_mail import Mail

# Import our new modules
from auth_enhanced import auth_enhanced_bp, AuthenticationManager
from subscription_system import SubscriptionManager
from stripe_webhooks import webhooks_bp
from rate_limiter import init_rate_limiter, rate_limiter

logger = logging.getLogger(__name__)

def integrate_subscription_system(app: Flask):
    """
    Integrate the complete subscription system with the Flask app.
    
    This function should be called in your main app.py create_app() function
    to add all the new subscription and authentication features.
    """
    
    # 1. Initialize Flask-Mail for email verification
    app.config.setdefault('MAIL_SERVER', os.environ.get('MAIL_SERVER', 'localhost'))
    app.config.setdefault('MAIL_PORT', int(os.environ.get('MAIL_PORT', 587)))
    app.config.setdefault('MAIL_USE_TLS', os.environ.get('MAIL_USE_TLS', 'True').lower() == 'true')
    app.config.setdefault('MAIL_USERNAME', os.environ.get('MAIL_USERNAME'))
    app.config.setdefault('MAIL_PASSWORD', os.environ.get('MAIL_PASSWORD'))
    app.config.setdefault('MAIL_DEFAULT_SENDER', os.environ.get('MAIL_DEFAULT_SENDER', 'noreply@cinematch.com'))
    
    mail = Mail(app)
    
    # 2. Initialize rate limiter with Redis
    try:
        import redis
        redis_client = redis.from_url(app.config.get('REDIS_URL', 'redis://localhost:6379/0'))
        init_rate_limiter(app, redis_client)
        logger.info("Rate limiter initialized successfully")
    except Exception as e:
        logger.warning(f"Failed to initialize rate limiter with Redis: {e}")
        init_rate_limiter(app, None)  # Fallback without Redis
    
    # 3. Register blueprints
    app.register_blueprint(auth_enhanced_bp)
    app.register_blueprint(webhooks_bp)
    
    # 4. Add Stripe configuration
    app.config.setdefault('STRIPE_PUBLISHABLE_KEY', os.environ.get('STRIPE_PUBLISHABLE_KEY'))
    app.config.setdefault('STRIPE_SECRET_KEY', os.environ.get('STRIPE_SECRET_KEY'))
    app.config.setdefault('STRIPE_ENDPOINT_SECRET', os.environ.get('STRIPE_ENDPOINT_SECRET'))
    
    # Price IDs for different subscription tiers
    app.config.setdefault('STRIPE_BASIC_MONTHLY_PRICE_ID', os.environ.get('STRIPE_BASIC_MONTHLY_PRICE_ID'))
    app.config.setdefault('STRIPE_PREMIUM_MONTHLY_PRICE_ID', os.environ.get('STRIPE_PREMIUM_MONTHLY_PRICE_ID'))
    app.config.setdefault('STRIPE_BASIC_YEARLY_PRICE_ID', os.environ.get('STRIPE_BASIC_YEARLY_PRICE_ID'))
    app.config.setdefault('STRIPE_PREMIUM_YEARLY_PRICE_ID', os.environ.get('STRIPE_PREMIUM_YEARLY_PRICE_ID'))
    
    # 5. Add template globals for subscription info
    @app.template_global()
    def get_subscription_tiers():
        """Template function to get subscription tier information"""
        return {
            'free': {
                'name': 'Free',
                'price': '$0',
                'queries_per_day': 10,
                'features': ['Basic movie recommendations', 'Single-agent analysis']
            },
            'basic': {
                'name': 'Basic',
                'price': '$9.99/month',
                'queries_per_day': 100,
                'features': [
                    'Enhanced movie recommendations',
                    'Dual-agent analysis', 
                    'PDF export',
                    'Email support'
                ]
            },
            'premium': {
                'name': 'Premium', 
                'price': '$19.99/month',
                'queries_per_day': 'Unlimited',
                'features': [
                    'All multi-agent features',
                    'Priority support',
                    'Advanced analysis tools',
                    'Multiple export formats',
                    'API access'
                ]
            }
        }
    
    @app.template_global()
    def get_user_usage_info(user):
        """Template function to get user's current usage information"""
        if not user or not user.is_authenticated:
            return None
        
        try:
            from rate_limiter import get_user_rate_limit_status
            return get_user_rate_limit_status(user)
        except Exception as e:
            logger.error(f"Error getting user usage info: {e}")
            return None
    
    # 6. Add CLI commands for subscription management
    @app.cli.command()
    def init_subscription_db():
        """Initialize subscription database tables"""
        from models import db
        try:
            # Import all models to ensure they're registered
            from models import (User, UserSubscription, UsageTracking, PaymentMethod, 
                               SubscriptionEvent, RateLimitLog, SecurityLog)
            
            print("Creating subscription system tables...")
            db.create_all()
            print("✅ Subscription database initialized successfully!")
            
            # Create default subscriptions for existing users
            users_without_subscriptions = db.session.query(User).outerjoin(UserSubscription).filter(
                UserSubscription.user_id.is_(None)
            ).all()
            
            for user in users_without_subscriptions:
                subscription = UserSubscription(
                    user_id=user.id,
                    tier='free',
                    status='active'
                )
                db.session.add(subscription)
            
            if users_without_subscriptions:
                db.session.commit()
                print(f"✅ Created free subscriptions for {len(users_without_subscriptions)} existing users")
                
        except Exception as e:
            print(f"❌ Error initializing subscription database: {e}")
            db.session.rollback()
    
    @app.cli.command()
    @app.cli.argument('user_id')
    @app.cli.argument('tier')
    def set_user_tier(user_id, tier):
        """Set a user's subscription tier (for testing/admin)"""
        from models import db, User, UserSubscription
        
        if tier not in ['free', 'basic', 'premium']:
            print(f"❌ Invalid tier: {tier}. Must be one of: free, basic, premium")
            return
        
        try:
            user = User.query.get(user_id)
            if not user:
                print(f"❌ User not found: {user_id}")
                return
            
            subscription = user.subscription
            if not subscription:
                subscription = UserSubscription(user_id=user.id)
                db.session.add(subscription)
            
            subscription.tier = tier
            subscription.status = 'active'
            db.session.commit()
            
            print(f"✅ Updated user {user.username} to {tier} tier")
            
        except Exception as e:
            print(f"❌ Error updating user tier: {e}")
            db.session.rollback()
    
    @app.cli.command()
    def subscription_stats():
        """Show subscription statistics"""
        from models import db, UserSubscription
        from sqlalchemy import func
        
        try:
            # Count users by tier
            tier_counts = db.session.query(
                UserSubscription.tier,
                func.count(UserSubscription.id).label('count')
            ).group_by(UserSubscription.tier).all()
            
            print("\n📊 Subscription Statistics:")
            print("-" * 30)
            total_users = 0
            for tier, count in tier_counts:
                print(f"{tier.capitalize():10}: {count:4d} users")
                total_users += count
            print("-" * 30)
            print(f"{'Total':10}: {total_users:4d} users")
            
            # Show recent usage
            from models import UsageTracking
            from datetime import date, timedelta
            
            today = date.today()
            week_ago = today - timedelta(days=7)
            
            recent_usage = db.session.query(
                func.sum(UsageTracking.query_count).label('total_queries'),
                func.count(func.distinct(UsageTracking.user_id)).label('active_users')
            ).filter(UsageTracking.query_date >= week_ago).first()
            
            print(f"\n📈 Last 7 Days:")
            print(f"Active users: {recent_usage.active_users or 0}")
            print(f"Total queries: {recent_usage.total_queries or 0}")
            
        except Exception as e:
            print(f"❌ Error getting subscription stats: {e}")
    
    # 7. Add error handlers for subscription-related errors
    @app.errorhandler(402)
    def handle_payment_required(e):
        """Handle subscription upgrade required errors"""
        return render_template('errors/payment_required.html'), 402
    
    @app.errorhandler(429)
    def handle_rate_limit_exceeded(e):
        """Handle rate limit exceeded errors"""
        return render_template('errors/rate_limit_exceeded.html'), 429
    
    # 8. Add before_request handler for subscription checks
    @app.before_request
    def check_subscription_status():
        """Check if user's subscription is still valid"""
        from flask import request, current_user
        from datetime import datetime
        
        # Skip for static files, webhooks, and auth endpoints
        if (request.endpoint and 
            (request.endpoint.startswith('static') or
             request.endpoint.startswith('webhooks') or
             request.endpoint.startswith('auth_enhanced'))):
            return
        
        if current_user.is_authenticated and hasattr(current_user, 'subscription'):
            subscription = current_user.subscription
            if subscription and subscription.status == 'past_due':
                # User's payment is past due - you might want to show a warning
                pass
            elif subscription and subscription.current_period_end:
                if datetime.utcnow() > subscription.current_period_end and subscription.tier != 'free':
                    # Subscription expired, revert to free
                    subscription.tier = 'free'
                    subscription.status = 'active'
                    from models import db
                    db.session.commit()
    
    logger.info("Subscription system integrated successfully")
    return app


def create_subscription_routes(app: Flask):
    """
    Create subscription management routes.
    These routes handle subscription upgrades, downgrades, and management.
    """
    
    @app.route('/subscription')
    def subscription_page():
        """Subscription management page"""
        from flask_login import login_required, current_user
        from flask import render_template
        
        @login_required
        def _subscription_page():
            user_subscription = current_user.subscription
            usage_info = get_user_usage_info(current_user)
            subscription_tiers = get_subscription_tiers()
            
            return render_template('subscription/manage.html',
                                 subscription=user_subscription,
                                 usage_info=usage_info,
                                 tiers=subscription_tiers)
        
        return _subscription_page()
    
    @app.route('/subscription/upgrade/<tier>')
    def upgrade_subscription(tier):
        """Start subscription upgrade process"""
        from flask_login import login_required, current_user
        from flask import redirect, url_for, flash, request
        
        @login_required
        def _upgrade_subscription():
            if tier not in ['basic', 'premium']:
                flash('Invalid subscription tier.', 'error')
                return redirect(url_for('subscription_page'))
            
            try:
                # Determine price ID based on tier
                price_id_map = {
                    'basic': app.config.get('STRIPE_BASIC_MONTHLY_PRICE_ID'),
                    'premium': app.config.get('STRIPE_PREMIUM_MONTHLY_PRICE_ID')
                }
                
                price_id = price_id_map.get(tier)
                if not price_id:
                    flash('Subscription pricing not configured.', 'error')
                    return redirect(url_for('subscription_page'))
                
                # Create Stripe checkout session
                success_url = url_for('subscription_success', _external=True)
                cancel_url = url_for('subscription_page', _external=True)
                
                checkout_session = SubscriptionManager.create_checkout_session(
                    current_user, price_id, success_url, cancel_url
                )
                
                return redirect(checkout_session.url, code=303)
                
            except Exception as e:
                logger.error(f"Error creating checkout session: {e}")
                flash('Unable to process subscription upgrade. Please try again.', 'error')
                return redirect(url_for('subscription_page'))
        
        return _upgrade_subscription()
    
    @app.route('/subscription/success')
    def subscription_success():
        """Subscription success page"""
        from flask_login import login_required, current_user
        from flask import render_template, flash
        
        @login_required
        def _subscription_success():
            flash('Subscription activated successfully! Welcome to your new plan.', 'success')
            return render_template('subscription/success.html')
        
        return _subscription_success()
    
    @app.route('/subscription/portal')
    def subscription_portal():
        """Redirect to Stripe customer portal"""
        from flask_login import login_required, current_user
        from flask import redirect, url_for, flash
        
        @login_required
        def _subscription_portal():
            try:
                return_url = url_for('subscription_page', _external=True)
                portal_session = SubscriptionManager.create_portal_session(
                    current_user, return_url
                )
                
                return redirect(portal_session.url, code=303)
                
            except Exception as e:
                logger.error(f"Error creating portal session: {e}")
                flash('Unable to access billing portal. Please try again.', 'error')
                return redirect(url_for('subscription_page'))
        
        return _subscription_portal()


# Usage tracking utilities

def track_api_usage(user, endpoint='general', query_type='basic', agents=None, tokens=0, cost=0.0):
    """
    Utility function to track API usage.
    Call this after successful API requests to track usage.
    """
    if user and user.is_authenticated:
        try:
            from models import UsageTracking
            return UsageTracking.increment_usage(
                user_id=user.id,
                query_type=query_type,
                agents=agents or [],
                tokens=tokens,
                cost=cost
            )
        except Exception as e:
            logger.error(f"Error tracking usage: {e}")
    return None


def check_feature_access(user, feature_name):
    """
    Check if user has access to a specific feature.
    
    Args:
        user: User instance
        feature_name: Name of the feature to check
        
    Returns:
        bool: True if user has access, False otherwise
    """
    if not user or not user.is_authenticated:
        return False
    
    if hasattr(user, 'subscription') and user.subscription:
        features = user.subscription.get_tier_features()
        user_features = features.get('features', [])
        return feature_name in user_features or 'all' in user_features
    
    return False


# Environment setup function

def setup_environment_variables():
    """
    Setup required environment variables with defaults for development.
    This should be called before creating the Flask app.
    """
    
    env_vars = {
        # Stripe configuration
        'STRIPE_PUBLISHABLE_KEY': 'pk_test_your_publishable_key_here',
        'STRIPE_SECRET_KEY': 'sk_test_your_secret_key_here', 
        'STRIPE_ENDPOINT_SECRET': 'whsec_your_endpoint_secret_here',
        'STRIPE_BASIC_MONTHLY_PRICE_ID': 'price_basic_monthly_id',
        'STRIPE_PREMIUM_MONTHLY_PRICE_ID': 'price_premium_monthly_id',
        'STRIPE_BASIC_YEARLY_PRICE_ID': 'price_basic_yearly_id',
        'STRIPE_PREMIUM_YEARLY_PRICE_ID': 'price_premium_yearly_id',
        
        # Email configuration
        'MAIL_SERVER': 'localhost',
        'MAIL_PORT': '587',
        'MAIL_USE_TLS': 'True',
        'MAIL_USERNAME': '',
        'MAIL_PASSWORD': '',
        'MAIL_DEFAULT_SENDER': 'noreply@cinematch.local',
        
        # Security
        'SECRET_KEY': os.urandom(32).hex(),
    }
    
    for key, default_value in env_vars.items():
        if not os.environ.get(key):
            os.environ[key] = default_value
            if key.startswith('STRIPE') or 'PASSWORD' in key or 'SECRET' in key:
                print(f"⚠️  Set {key} to default/placeholder value - update for production!")
            else:
                print(f"ℹ️  Set {key} to default value: {default_value}")


# Example integration in main app.py:
"""
# Add this to your main app.py create_app() function:

from subscription_integration import integrate_subscription_system, create_subscription_routes

def create_app():
    app = Flask(__name__)
    
    # ... existing app configuration ...
    
    # Initialize subscription system
    integrate_subscription_system(app)
    
    # Add subscription routes  
    create_subscription_routes(app)
    
    return app
"""