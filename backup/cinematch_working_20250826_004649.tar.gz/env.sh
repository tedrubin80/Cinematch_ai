# .env.example - Cinematch Environment Variables Template
# Copy this to .env and fill in your actual values

# Flask Configuration
SECRET_KEY=your-secret-key-here-use-python-secrets-token-hex-32
FLASK_ENV=production
FLASK_DEBUG=False

# Database Configuration (DigitalOcean Managed PostgreSQL)
DATABASE_URL=postgresql://username:password@host:port/database?sslmode=require

# Encryption Key (Generate with: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")
ENCRYPTION_KEY=your-encryption-key-here

# Admin Configuration
ADMIN_SECRET_PATH=change-this-to-random-string-like-admin-x7j9k2m4
ALLOW_REGISTRATION=False

# DigitalOcean Spaces (S3-compatible storage)
DO_SPACES_KEY=your-digitalocean-spaces-access-key
DO_SPACES_SECRET=your-digitalocean-spaces-secret-key
DO_SPACES_REGION=nyc3
DO_SPACES_ENDPOINT=https://nyc3.digitaloceanspaces.com
DO_SPACES_BUCKET=your-bucket-name

# API Keys (Required for AI functionality)
OPENAI_API_KEY=sk-your-openai-api-key
ANTHROPIC_API_KEY=sk-ant-your-anthropic-api-key
GOOGLE_API_KEY=AIza-your-google-api-key

# Redis Configuration (for caching and sessions)
REDIS_URL=redis://localhost:6379/0

# Email Configuration (Optional - for notifications)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-specific-password

# CORS Configuration
CORS_ORIGINS=https://yourdomain.com,https://www.yourdomain.com

# Rate Limiting Storage (uses database if not specified)
RATELIMIT_STORAGE_URL=postgresql://same-as-database-url

# Session Configuration
SESSION_TYPE=filesystem
PERMANENT_SESSION_LIFETIME=86400

# Logging
LOG_LEVEL=INFO
LOG_FILE=logs/cinematch.log

# Security Settings
FORCE_HTTPS=True
SESSION_COOKIE_SECURE=True
SESSION_COOKIE_HTTPONLY=True
SESSION_COOKIE_SAMESITE=Lax

# Content Delivery
CDN_URL=https://yourdomain.com
STATIC_URL=/static

# Feature Flags
ENABLE_CHAT_LOGS=False
ENABLE_DEMO_MODE=False
MAINTENANCE_MODE=False

# Backup Configuration
BACKUP_RETENTION_DAYS=30
BACKUP_ENCRYPTION_KEY=your-backup-encryption-key

# Domain Configuration
DOMAIN_NAME=yourdomain.com

# Additional Security
MAX_LOGIN_ATTEMPTS=5
LOCKOUT_DURATION=3600
PASSWORD_MIN_LENGTH=8
PASSWORD_REQUIRE_SPECIAL=True

# AI Model Configuration
DEFAULT_TEMPERATURE=0.7
DEFAULT_TOP_K=20
MAX_TOKENS=500

# Content Moderation
ENABLE_CONTENT_FILTERING=True
PROFANITY_FILTER_LEVEL=medium
BLOCK_SUSPICIOUS_PATTERNS=True

# Analytics (Optional)
GOOGLE_ANALYTICS_ID=UA-XXXXXXXXX-X
MIXPANEL_TOKEN=your-mixpanel-token

# Performance
CACHE_DEFAULT_TIMEOUT=300
CACHE_THRESHOLD=1000
DATABASE_POOL_SIZE=10
DATABASE_POOL_RECYCLE=3600

# Development/Testing (set to False in production)
TESTING=False
DEBUG_TB_ENABLED=False
EXPLAIN_TEMPLATE_LOADING=False