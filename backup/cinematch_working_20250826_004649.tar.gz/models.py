# models.py - Database models for Cinematch

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import uuid
from sqlalchemy.dialects.postgresql import UUID, JSONB
from pgvector.sqlalchemy import Vector

db = SQLAlchemy()

# User model with authentication
class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255))
    is_admin = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    is_verified = db.Column(db.Boolean, default=False)
    verification_token = db.Column(db.String(100), unique=True)
    verification_token_expiry = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    failed_login_attempts = db.Column(db.Integer, default=0)
    account_locked_until = db.Column(db.DateTime)
    
    # Password reset fields
    reset_token = db.Column(db.String(100), unique=True)
    reset_token_expiry = db.Column(db.DateTime)
    
    # Two-factor auth
    two_factor_secret = db.Column(db.String(32))
    two_factor_enabled = db.Column(db.Boolean, default=False)
    
    # Relationships
    subscription = db.relationship('UserSubscription', backref='user', uselist=False, cascade='all, delete-orphan')
    usage_records = db.relationship('UsageTracking', backref='user', cascade='all, delete-orphan')
    payment_methods = db.relationship('PaymentMethod', backref='user', cascade='all, delete-orphan')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_id(self):
        return str(self.id)
    
    @property
    def current_tier(self):
        if self.subscription and self.subscription.is_active:
            return self.subscription.tier
        return 'free'
    
    @property
    def is_account_locked(self):
        if self.account_locked_until:
            return datetime.utcnow() < self.account_locked_until
        return False
    
    def lock_account(self, duration_minutes=30):
        self.account_locked_until = datetime.utcnow() + timedelta(minutes=duration_minutes)
        db.session.commit()
    
    def unlock_account(self):
        self.failed_login_attempts = 0
        self.account_locked_until = None
        db.session.commit()
    
    def increment_failed_login(self):
        self.failed_login_attempts += 1
        if self.failed_login_attempts >= 5:
            self.lock_account()
        db.session.commit()
    
    def get_daily_usage(self, date=None):
        if not date:
            date = datetime.utcnow().date()
        usage = UsageTracking.query.filter_by(
            user_id=self.id,
            query_date=date
        ).first()
        return usage.query_count if usage else 0
    
    def get_rate_limit(self):
        tier_limits = {
            'free': 10,
            'basic': 100,
            'premium': float('inf')
        }
        return tier_limits.get(self.current_tier, 10)

# Session tracking
class Session(db.Model):
    __tablename__ = 'sessions'
    
    id = db.Column(db.String(64), primary_key=True)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))
    age_verified = db.Column(db.Boolean, default=False)
    age_verified_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_activity = db.Column(db.DateTime, default=datetime.utcnow)
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(255))

# API Keys management
class APIKey(db.Model):
    __tablename__ = 'api_keys'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    service = db.Column(db.String(50), nullable=False)  # 'openai', 'anthropic', 'google'
    encrypted_key = db.Column(db.Text, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    updated_by = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))

# Content filtering keywords
class ContentKeyword(db.Model):
    __tablename__ = 'content_keywords'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    category = db.Column(db.String(50), nullable=False)  # 'mature', 'restricted', 'family'
    keyword = db.Column(db.String(100), nullable=False)
    weight = db.Column(db.Float, default=1.0)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))

# Movie documents for vector search
class MovieDocument(db.Model):
    __tablename__ = 'movie_documents'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    source_type = db.Column(db.String(50))  # 'web', 's3', 'manual'
    source_id = db.Column(db.String(500))
    title = db.Column(db.String(500), nullable=False)
    content = db.Column(db.Text)
    doc_metadata = db.Column(JSONB)
    embedding = db.Column(Vector(1536))  # OpenAI embeddings dimension
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# Chat logs
class ChatLog(db.Model):
    __tablename__ = 'chat_logs'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id = db.Column(db.String(64), db.ForeignKey('sessions.id'))
    user_input = db.Column(db.Text)
    bot_response = db.Column(db.Text)
    llm_used = db.Column(db.String(50))  # 'claude', 'gemini'
    content_rating = db.Column(db.String(20))
    response_time_ms = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Safety logs
class SafetyLog(db.Model):
    __tablename__ = 'safety_logs'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id = db.Column(db.String(64), db.ForeignKey('sessions.id'))
    input_hash = db.Column(db.String(64))  # SHA256 hash of input
    safe = db.Column(db.Boolean)
    reason = db.Column(db.String(255))
    severity = db.Column(db.String(20))  # 'low', 'medium', 'high', 'critical'
    action = db.Column(db.String(20))  # 'allow', 'warn', 'block', 'ban'
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

# Admin audit logs
class AdminAuditLog(db.Model):
    __tablename__ = 'admin_audit_logs'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))
    action = db.Column(db.String(255), nullable=False)
    details = db.Column(JSONB)
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(255))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='audit_logs')

# Custom routes
class CustomRoute(db.Model):
    __tablename__ = 'custom_routes'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = db.Column(db.String(100), unique=True)
    path = db.Column(db.String(255), unique=True)
    method = db.Column(db.String(10))  # GET, POST, etc.
    description = db.Column(db.Text)
    action_type = db.Column(db.String(50))  # 'llm_query', 'database_query', 'webhook'
    configuration = db.Column(JSONB)  # JSON configuration
    requires_auth = db.Column(db.Boolean, default=True)
    rate_limit = db.Column(db.Integer, default=60)  # requests per minute
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))

# User preferences
class UserPreference(db.Model):
    __tablename__ = 'user_preferences'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'), unique=True)
    theme = db.Column(db.String(50), default='dark_modern')
    custom_theme = db.Column(JSONB)  # Custom theme colors
    language = db.Column(db.String(10), default='en')
    notifications_enabled = db.Column(db.Boolean, default=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# S3 Knowledge Base
class S3KnowledgeBase(db.Model):
    __tablename__ = 's3_knowledge_base'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    s3_key = db.Column(db.String(500), unique=True, nullable=False)
    filename = db.Column(db.String(255))
    content_type = db.Column(db.String(100))
    size = db.Column(db.BigInteger)
    indexed = db.Column(db.Boolean, default=False)
    last_indexed = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Indexed websites
class IndexedSite(db.Model):
    __tablename__ = 'indexed_sites'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    url = db.Column(db.String(500), unique=True, nullable=False)
    domain = db.Column(db.String(255), nullable=False)
    title = db.Column(db.String(500))
    content = db.Column(db.Text)
    site_metadata = db.Column(JSONB)
    last_indexed = db.Column(db.DateTime)
    index_frequency = db.Column(db.Integer, default=7)  # days
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Routing configuration
class RoutingConfiguration(db.Model):
    __tablename__ = 'routing_configurations'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    use_claude_threshold = db.Column(db.Float, default=0.7)
    use_gemini_threshold = db.Column(db.Float, default=0.3)
    content_length_threshold = db.Column(db.Integer, default=500)
    enable_cross_validation = db.Column(db.Boolean, default=False)
    cross_validation_keywords = db.Column(JSONB)  # List of keywords
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    updated_by = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))

# Content routing rules
class ContentRoutingRule(db.Model):
    __tablename__ = 'content_routing_rules'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rule_name = db.Column(db.String(100), nullable=False)
    condition_type = db.Column(db.String(50))  # 'keyword', 'regex', 'sentiment'
    condition_value = db.Column(db.Text)
    target_llm = db.Column(db.String(50))  # 'claude', 'gemini', 'both'
    priority = db.Column(db.Integer, default=1)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))

# Security logs
class SecurityLog(db.Model):
    __tablename__ = 'security_logs'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_type = db.Column(db.String(50))  # 'failed_login', 'blocked_ip', 'rate_limit'
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(255))
    details = db.Column(JSONB)
    severity = db.Column(db.String(20))  # 'info', 'warning', 'critical'
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)


# ==================== SUBSCRIPTION SYSTEM MODELS ====================

class UserSubscription(db.Model):
    """User subscription model with Stripe integration"""
    __tablename__ = 'user_subscriptions'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'), unique=True, nullable=False)
    tier = db.Column(db.String(20), nullable=False, default='free')  # free, basic, premium
    
    # Stripe integration fields
    stripe_customer_id = db.Column(db.String(100), unique=True)
    stripe_subscription_id = db.Column(db.String(100), unique=True)
    stripe_price_id = db.Column(db.String(100))
    
    # Subscription status
    status = db.Column(db.String(20), default='active')  # active, cancelled, past_due, incomplete
    current_period_start = db.Column(db.DateTime)
    current_period_end = db.Column(db.DateTime)
    cancel_at_period_end = db.Column(db.Boolean, default=False)
    cancelled_at = db.Column(db.DateTime)
    
    # Billing info
    trial_start = db.Column(db.DateTime)
    trial_end = db.Column(db.DateTime)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Indexes for performance
    __table_args__ = (
        db.Index('idx_user_subscription_user_id', 'user_id'),
        db.Index('idx_user_subscription_stripe_customer', 'stripe_customer_id'),
        db.Index('idx_user_subscription_status', 'status'),
    )
    
    @property
    def is_active(self):
        return self.status in ['active', 'trialing']
    
    @property
    def is_trial(self):
        if self.trial_end:
            return datetime.utcnow() < self.trial_end
        return False
    
    @property
    def days_until_renewal(self):
        if self.current_period_end:
            delta = self.current_period_end - datetime.utcnow()
            return max(0, delta.days)
        return 0
    
    def get_tier_features(self):
        features = {
            'free': {
                'queries_per_day': 10,
                'agents': ['basic'],
                'features': ['basic_recommendations'],
                'export_formats': [],
                'support': 'community'
            },
            'basic': {
                'queries_per_day': 100,
                'agents': ['basic', 'advanced'],
                'features': ['basic_recommendations', 'dual_agent_analysis', 'enhanced_recommendations'],
                'export_formats': ['pdf'],
                'support': 'email'
            },
            'premium': {
                'queries_per_day': float('inf'),
                'agents': ['basic', 'advanced', 'multi_agent'],
                'features': ['all'],
                'export_formats': ['pdf', 'json', 'csv'],
                'support': 'priority'
            }
        }
        return features.get(self.tier, features['free'])


class UsageTracking(db.Model):
    """Track daily usage per user for rate limiting"""
    __tablename__ = 'usage_tracking'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'), nullable=False)
    query_date = db.Column(db.Date, nullable=False, default=datetime.utcnow().date())
    query_count = db.Column(db.Integer, default=0)
    query_type = db.Column(db.String(50), default='basic')  # basic, advanced, multi_agent
    agents_used = db.Column(JSONB, default=list)  # List of AI agents used
    
    # Usage details
    total_tokens = db.Column(db.Integer, default=0)
    total_cost = db.Column(db.Numeric(10, 4), default=0.0)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Unique constraint to prevent duplicate records
    __table_args__ = (
        db.UniqueConstraint('user_id', 'query_date', name='unique_user_date'),
        db.Index('idx_usage_tracking_user_date', 'user_id', 'query_date'),
        db.Index('idx_usage_tracking_date', 'query_date'),
    )
    
    @classmethod
    def increment_usage(cls, user_id, query_type='basic', agents=None, tokens=0, cost=0.0):
        """Increment usage for a user on current date"""
        today = datetime.utcnow().date()
        usage = cls.query.filter_by(user_id=user_id, query_date=today).first()
        
        if not usage:
            usage = cls(
                user_id=user_id,
                query_date=today,
                query_type=query_type,
                agents_used=agents or []
            )
            db.session.add(usage)
        
        usage.query_count += 1
        usage.total_tokens += tokens
        usage.total_cost += cost
        
        if agents:
            current_agents = set(usage.agents_used or [])
            current_agents.update(agents)
            usage.agents_used = list(current_agents)
        
        db.session.commit()
        return usage
    
    @classmethod
    def get_monthly_usage(cls, user_id, year=None, month=None):
        """Get monthly usage statistics"""
        if not year:
            year = datetime.utcnow().year
        if not month:
            month = datetime.utcnow().month
        
        from sqlalchemy import func
        return db.session.query(
            func.sum(cls.query_count).label('total_queries'),
            func.sum(cls.total_tokens).label('total_tokens'),
            func.sum(cls.total_cost).label('total_cost')
        ).filter(
            cls.user_id == user_id,
            func.extract('year', cls.query_date) == year,
            func.extract('month', cls.query_date) == month
        ).first()


class PaymentMethod(db.Model):
    """Store user payment methods (Stripe)"""
    __tablename__ = 'payment_methods'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'), nullable=False)
    stripe_payment_method_id = db.Column(db.String(100), unique=True, nullable=False)
    
    # Card details (for display only)
    card_brand = db.Column(db.String(20))
    card_last4 = db.Column(db.String(4))
    card_exp_month = db.Column(db.Integer)
    card_exp_year = db.Column(db.Integer)
    
    is_default = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = (
        db.Index('idx_payment_method_user_id', 'user_id'),
    )


class SubscriptionEvent(db.Model):
    """Track subscription events from Stripe webhooks"""
    __tablename__ = 'subscription_events'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))
    stripe_event_id = db.Column(db.String(100), unique=True, nullable=False)
    event_type = db.Column(db.String(50), nullable=False)
    
    # Event data
    event_data = db.Column(JSONB)
    processed = db.Column(db.Boolean, default=False)
    processing_error = db.Column(db.Text)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    processed_at = db.Column(db.DateTime)
    
    __table_args__ = (
        db.Index('idx_subscription_event_type', 'event_type'),
        db.Index('idx_subscription_event_processed', 'processed'),
    )


class RateLimitLog(db.Model):
    """Log rate limit hits for analysis"""
    __tablename__ = 'rate_limit_logs'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))
    ip_address = db.Column(db.String(45))
    endpoint = db.Column(db.String(200))
    user_tier = db.Column(db.String(20))
    rate_limit = db.Column(db.Integer)
    current_usage = db.Column(db.Integer)
    
    # Request details
    user_agent = db.Column(db.String(255))
    referer = db.Column(db.String(255))
    
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        db.Index('idx_rate_limit_log_user_timestamp', 'user_id', 'timestamp'),
        db.Index('idx_rate_limit_log_timestamp', 'timestamp'),
    )


# ==================== SAFETY AND AGE VERIFICATION MODELS ====================

class AgeVerification(db.Model):
    """Track age verification attempts and status"""
    __tablename__ = 'age_verifications'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id = db.Column(db.String(255), unique=True, nullable=False)
    ip_address = db.Column(db.String(45))
    age = db.Column(db.Integer)
    is_verified = db.Column(db.Boolean, default=False)
    verification_method = db.Column(db.String(50), default='self_declaration')
    
    # Timestamps
    verified_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime)
    
    # Security fields
    user_agent = db.Column(db.Text)
    verification_token = db.Column(db.String(128))
    attempts = db.Column(db.Integer, default=0)
    
    # Geographic compliance
    country_code = db.Column(db.String(2))
    region = db.Column(db.String(100))
    
    __table_args__ = (
        db.Index('idx_age_verification_session', 'session_id'),
        db.Index('idx_age_verification_ip', 'ip_address'),
        db.Index('idx_age_verification_verified_at', 'verified_at'),
    )
    
    @property
    def is_valid(self):
        """Check if verification is still valid"""
        if not self.is_verified:
            return False
        if self.expires_at and datetime.utcnow() > self.expires_at:
            return False
        return True
    
    def extend_verification(self, hours=24):
        """Extend verification for additional hours"""
        self.expires_at = datetime.utcnow() + timedelta(hours=hours)
        db.session.commit()


class SafetyViolation(db.Model):
    """Track safety policy violations"""
    __tablename__ = 'safety_violations'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id = db.Column(db.String(255))
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))
    
    # Violation details
    violation_type = db.Column(db.String(100), nullable=False)
    severity = db.Column(db.String(20), default='medium')  # low, medium, high, critical
    category = db.Column(db.String(50))  # pii, profanity, harmful, inappropriate
    
    # Content information
    content_sample = db.Column(db.Text)  # Truncated sample for review
    content_hash = db.Column(db.String(64))  # SHA256 hash of full content
    input_type = db.Column(db.String(20), default='text')  # text, image, file
    
    # Context
    endpoint = db.Column(db.String(200))
    message_id = db.Column(db.String(100))
    conversation_id = db.Column(db.String(100))
    
    # Detection details
    detection_method = db.Column(db.String(50))  # regex, ml_model, keyword, manual
    confidence_score = db.Column(db.Float)
    detector_version = db.Column(db.String(20))
    
    # Action taken
    action_taken = db.Column(db.String(100))  # blocked, warned, logged, escalated
    auto_resolved = db.Column(db.Boolean, default=False)
    manual_review_required = db.Column(db.Boolean, default=False)
    
    # Network info
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.Text)
    
    # Timestamps
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    resolved_at = db.Column(db.DateTime)
    
    __table_args__ = (
        db.Index('idx_safety_violation_session', 'session_id'),
        db.Index('idx_safety_violation_user', 'user_id'),
        db.Index('idx_safety_violation_type', 'violation_type'),
        db.Index('idx_safety_violation_severity', 'severity'),
        db.Index('idx_safety_violation_timestamp', 'timestamp'),
        db.Index('idx_safety_violation_unresolved', 'manual_review_required'),
    )
    
    def escalate(self):
        """Escalate violation for manual review"""
        self.manual_review_required = True
        self.severity = 'high' if self.severity != 'critical' else 'critical'
        db.session.commit()
    
    def resolve(self, action_taken=None):
        """Mark violation as resolved"""
        self.auto_resolved = True
        self.resolved_at = datetime.utcnow()
        if action_taken:
            self.action_taken = action_taken
        db.session.commit()


class ParameterUsage(db.Model):
    """Track AI parameter usage for optimization"""
    __tablename__ = 'parameter_usage'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id = db.Column(db.String(255))
    user_id = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))
    
    # Parameter values
    temperature = db.Column(db.Numeric(3,2))  # 0.00-2.00
    top_k = db.Column(db.Integer)  # 1-100
    max_tokens = db.Column(db.Integer)
    presence_penalty = db.Column(db.Numeric(3,2))
    frequency_penalty = db.Column(db.Numeric(3,2))
    
    # Preset information
    preset_used = db.Column(db.String(50))  # factual, balanced, creative, custom
    preset_version = db.Column(db.String(20))
    
    # Usage context
    query_type = db.Column(db.String(50))
    message_count = db.Column(db.Integer, default=1)
    conversation_length = db.Column(db.Integer)
    
    # Performance metrics
    response_time = db.Column(db.Integer)  # milliseconds
    token_count = db.Column(db.Integer)
    cost = db.Column(db.Numeric(10,4))
    
    # Quality indicators
    user_rating = db.Column(db.Integer)  # 1-5 stars
    user_feedback = db.Column(db.String(500))
    
    # Timestamps
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        db.Index('idx_parameter_usage_session', 'session_id'),
        db.Index('idx_parameter_usage_user', 'user_id'),
        db.Index('idx_parameter_usage_preset', 'preset_used'),
        db.Index('idx_parameter_usage_timestamp', 'timestamp'),
    )


class ContentFilter(db.Model):
    """Configurable content filtering rules"""
    __tablename__ = 'content_filters'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # Filter identification
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50), nullable=False)  # pii, profanity, harmful, etc.
    filter_type = db.Column(db.String(20), nullable=False)  # regex, keyword, ml_model
    
    # Filter configuration
    pattern = db.Column(db.Text)  # Regex pattern or keyword list
    model_name = db.Column(db.String(100))  # ML model identifier
    threshold = db.Column(db.Float, default=0.8)  # Confidence threshold
    
    # Action configuration
    action = db.Column(db.String(50), default='block')  # block, warn, log, replace
    replacement_text = db.Column(db.String(200))
    warning_message = db.Column(db.String(500))
    
    # Metadata
    severity = db.Column(db.String(20), default='medium')
    description = db.Column(db.Text)
    enabled = db.Column(db.Boolean, default=True)
    
    # Version control
    version = db.Column(db.String(20), default='1.0')
    created_by = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = (
        db.Index('idx_content_filter_category', 'category'),
        db.Index('idx_content_filter_enabled', 'enabled'),
    )


class SafetyReport(db.Model):
    """Aggregate safety reports for compliance"""
    __tablename__ = 'safety_reports'
    
    id = db.Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    
    # Report metadata
    report_type = db.Column(db.String(50), nullable=False)  # daily, weekly, monthly, custom
    period_start = db.Column(db.DateTime, nullable=False)
    period_end = db.Column(db.DateTime, nullable=False)
    
    # Metrics
    total_interactions = db.Column(db.Integer, default=0)
    total_violations = db.Column(db.Integer, default=0)
    blocked_content = db.Column(db.Integer, default=0)
    warnings_issued = db.Column(db.Integer, default=0)
    false_positives = db.Column(db.Integer, default=0)
    
    # Violation breakdown
    violations_by_category = db.Column(JSONB)  # {category: count}
    violations_by_severity = db.Column(JSONB)  # {severity: count}
    
    # Compliance data
    compliance_score = db.Column(db.Float)  # 0.0-1.0
    regulatory_notes = db.Column(db.Text)
    
    # Report generation
    generated_at = db.Column(db.DateTime, default=datetime.utcnow)
    generated_by = db.Column(UUID(as_uuid=True), db.ForeignKey('users.id'))
    
    __table_args__ = (
        db.Index('idx_safety_report_period', 'period_start', 'period_end'),
        db.Index('idx_safety_report_type', 'report_type'),
    )
