#!/bin/bash
# deploy.sh - Production Deployment Script

set -e  # Exit on error

echo "🚀 Starting Cinematch Deployment..."

# Load environment
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

# Activate virtual environment
source venv/bin/activate

# Pull latest code
echo "📥 Pulling latest code..."
git pull origin main

# Install/update dependencies
echo "📦 Installing dependencies..."
pip install -r requirements.txt

# Run database migrations
echo "🗄️ Running database migrations..."
flask db upgrade

# Initialize database if needed
echo "🔧 Initializing database..."
flask init-db

# Load default keywords if needed
flask load-default-keywords

# Collect static files (if using Flask-Assets)
# flask assets build

# Run tests
echo "🧪 Running tests..."
python -m pytest tests/ -v || echo "⚠️ Tests failed, continuing..."

# Restart services
echo "🔄 Restarting services..."
sudo systemctl restart cinematch
sudo systemctl restart nginx

# Clear cache
echo "🧹 Clearing cache..."
flask clear-cache

echo "✅ Deployment complete!"

---

#!/bin/bash
# backup.sh - Backup Script

set -e

# Configuration
BACKUP_DIR="/var/backups/cinematch"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
S3_BUCKET="your-backup-bucket"

echo "🔒 Starting backup..."

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup database
echo "📊 Backing up database..."
PGPASSWORD=$PGPASSWORD pg_dump \
    -h db-postgresql-nyc1-43575-do-user-14596576-0.i.db.ondigitalocean.com \
    -p 25060 \
    -U Cinematch \
    -d defaultdb \
    --no-owner \
    > $BACKUP_DIR/db_$TIMESTAMP.sql

# Compress database backup
gzip $BACKUP_DIR/db_$TIMESTAMP.sql

# Backup environment files
echo "📄 Backing up configuration..."
tar -czf $BACKUP_DIR/config_$TIMESTAMP.tar.gz \
    .env \
    config.py \
    gunicorn.conf.py

# Backup uploaded files (if any)
if [ -d "uploads" ]; then
    echo "📁 Backing up uploads..."
    tar -czf $BACKUP_DIR/uploads_$TIMESTAMP.tar.gz uploads/
fi

# Upload to S3 (optional)
if command -v aws &> /dev/null; then
    echo "☁️ Uploading to S3..."
    aws s3 cp $BACKUP_DIR/db_$TIMESTAMP.sql.gz s3://$S3_BUCKET/backups/
    aws s3 cp $BACKUP_DIR/config_$TIMESTAMP.tar.gz s3://$S3_BUCKET/backups/
fi

# Clean old backups (keep last 7 days)
echo "🧹 Cleaning old backups..."
find $BACKUP_DIR -type f -mtime +7 -delete

echo "✅ Backup complete!"

---

#!/bin/bash
# health_check.sh - Health Check Script

# Check if app is responding
curl -f http://localhost:5000/health || exit 1

# Check database connection
flask check-db || exit 1

# Check Redis/Cache
flask check-cache || exit 1

# Check disk space
DISK_USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 90 ]; then
    echo "⚠️ Disk usage is above 90%"
    exit 1
fi

# Check memory usage
MEM_USAGE=$(free | awk 'NR==2 {print $3/$2 * 100.0}')
if (( $(echo "$MEM_USAGE > 90" | bc -l) )); then
    echo "⚠️ Memory usage is above 90%"
    exit 1
fi

echo "✅ All health checks passed"

---

#!/bin/bash
# setup_server.sh - Initial Server Setup

set -e

echo "🔧 Setting up Cinematch server..."

# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y \
    python3.11 \
    python3.11-venv \
    python3.11-dev \
    postgresql-client \
    nginx \
    certbot \
    python3-certbot-nginx \
    supervisor \
    git \
    curl \
    htop \
    fail2ban \
    ufw

# Setup firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw --force enable

# Create app user
sudo useradd -m -s /bin/bash cinematch

# Create app directory
sudo mkdir -p /var/www/cinematch
sudo chown cinematch:cinematch /var/www/cinematch

# Clone repository
cd /var/www/cinematch
sudo -u cinematch git clone https://github.com/tedrubin80/Cinematch.git .

# Create virtual environment
sudo -u cinematch python3.11 -m venv venv

# Install Python packages
sudo -u cinematch venv/bin/pip install --upgrade pip
sudo -u cinematch venv/bin/pip install -r requirements.txt

# Install Playwright browsers
sudo -u cinematch venv/bin/playwright install chromium
sudo -u cinematch venv/bin/playwright install-deps chromium

# Create necessary directories
sudo -u cinematch mkdir -p logs instance static/uploads

# Setup Nginx
sudo cp nginx.conf /etc/nginx/sites-available/cinematch
sudo ln -s /etc/nginx/sites-available/cinematch /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl restart nginx

# Setup systemd service
sudo cp cinematch.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable cinematch
sudo systemctl start cinematch

# Setup SSL with Let's Encrypt
read -p "Enter your domain name: " DOMAIN
sudo certbot --nginx -d $DOMAIN -d www.$DOMAIN

# Setup log rotation
sudo tee /etc/logrotate.d/cinematch > /dev/null <<EOF
/var/www/cinematch/logs/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 cinematch cinematch
    sharedscripts
    postrotate
        systemctl reload cinematch > /dev/null 2>&1 || true
    endscript
}
EOF

# Setup fail2ban
sudo tee /etc/fail2ban/jail.local > /dev/null <<EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true

[nginx-limit-req]
enabled = true
filter = nginx-limit-req
logpath = /var/log/nginx/error.log
EOF

sudo systemctl restart fail2ban

echo "✅ Server setup complete!"
echo "📝 Next steps:"
echo "1. Copy .env.production to .env and configure"
echo "2. Run: flask init-db"
echo "3. Run: flask create-admin"
echo "4. Visit https://$DOMAIN"

---

# maintenance.sh - Maintenance Mode Script
#!/bin/bash

case "$1" in
    on)
        echo "🔧 Enabling maintenance mode..."
        touch /var/www/cinematch/maintenance.flag
        sudo systemctl reload nginx
        echo "✅ Maintenance mode enabled"
        ;;
    off)
        echo "🔧 Disabling maintenance mode..."
        rm -f /var/www/cinematch/maintenance.flag
        sudo systemctl reload nginx
        echo "✅ Maintenance mode disabled"
        ;;
    *)
        echo "Usage: $0 {on|off}"
        exit 1
        ;;
esac