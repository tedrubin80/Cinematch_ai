# rate_limiter.py - Dynamic rate limiting middleware

import redis
import json
import logging
from datetime import datetime, timedelta, date
from functools import wraps
from flask import current_app, request, jsonify, g
from flask_login import current_user
from models import db, User, UsageTracking, RateLimitLog

logger = logging.getLogger(__name__)

class TierBasedRateLimiter:
    """Advanced rate limiting system with tier-based limits"""
    
    def __init__(self, redis_client=None):
        self.redis_client = redis_client
        self.tier_limits = {
            'free': {
                'requests_per_day': 10,
                'burst_allowance': 2,  # Extra requests for occasional spikes
                'cooldown_period': 3600,  # 1 hour cooldown after limit hit
                'features': ['basic_recommendations']
            },
            'basic': {
                'requests_per_day': 100,
                'burst_allowance': 10,
                'cooldown_period': 1800,  # 30 min cooldown
                'features': ['basic_recommendations', 'dual_agent_analysis', 'enhanced_recommendations', 'pdf_export']
            },
            'premium': {
                'requests_per_day': float('inf'),
                'burst_allowance': float('inf'),
                'cooldown_period': 0,
                'features': ['all']
            }
        }
    
    def get_user_key(self, user_id, date_str=None):
        """Generate Redis key for user rate limiting"""
        if not date_str:
            date_str = datetime.utcnow().strftime('%Y-%m-%d')
        return f"rate_limit:user:{user_id}:{date_str}"
    
    def get_ip_key(self, ip_address, date_str=None):
        """Generate Redis key for IP-based rate limiting"""
        if not date_str:
            date_str = datetime.utcnow().strftime('%Y-%m-%d')
        return f"rate_limit:ip:{ip_address}:{date_str}"
    
    def get_burst_key(self, user_id):
        """Generate Redis key for burst allowance tracking"""
        return f"burst:user:{user_id}"
    
    def get_cooldown_key(self, user_id):
        """Generate Redis key for cooldown tracking"""
        return f"cooldown:user:{user_id}"
    
    def check_rate_limit(self, user=None, ip_address=None, endpoint='general'):
        """
        Comprehensive rate limit checking
        Returns: (allowed: bool, info: dict)
        """
        current_time = datetime.utcnow()
        today = current_time.date()
        
        # For authenticated users
        if user and user.is_authenticated:
            return self._check_user_rate_limit(user, endpoint, current_time, today)
        
        # For anonymous users (IP-based limiting)
        if ip_address:
            return self._check_ip_rate_limit(ip_address, endpoint, current_time, today)
        
        return False, {
            'error': 'No user or IP provided for rate limiting',
            'code': 'INVALID_REQUEST'
        }
    
    def _check_user_rate_limit(self, user, endpoint, current_time, today):
        """Check rate limits for authenticated user"""
        tier = user.current_tier
        limits = self.tier_limits.get(tier, self.tier_limits['free'])
        
        # Premium users have unlimited access
        if tier == 'premium':
            return True, {
                'allowed': True,
                'tier': tier,
                'remaining': 'unlimited',
                'reset_time': None,
                'message': 'Premium access - unlimited requests'
            }
        
        # Check if user is in cooldown period
        cooldown_key = self.get_cooldown_key(user.id)
        if self.redis_client:
            cooldown_end = self.redis_client.get(cooldown_key)
            if cooldown_end:
                cooldown_end = datetime.fromisoformat(cooldown_end.decode())
                if current_time < cooldown_end:
                    remaining_cooldown = (cooldown_end - current_time).total_seconds()
                    return False, {
                        'allowed': False,
                        'code': 'COOLDOWN_ACTIVE',
                        'message': f'Account in cooldown period',
                        'cooldown_remaining': int(remaining_cooldown),
                        'reset_time': cooldown_end.isoformat()
                    }
        
        # Get current usage from database
        daily_usage = user.get_daily_usage(today)
        rate_limit = limits['requests_per_day']
        burst_allowance = limits['burst_allowance']
        
        # Check basic daily limit
        if daily_usage >= rate_limit:
            # Check if user can use burst allowance
            burst_used = self._get_burst_usage(user.id)
            if burst_used < burst_allowance:
                # Allow request but increment burst usage
                self._increment_burst_usage(user.id)
                return True, {
                    'allowed': True,
                    'tier': tier,
                    'daily_usage': daily_usage,
                    'rate_limit': rate_limit,
                    'burst_used': burst_used + 1,
                    'burst_allowance': burst_allowance,
                    'message': f'Using burst allowance ({burst_used + 1}/{burst_allowance})'
                }
            else:
                # Set cooldown period
                self._set_cooldown(user.id, limits['cooldown_period'])
                
                # Log the rate limit hit
                self._log_rate_limit_hit(user, endpoint, tier, rate_limit, daily_usage)
                
                return False, {
                    'allowed': False,
                    'code': 'RATE_LIMIT_EXCEEDED',
                    'tier': tier,
                    'daily_usage': daily_usage,
                    'rate_limit': rate_limit,
                    'burst_allowance': burst_allowance,
                    'message': f'Daily limit exceeded. Upgrade to {self._get_next_tier(tier)} for more requests.',
                    'upgrade_url': '/subscription/upgrade',
                    'reset_time': (current_time + timedelta(days=1)).replace(hour=0, minute=0, second=0).isoformat()
                }
        
        # Request allowed
        remaining = rate_limit - daily_usage - 1
        return True, {
            'allowed': True,
            'tier': tier,
            'daily_usage': daily_usage,
            'rate_limit': rate_limit,
            'remaining': remaining,
            'burst_allowance': burst_allowance,
            'message': f'Request allowed. {remaining} requests remaining today.'
        }
    
    def _check_ip_rate_limit(self, ip_address, endpoint, current_time, today):
        """Check rate limits for anonymous users by IP"""
        # Anonymous users get very limited access
        ip_limit = 5  # 5 requests per day for anonymous users
        
        if self.redis_client:
            ip_key = self.get_ip_key(ip_address)
            current_count = self.redis_client.get(ip_key)
            current_count = int(current_count) if current_count else 0
            
            if current_count >= ip_limit:
                return False, {
                    'allowed': False,
                    'code': 'IP_RATE_LIMIT_EXCEEDED',
                    'message': 'Anonymous usage limit exceeded. Please register for more access.',
                    'register_url': '/auth/register',
                    'current_usage': current_count,
                    'limit': ip_limit
                }
            
            return True, {
                'allowed': True,
                'current_usage': current_count,
                'limit': ip_limit,
                'remaining': ip_limit - current_count - 1,
                'message': 'Anonymous access allowed'
            }
        
        # Fallback if Redis is not available
        return True, {
            'allowed': True,
            'message': 'Rate limiting temporarily disabled'
        }
    
    def increment_usage(self, user=None, ip_address=None, query_type='basic', agents=None, tokens=0, cost=0.0):
        """Increment usage counters after successful request"""
        current_time = datetime.utcnow()
        
        if user and user.is_authenticated:
            # Update database usage tracking
            UsageTracking.increment_usage(
                user_id=user.id,
                query_type=query_type,
                agents=agents,
                tokens=tokens,
                cost=cost
            )
            
            # Update Redis counters for real-time tracking
            if self.redis_client:
                user_key = self.get_user_key(user.id)
                pipe = self.redis_client.pipeline()
                pipe.incr(user_key)
                pipe.expire(user_key, 86400)  # 24 hours
                pipe.execute()
        
        elif ip_address and self.redis_client:
            # Update IP-based counters
            ip_key = self.get_ip_key(ip_address)
            pipe = self.redis_client.pipeline()
            pipe.incr(ip_key)
            pipe.expire(ip_key, 86400)  # 24 hours
            pipe.execute()
    
    def _get_burst_usage(self, user_id):
        """Get current burst usage for user"""
        if not self.redis_client:
            return 0
        
        burst_key = self.get_burst_key(user_id)
        burst_data = self.redis_client.get(burst_key)
        
        if burst_data:
            data = json.loads(burst_data.decode())
            # Check if burst data is from today
            if data.get('date') == datetime.utcnow().strftime('%Y-%m-%d'):
                return data.get('count', 0)
        
        return 0
    
    def _increment_burst_usage(self, user_id):
        """Increment burst usage counter"""
        if not self.redis_client:
            return
        
        burst_key = self.get_burst_key(user_id)
        current_date = datetime.utcnow().strftime('%Y-%m-%d')
        
        burst_data = {
            'date': current_date,
            'count': self._get_burst_usage(user_id) + 1
        }
        
        # Store burst data with 24-hour expiry
        self.redis_client.setex(
            burst_key,
            86400,
            json.dumps(burst_data)
        )
    
    def _set_cooldown(self, user_id, cooldown_seconds):
        """Set cooldown period for user"""
        if not self.redis_client or cooldown_seconds <= 0:
            return
        
        cooldown_key = self.get_cooldown_key(user_id)
        cooldown_end = datetime.utcnow() + timedelta(seconds=cooldown_seconds)
        
        self.redis_client.setex(
            cooldown_key,
            cooldown_seconds,
            cooldown_end.isoformat()
        )
    
    def _get_next_tier(self, current_tier):
        """Get the next subscription tier"""
        tier_progression = {'free': 'basic', 'basic': 'premium', 'premium': 'premium'}
        return tier_progression.get(current_tier, 'basic')
    
    def _log_rate_limit_hit(self, user, endpoint, tier, rate_limit, current_usage):
        """Log rate limit hit for analysis"""
        try:
            log_entry = RateLimitLog(
                user_id=user.id,
                ip_address=request.remote_addr if request else None,
                endpoint=endpoint,
                user_tier=tier,
                rate_limit=rate_limit,
                current_usage=current_usage,
                user_agent=request.headers.get('User-Agent') if request else None,
                referer=request.headers.get('Referer') if request else None
            )
            db.session.add(log_entry)
            db.session.commit()
        except Exception as e:
            logger.error(f"Error logging rate limit hit: {e}")
    
    def get_usage_statistics(self, user_id, days=7):
        """Get detailed usage statistics for a user"""
        from sqlalchemy import func
        
        start_date = date.today() - timedelta(days=days-1)
        
        # Get daily usage for the period
        daily_usage = db.session.query(
            UsageTracking.query_date,
            UsageTracking.query_count,
            UsageTracking.query_type,
            UsageTracking.agents_used
        ).filter(
            UsageTracking.user_id == user_id,
            UsageTracking.query_date >= start_date
        ).order_by(UsageTracking.query_date).all()
        
        # Get rate limit hits in the period
        rate_limit_hits = db.session.query(
            func.date(RateLimitLog.timestamp).label('hit_date'),
            func.count(RateLimitLog.id).label('hit_count')
        ).filter(
            RateLimitLog.user_id == user_id,
            func.date(RateLimitLog.timestamp) >= start_date
        ).group_by(func.date(RateLimitLog.timestamp)).all()
        
        return {
            'daily_usage': [
                {
                    'date': usage.query_date.isoformat(),
                    'count': usage.query_count,
                    'type': usage.query_type,
                    'agents': usage.agents_used
                }
                for usage in daily_usage
            ],
            'rate_limit_hits': [
                {
                    'date': hit.hit_date.isoformat(),
                    'count': hit.hit_count
                }
                for hit in rate_limit_hits
            ],
            'period_days': days
        }
    
    def reset_user_cooldown(self, user_id):
        """Admin function to reset user cooldown"""
        if self.redis_client:
            cooldown_key = self.get_cooldown_key(user_id)
            burst_key = self.get_burst_key(user_id)
            
            self.redis_client.delete(cooldown_key)
            self.redis_client.delete(burst_key)
            
            return True
        return False


# Global rate limiter instance
rate_limiter = None

def init_rate_limiter(app, redis_client=None):
    """Initialize the rate limiter with app context"""
    global rate_limiter
    
    if not redis_client:
        import redis
        redis_url = app.config.get('REDIS_URL', 'redis://localhost:6379/0')
        redis_client = redis.from_url(redis_url, decode_responses=False)
    
    rate_limiter = TierBasedRateLimiter(redis_client)
    return rate_limiter


# Decorators for easy use

def require_rate_limit(endpoint='general'):
    """Decorator to enforce rate limiting on routes"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Get rate limiter
            if not rate_limiter:
                logger.warning("Rate limiter not initialized, allowing request")
                return f(*args, **kwargs)
            
            # Determine user and IP
            user = current_user if current_user.is_authenticated else None
            ip_address = request.remote_addr
            
            # Check rate limit
            allowed, info = rate_limiter.check_rate_limit(
                user=user,
                ip_address=ip_address,
                endpoint=endpoint
            )
            
            if not allowed:
                response_data = {
                    'error': 'Rate limit exceeded',
                    'details': info
                }
                
                # Add upgrade suggestion for authenticated users
                if user and user.is_authenticated:
                    response_data['suggestion'] = {
                        'message': f"Upgrade to {rate_limiter._get_next_tier(user.current_tier)} for more requests",
                        'upgrade_url': '/subscription/upgrade'
                    }
                elif not user:
                    response_data['suggestion'] = {
                        'message': 'Register for a free account to get more requests',
                        'register_url': '/auth/register'
                    }
                
                return jsonify(response_data), 429
            
            # Store rate limit info in g for use in the route
            g.rate_limit_info = info
            
            # Execute the route function
            try:
                result = f(*args, **kwargs)
                
                # Increment usage after successful execution
                rate_limiter.increment_usage(
                    user=user,
                    ip_address=ip_address,
                    query_type=request.json.get('query_type', 'basic') if request.json else 'basic',
                    agents=request.json.get('agents', []) if request.json else [],
                    tokens=getattr(g, 'response_tokens', 0),
                    cost=getattr(g, 'response_cost', 0.0)
                )
                
                return result
                
            except Exception as e:
                # Don't increment usage if the request failed
                logger.error(f"Request failed after rate limit check: {e}")
                raise
        
        return decorated_function
    return decorator


def feature_required(feature_name):
    """Decorator to require specific subscription features"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                return jsonify({
                    'error': 'Authentication required',
                    'login_url': '/auth/login'
                }), 401
            
            # Get user's tier features
            if hasattr(current_user, 'subscription') and current_user.subscription:
                features = current_user.subscription.get_tier_features()
                user_features = features.get('features', [])
                
                if feature_name not in user_features and 'all' not in user_features:
                    return jsonify({
                        'error': 'Feature not available in your subscription tier',
                        'required_feature': feature_name,
                        'current_tier': current_user.current_tier,
                        'upgrade_url': '/subscription/upgrade'
                    }), 402
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def smart_rate_limit(base_endpoint='general'):
    """Smart rate limiting that adjusts based on request complexity"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Determine endpoint complexity
            complexity_score = 1
            endpoint = base_endpoint
            
            if request.json:
                # Adjust complexity based on request parameters
                if request.json.get('agents'):
                    agent_count = len(request.json['agents'])
                    complexity_score += agent_count * 0.5
                    endpoint = f"{base_endpoint}_multi_agent"
                
                if request.json.get('query_type') == 'advanced':
                    complexity_score += 1
                    endpoint = f"{base_endpoint}_advanced"
            
            # Apply rate limiting with adjusted endpoint
            return require_rate_limit(endpoint)(f)(*args, **kwargs)
        
        return decorated_function
    return decorator


# Utility functions for rate limit management

def get_user_rate_limit_status(user):
    """Get comprehensive rate limit status for a user"""
    if not rate_limiter:
        return {'error': 'Rate limiter not available'}
    
    allowed, info = rate_limiter.check_rate_limit(user=user)
    
    # Add usage statistics
    stats = rate_limiter.get_usage_statistics(user.id, days=7)
    
    return {
        'current_status': info,
        'usage_statistics': stats,
        'tier_info': {
            'current_tier': user.current_tier,
            'features': user.subscription.get_tier_features() if user.subscription else None
        }
    }


def admin_reset_user_rate_limit(user_id):
    """Admin function to reset a user's rate limit"""
    if rate_limiter:
        return rate_limiter.reset_user_cooldown(user_id)
    return False


def get_rate_limit_analytics():
    """Get system-wide rate limiting analytics"""
    from sqlalchemy import func, desc
    
    # Top rate-limited users
    top_limited_users = db.session.query(
        RateLimitLog.user_id,
        func.count(RateLimitLog.id).label('hit_count'),
        RateLimitLog.user_tier
    ).group_by(
        RateLimitLog.user_id, 
        RateLimitLog.user_tier
    ).order_by(desc('hit_count')).limit(10).all()
    
    # Rate limit hits by tier
    hits_by_tier = db.session.query(
        RateLimitLog.user_tier,
        func.count(RateLimitLog.id).label('hit_count')
    ).group_by(RateLimitLog.user_tier).all()
    
    # Most rate-limited endpoints
    hits_by_endpoint = db.session.query(
        RateLimitLog.endpoint,
        func.count(RateLimitLog.id).label('hit_count')
    ).group_by(RateLimitLog.endpoint).order_by(desc('hit_count')).limit(10).all()
    
    return {
        'top_limited_users': [
            {
                'user_id': str(user.user_id),
                'hit_count': user.hit_count,
                'tier': user.user_tier
            }
            for user in top_limited_users
        ],
        'hits_by_tier': [
            {
                'tier': tier.user_tier,
                'hit_count': tier.hit_count
            }
            for tier in hits_by_tier
        ],
        'hits_by_endpoint': [
            {
                'endpoint': endpoint.endpoint,
                'hit_count': endpoint.hit_count
            }
            for endpoint in hits_by_endpoint
        ]
    }