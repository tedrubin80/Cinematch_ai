# auth_enhanced.py - Enhanced authentication system for Cinematch

import secrets
import logging
from datetime import datetime, timedelta
from functools import wraps
from urllib.parse import urlparse, urljoin

from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, current_app
from flask_login import login_user, login_required, logout_user, current_user
from flask_mail import Message
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import bleach

from models import db, User, UserSubscription, SecurityLog
from subscription_system import SubscriptionManager
from rate_limiter import get_user_rate_limit_status

logger = logging.getLogger(__name__)

# Create enhanced auth blueprint
auth_enhanced_bp = Blueprint('auth_enhanced', __name__, url_prefix='/auth')

# Email verification settings
VERIFICATION_TOKEN_EXPIRY_HOURS = 24
PASSWORD_RESET_TOKEN_EXPIRY_HOURS = 2
MAX_LOGIN_ATTEMPTS = 5
ACCOUNT_LOCKOUT_DURATION_MINUTES = 30

class AuthenticationManager:
    """Centralized authentication management"""
    
    @staticmethod
    def generate_verification_token():
        """Generate a secure verification token"""
        return secrets.token_urlsafe(32)
    
    @staticmethod
    def generate_password_reset_token():
        """Generate a secure password reset token"""
        return secrets.token_urlsafe(32)
    
    @staticmethod
    def is_safe_url(target):
        """Check if redirect URL is safe"""
        ref_url = urlparse(request.host_url)
        test_url = urlparse(urljoin(request.host_url, target))
        return test_url.scheme in ('http', 'https') and ref_url.netloc == test_url.netloc
    
    @staticmethod
    def log_security_event(event_type, details, severity='info', user_id=None):
        """Log security events"""
        try:
            security_log = SecurityLog(
                event_type=event_type,
                ip_address=request.remote_addr,
                user_agent=request.headers.get('User-Agent', ''),
                details=details,
                severity=severity
            )
            if user_id:
                security_log.user_id = user_id
            
            db.session.add(security_log)
            db.session.commit()
        except Exception as e:
            logger.error(f"Failed to log security event: {e}")
    
    @staticmethod
    def send_verification_email(user, mail_instance=None):
        """Send email verification"""
        if not mail_instance:
            logger.warning("Mail instance not provided for verification email")
            return False
        
        try:
            token = AuthenticationManager.generate_verification_token()
            user.verification_token = token
            user.verification_token_expiry = datetime.utcnow() + timedelta(hours=VERIFICATION_TOKEN_EXPIRY_HOURS)
            db.session.commit()
            
            verification_url = url_for('auth_enhanced.verify_email', token=token, _external=True)
            
            msg = Message(
                subject='Welcome to Cinematch - Verify Your Email',
                recipients=[user.email],
                html=render_template('email/verification.html', 
                                   user=user, 
                                   verification_url=verification_url)
            )
            mail_instance.send(msg)
            
            AuthenticationManager.log_security_event(
                'email_verification_sent',
                {'email': user.email, 'user_id': str(user.id)},
                user_id=user.id
            )
            
            return True
        except Exception as e:
            logger.error(f"Failed to send verification email: {e}")
            return False
    
    @staticmethod
    def send_password_reset_email(user, mail_instance=None):
        """Send password reset email"""
        if not mail_instance:
            logger.warning("Mail instance not provided for password reset email")
            return False
        
        try:
            token = AuthenticationManager.generate_password_reset_token()
            user.reset_token = token
            user.reset_token_expiry = datetime.utcnow() + timedelta(hours=PASSWORD_RESET_TOKEN_EXPIRY_HOURS)
            db.session.commit()
            
            reset_url = url_for('auth_enhanced.reset_password', token=token, _external=True)
            
            msg = Message(
                subject='Cinematch - Password Reset Request',
                recipients=[user.email],
                html=render_template('email/password_reset.html',
                                   user=user,
                                   reset_url=reset_url)
            )
            mail_instance.send(msg)
            
            AuthenticationManager.log_security_event(
                'password_reset_requested',
                {'email': user.email, 'user_id': str(user.id)},
                user_id=user.id
            )
            
            return True
        except Exception as e:
            logger.error(f"Failed to send password reset email: {e}")
            return False
    
    @staticmethod
    def validate_password_strength(password):
        """Validate password meets security requirements"""
        errors = []
        
        if len(password) < 8:
            errors.append("Password must be at least 8 characters long")
        
        if not any(c.isupper() for c in password):
            errors.append("Password must contain at least one uppercase letter")
        
        if not any(c.islower() for c in password):
            errors.append("Password must contain at least one lowercase letter")
        
        if not any(c.isdigit() for c in password):
            errors.append("Password must contain at least one number")
        
        if not any(c in '!@#$%^&*()_+-=[]{}|;:,.<>?' for c in password):
            errors.append("Password must contain at least one special character")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def sanitize_input(text, max_length=255):
        """Sanitize user input"""
        if not text:
            return ""
        
        # Remove HTML tags and limit length
        cleaned = bleach.clean(str(text), tags=[], strip=True)
        return cleaned[:max_length]


# Authentication routes

@auth_enhanced_bp.route('/register', methods=['GET', 'POST'])
def register():
    """Enhanced user registration with email verification"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        try:
            # Get and sanitize form data
            username = AuthenticationManager.sanitize_input(request.form.get('username', ''), 80)
            email = AuthenticationManager.sanitize_input(request.form.get('email', ''), 120).lower()
            password = request.form.get('password', '')
            confirm_password = request.form.get('confirm_password', '')
            
            # Validation
            errors = []
            
            if not username or len(username) < 3:
                errors.append("Username must be at least 3 characters long")
            
            if not email or '@' not in email:
                errors.append("Please provide a valid email address")
            
            if password != confirm_password:
                errors.append("Passwords do not match")
            
            # Password strength validation
            password_valid, password_errors = AuthenticationManager.validate_password_strength(password)
            if not password_valid:
                errors.extend(password_errors)
            
            # Check if user already exists
            existing_user = User.query.filter(
                (User.username == username) | (User.email == email)
            ).first()
            
            if existing_user:
                if existing_user.username == username:
                    errors.append("Username already exists")
                if existing_user.email == email:
                    errors.append("Email already registered")
            
            if errors:
                for error in errors:
                    flash(error, 'error')
                return render_template('auth/register.html')
            
            # Create new user
            user = User(
                username=username,
                email=email,
                is_verified=False,
                created_at=datetime.utcnow()
            )
            user.set_password(password)
            
            db.session.add(user)
            db.session.flush()  # Get user ID
            
            # Create free subscription
            subscription = UserSubscription(
                user_id=user.id,
                tier='free',
                status='active',
                created_at=datetime.utcnow()
            )
            db.session.add(subscription)
            
            db.session.commit()
            
            # Send verification email
            from flask_mail import Mail
            mail = Mail(current_app)
            if AuthenticationManager.send_verification_email(user, mail):
                flash('Registration successful! Please check your email to verify your account.', 'success')
            else:
                flash('Registration successful! However, we could not send the verification email. Please contact support.', 'warning')
            
            # Log successful registration
            AuthenticationManager.log_security_event(
                'user_registered',
                {'username': username, 'email': email, 'user_id': str(user.id)},
                user_id=user.id
            )
            
            return redirect(url_for('auth_enhanced.login'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Registration error: {e}")
            flash('An error occurred during registration. Please try again.', 'error')
    
    return render_template('auth/register.html')


@auth_enhanced_bp.route('/verify-email/<token>')
def verify_email(token):
    """Email verification endpoint"""
    user = User.query.filter_by(verification_token=token).first()
    
    if not user:
        flash('Invalid verification link.', 'error')
        return redirect(url_for('auth_enhanced.login'))
    
    if user.verification_token_expiry and datetime.utcnow() > user.verification_token_expiry:
        flash('Verification link has expired. Please request a new one.', 'error')
        return redirect(url_for('auth_enhanced.resend_verification'))
    
    user.is_verified = True
    user.verification_token = None
    user.verification_token_expiry = None
    db.session.commit()
    
    AuthenticationManager.log_security_event(
        'email_verified',
        {'email': user.email, 'user_id': str(user.id)},
        user_id=user.id
    )
    
    flash('Email verified successfully! You can now log in.', 'success')
    return redirect(url_for('auth_enhanced.login'))


@auth_enhanced_bp.route('/resend-verification', methods=['GET', 'POST'])
def resend_verification():
    """Resend email verification"""
    if request.method == 'POST':
        email = AuthenticationManager.sanitize_input(request.form.get('email', '')).lower()
        user = User.query.filter_by(email=email).first()
        
        if user and not user.is_verified:
            from flask_mail import Mail
            mail = Mail(current_app)
            if AuthenticationManager.send_verification_email(user, mail):
                flash('Verification email sent! Please check your inbox.', 'success')
            else:
                flash('Failed to send verification email. Please try again later.', 'error')
        else:
            # Don't reveal if email exists for security
            flash('If the email exists and is not verified, a verification email has been sent.', 'info')
        
        return redirect(url_for('auth_enhanced.login'))
    
    return render_template('auth/resend_verification.html')


@auth_enhanced_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Enhanced login with account lockout protection"""
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        try:
            identifier = AuthenticationManager.sanitize_input(request.form.get('identifier', '')).lower()
            password = request.form.get('password', '')
            remember_me = bool(request.form.get('remember_me'))
            
            if not identifier or not password:
                flash('Please provide both username/email and password.', 'error')
                return render_template('auth/login.html')
            
            # Find user by username or email
            user = User.query.filter(
                (User.username == identifier) | (User.email == identifier)
            ).first()
            
            if not user:
                AuthenticationManager.log_security_event(
                    'login_failed_invalid_user',
                    {'identifier': identifier, 'ip': request.remote_addr},
                    severity='warning'
                )
                flash('Invalid credentials.', 'error')
                return render_template('auth/login.html')
            
            # Check if account is locked
            if user.is_account_locked:
                AuthenticationManager.log_security_event(
                    'login_attempt_locked_account',
                    {'user_id': str(user.id), 'identifier': identifier},
                    severity='warning',
                    user_id=user.id
                )
                remaining_time = (user.account_locked_until - datetime.utcnow()).total_seconds() // 60
                flash(f'Account is locked. Try again in {int(remaining_time)} minutes.', 'error')
                return render_template('auth/login.html')
            
            # Check password
            if not user.check_password(password):
                user.increment_failed_login()
                AuthenticationManager.log_security_event(
                    'login_failed_invalid_password',
                    {
                        'user_id': str(user.id),
                        'identifier': identifier,
                        'failed_attempts': user.failed_login_attempts
                    },
                    severity='warning',
                    user_id=user.id
                )
                
                if user.is_account_locked:
                    flash('Too many failed attempts. Account has been locked.', 'error')
                else:
                    remaining = MAX_LOGIN_ATTEMPTS - user.failed_login_attempts
                    flash(f'Invalid credentials. {remaining} attempts remaining.', 'error')
                
                return render_template('auth/login.html')
            
            # Check if email is verified
            if not user.is_verified:
                flash('Please verify your email address before logging in.', 'warning')
                return redirect(url_for('auth_enhanced.resend_verification'))
            
            # Successful login
            user.unlock_account()  # Reset failed login attempts
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            login_user(user, remember=remember_me)
            
            AuthenticationManager.log_security_event(
                'user_logged_in',
                {'user_id': str(user.id), 'username': user.username},
                user_id=user.id
            )
            
            flash(f'Welcome back, {user.username}!', 'success')
            
            # Redirect to next page or dashboard
            next_page = request.args.get('next')
            if next_page and AuthenticationManager.is_safe_url(next_page):
                return redirect(next_page)
            
            return redirect(url_for('index'))
            
        except Exception as e:
            logger.error(f"Login error: {e}")
            flash('An error occurred during login. Please try again.', 'error')
    
    return render_template('auth/login.html')


@auth_enhanced_bp.route('/logout')
@login_required
def logout():
    """User logout"""
    AuthenticationManager.log_security_event(
        'user_logged_out',
        {'user_id': str(current_user.id), 'username': current_user.username},
        user_id=current_user.id
    )
    
    logout_user()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('index'))


@auth_enhanced_bp.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    """Password reset request"""
    if request.method == 'POST':
        email = AuthenticationManager.sanitize_input(request.form.get('email', '')).lower()
        user = User.query.filter_by(email=email).first()
        
        if user:
            from flask_mail import Mail
            mail = Mail(current_app)
            if AuthenticationManager.send_password_reset_email(user, mail):
                flash('Password reset instructions have been sent to your email.', 'success')
            else:
                flash('Failed to send password reset email. Please try again later.', 'error')
        else:
            # Don't reveal if email exists for security
            flash('If the email exists, password reset instructions have been sent.', 'info')
        
        return redirect(url_for('auth_enhanced.login'))
    
    return render_template('auth/forgot_password.html')


@auth_enhanced_bp.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    """Password reset with token"""
    user = User.query.filter_by(reset_token=token).first()
    
    if not user:
        flash('Invalid password reset link.', 'error')
        return redirect(url_for('auth_enhanced.forgot_password'))
    
    if user.reset_token_expiry and datetime.utcnow() > user.reset_token_expiry:
        flash('Password reset link has expired. Please request a new one.', 'error')
        return redirect(url_for('auth_enhanced.forgot_password'))
    
    if request.method == 'POST':
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        
        if password != confirm_password:
            flash('Passwords do not match.', 'error')
            return render_template('auth/reset_password.html', token=token)
        
        # Validate password strength
        password_valid, password_errors = AuthenticationManager.validate_password_strength(password)
        if not password_valid:
            for error in password_errors:
                flash(error, 'error')
            return render_template('auth/reset_password.html', token=token)
        
        # Reset password
        user.set_password(password)
        user.reset_token = None
        user.reset_token_expiry = None
        user.unlock_account()  # Clear any lockout
        db.session.commit()
        
        AuthenticationManager.log_security_event(
            'password_reset_completed',
            {'user_id': str(user.id), 'email': user.email},
            user_id=user.id
        )
        
        flash('Password reset successfully! You can now log in with your new password.', 'success')
        return redirect(url_for('auth_enhanced.login'))
    
    return render_template('auth/reset_password.html', token=token)


@auth_enhanced_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    """User profile management"""
    if request.method == 'POST':
        try:
            # Get form data
            username = AuthenticationManager.sanitize_input(request.form.get('username', ''), 80)
            email = AuthenticationManager.sanitize_input(request.form.get('email', ''), 120).lower()
            current_password = request.form.get('current_password', '')
            new_password = request.form.get('new_password', '')
            confirm_password = request.form.get('confirm_password', '')
            
            # Validate current password for any changes
            if not current_user.check_password(current_password):
                flash('Current password is incorrect.', 'error')
                return render_template('auth/profile.html')
            
            errors = []
            
            # Check if username/email changed and validate
            if username != current_user.username:
                existing = User.query.filter(User.username == username, User.id != current_user.id).first()
                if existing:
                    errors.append('Username already taken.')
                elif len(username) < 3:
                    errors.append('Username must be at least 3 characters long.')
                else:
                    current_user.username = username
            
            if email != current_user.email:
                existing = User.query.filter(User.email == email, User.id != current_user.id).first()
                if existing:
                    errors.append('Email already registered.')
                elif '@' not in email:
                    errors.append('Please provide a valid email address.')
                else:
                    current_user.email = email
                    current_user.is_verified = False  # Re-verify new email
                    
                    # Send verification email for new address
                    from flask_mail import Mail
                    mail = Mail(current_app)
                    AuthenticationManager.send_verification_email(current_user, mail)
                    flash('Email updated. Please verify your new email address.', 'info')
            
            # Handle password change
            if new_password:
                if new_password != confirm_password:
                    errors.append('New passwords do not match.')
                else:
                    password_valid, password_errors = AuthenticationManager.validate_password_strength(new_password)
                    if not password_valid:
                        errors.extend(password_errors)
                    else:
                        current_user.set_password(new_password)
                        flash('Password updated successfully.', 'success')
            
            if errors:
                for error in errors:
                    flash(error, 'error')
            else:
                current_user.updated_at = datetime.utcnow()
                db.session.commit()
                
                AuthenticationManager.log_security_event(
                    'profile_updated',
                    {'user_id': str(current_user.id)},
                    user_id=current_user.id
                )
                
                flash('Profile updated successfully!', 'success')
                
        except Exception as e:
            db.session.rollback()
            logger.error(f"Profile update error: {e}")
            flash('An error occurred while updating your profile.', 'error')
    
    # Get user's subscription and usage info
    rate_limit_status = get_user_rate_limit_status(current_user)
    
    return render_template('auth/profile.html', 
                         user=current_user,
                         rate_limit_status=rate_limit_status)


@auth_enhanced_bp.route('/account/delete', methods=['GET', 'POST'])
@login_required
def delete_account():
    """Account deletion with confirmation"""
    if request.method == 'POST':
        password = request.form.get('password', '')
        confirmation = request.form.get('confirmation', '')
        
        if not current_user.check_password(password):
            flash('Incorrect password.', 'error')
            return render_template('auth/delete_account.html')
        
        if confirmation != 'DELETE':
            flash('Please type "DELETE" to confirm account deletion.', 'error')
            return render_template('auth/delete_account.html')
        
        try:
            user_id = current_user.id
            email = current_user.email
            
            # Cancel any active subscriptions
            if current_user.subscription and current_user.subscription.stripe_subscription_id:
                try:
                    import stripe
                    stripe.Subscription.delete(current_user.subscription.stripe_subscription_id)
                except Exception as e:
                    logger.error(f"Failed to cancel Stripe subscription: {e}")
            
            # Log account deletion
            AuthenticationManager.log_security_event(
                'account_deleted',
                {'user_id': str(user_id), 'email': email},
                severity='info',
                user_id=user_id
            )
            
            # Logout user
            logout_user()
            
            # Delete user account (cascade will handle related records)
            db.session.delete(current_user)
            db.session.commit()
            
            flash('Your account has been deleted successfully.', 'info')
            return redirect(url_for('index'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Account deletion error: {e}")
            flash('An error occurred while deleting your account. Please contact support.', 'error')
    
    return render_template('auth/delete_account.html')


# API endpoints for AJAX requests

@auth_enhanced_bp.route('/api/check-username', methods=['POST'])
def check_username():
    """Check if username is available"""
    username = AuthenticationManager.sanitize_input(request.json.get('username', ''), 80)
    
    if len(username) < 3:
        return jsonify({'available': False, 'message': 'Username must be at least 3 characters long'})
    
    existing = User.query.filter_by(username=username).first()
    
    return jsonify({
        'available': existing is None,
        'message': 'Username available' if not existing else 'Username already taken'
    })


@auth_enhanced_bp.route('/api/check-email', methods=['POST'])
def check_email():
    """Check if email is available"""
    email = AuthenticationManager.sanitize_input(request.json.get('email', ''), 120).lower()
    
    if '@' not in email:
        return jsonify({'available': False, 'message': 'Please provide a valid email address'})
    
    existing = User.query.filter_by(email=email).first()
    
    return jsonify({
        'available': existing is None,
        'message': 'Email available' if not existing else 'Email already registered'
    })


@auth_enhanced_bp.route('/api/validate-password', methods=['POST'])
def validate_password():
    """Validate password strength"""
    password = request.json.get('password', '')
    valid, errors = AuthenticationManager.validate_password_strength(password)
    
    return jsonify({
        'valid': valid,
        'errors': errors,
        'message': 'Password meets requirements' if valid else 'Password does not meet requirements'
    })


# Admin decorators and functions

def admin_required(f):
    """Decorator to require admin privileges"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth_enhanced.login', next=request.url))
        if not current_user.is_admin:
            flash('Administrator privileges required.', 'error')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function


def verified_required(f):
    """Decorator to require email verification"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth_enhanced.login', next=request.url))
        if not current_user.is_verified:
            flash('Please verify your email address to access this feature.', 'warning')
            return redirect(url_for('auth_enhanced.resend_verification'))
        return f(*args, **kwargs)
    return decorated_function


# Utility functions

def get_user_security_summary(user_id):
    """Get security summary for a user"""
    from sqlalchemy import func, desc
    
    # Recent security events
    recent_events = SecurityLog.query.filter_by(
        user_id=user_id
    ).order_by(desc(SecurityLog.timestamp)).limit(10).all()
    
    # Failed login attempts in last 24 hours
    since_yesterday = datetime.utcnow() - timedelta(hours=24)
    recent_failed_logins = SecurityLog.query.filter(
        SecurityLog.user_id == user_id,
        SecurityLog.event_type == 'login_failed_invalid_password',
        SecurityLog.timestamp >= since_yesterday
    ).count()
    
    return {
        'recent_events': [
            {
                'event_type': event.event_type,
                'timestamp': event.timestamp.isoformat(),
                'severity': event.severity,
                'details': event.details
            }
            for event in recent_events
        ],
        'recent_failed_logins': recent_failed_logins,
        'account_status': {
            'is_verified': User.query.get(user_id).is_verified,
            'is_locked': User.query.get(user_id).is_account_locked,
            'last_login': User.query.get(user_id).last_login.isoformat() if User.query.get(user_id).last_login else None
        }
    }