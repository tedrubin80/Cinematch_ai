# privacy_logging.py - Privacy-friendly logging implementation

import hashlib
import ipaddress
from datetime import datetime, timedelta
from typing import Optional
import json

class PrivacyFriendlyLogger:
    """Logging system that respects user privacy"""
    
    def __init__(self, db):
        self.db = db
        
    def anonymize_ip(self, ip_address: str, level: str = 'partial') -> str:
        """
        Anonymize IP address
        - partial: Remove last octet (192.168.1.100 -> 192.168.1.0)
        - full: Complete hash
        - none: Keep full IP (not recommended)
        """
        if level == 'none':
            return ip_address
            
        try:
            ip = ipaddress.ip_address(ip_address)
            
            if level == 'partial':
                if isinstance(ip, ipaddress.IPv4Address):
                    # Remove last octet for IPv4
                    parts = str(ip).split('.')
                    return f"{'.'.join(parts[:3])}.0"
                else:
                    # For IPv6, zero out last 64 bits
                    network = ipaddress.ip_network(f"{ip}/64", strict=False)
                    return str(network.network_address)
                    
            elif level == '