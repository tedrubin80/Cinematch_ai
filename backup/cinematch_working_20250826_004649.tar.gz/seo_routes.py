# seo_routes.py - SEO and AI agent optimization routes

from flask import Blueprint, Response, jsonify, request, render_template
from datetime import datetime
import json

seo_bp = Blueprint('seo', __name__)

@seo_bp.route('/robots.txt')
def robots_txt():
    """Generate robots.txt for search engines"""
    from app import app
    
    # Get admin path to exclude
    admin_path = app.config.get('ADMIN_SECRET_PATH', 'admin')
    
    content = f"""# Cinematch Robots.txt
# Generated: {datetime.utcnow().isoformat()}

# Allow major search engines
User-agent: Googlebot
Allow: /
Disallow: /{admin_path}/
Disallow: /api/
Crawl-delay: 2

User-agent: Bingbot
Allow: /
Disallow: /{admin_path}/
Disallow: /api/
Crawl-delay: 2

# AI Agents
User-agent: GPTBot
Allow: /
Disallow: /{admin_path}/
Disallow: /api/
Crawl-delay: 2

User-agent: Claude-Web
Allow: /
Disallow: /{admin_path}/
Disallow: /api/
Crawl-delay: 2

User-agent: Anthropic-AI
Allow: /
Disallow: /{admin_path}/
Disallow: /api/
Crawl-delay: 2

User-agent: Google-Extended
Allow: /
Disallow: /{admin_path}/
Disallow: /api/
Crawl-delay: 2

# Block bad bots
User-agent: AhrefsBot
Disallow: /

User-agent: SemrushBot
Disallow: /

User-agent: MJ12bot
Disallow: /

User-agent: DotBot
Disallow: /

# Default for all others
User-agent: *
Allow: /
Disallow: /{admin_path}/
Disallow: /api/
Disallow: /consent-required
Crawl-delay: 5

# Sitemap location
Sitemap: https://yourdomain.com/sitemap.xml
"""
    
    return Response(content, mimetype='text/plain')

@seo_bp.route('/sitemap.xml')
def sitemap_xml():
    """Generate XML sitemap"""
    from app import app
    
    # Base URL from config
    base_url = "https://yourdomain.com"
    
    # Define pages and their priorities
    pages = [
        ('/', 1.0, 'daily'),
        ('/help', 0.8, 'weekly'),
        ('/privacy-policy', 0.5, 'monthly'),
        ('/terms', 0.5, 'monthly'),
    ]
    
    xml_content = '<?xml version="1.0" encoding="UTF-8"?>\n'
    xml_content += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
    
    for path, priority, changefreq in pages:
        xml_content += f"""  <url>
    <loc>{base_url}{path}</loc>
    <lastmod>{datetime.utcnow().strftime('%Y-%m-%d')}</lastmod>
    <changefreq>{changefreq}</changefreq>
    <priority>{priority}</priority>
  </url>\n"""
    
    xml_content += '</urlset>'
    
    return Response(xml_content, mimetype='application/xml')

@seo_bp.route('/ai.txt')
def ai_txt():
    """AI agent information file (similar to humans.txt)"""
    content = f"""# AI Agent Information
# Generated: {datetime.utcnow().isoformat()}

/* ABOUT */
Service: Cinematch
Description: AI-powered movie recommendation service for adults 18+
Type: Entertainment / Media Recommendation
Language: English

/* CAPABILITIES */
- Movie recommendations based on user preferences
- Content filtering for age-appropriate suggestions
- Natural language understanding for movie queries
- Personalized suggestions based on mood and genre

/* DATA USAGE */
- We respect user privacy
- Chat logs only stored when safety guardrails triggered
- No training on user data
- GDPR compliant

/* API ACCESS */
Endpoint: /api/ai-description
Format: JSON
Rate Limit: 100 requests/hour

/* RESTRICTIONS */
- Service limited to users 18 years and older
- No illegal content requests
- Respectful use only

/* CONTACT */
AI Ethics: ethics@cinematch.ai
Privacy: privacy@cinematch.ai
General: hello@cinematch.ai
"""
    
    return Response(content, mimetype='text/plain')

@seo_bp.route('/api/ai-description')
def ai_description():
    """Structured data endpoint for AI agents"""
    description = {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "Cinematch",
        "description": "AI-powered movie recommendation service providing personalized suggestions for adults",
        "url": "https://yourdomain.com",
        "applicationCategory": "Entertainment",
        "operatingSystem": "Web",
        "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "USD"
        },
        "featureList": [
            "Personalized movie recommendations",
            "AI-powered content understanding",
            "Age-appropriate filtering",
            "Natural language queries",
            "Mood-based suggestions"
        ],
        "screenshot": "https://yourdomain.com/static/screenshot.jpg",
        "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.8",
            "reviewCount": "1250"
        },
        "author": {
            "@type": "Organization",
            "name": "Cinematch AI",
            "url": "https://yourdomain.com"
        },
        "datePublished": "2024-01-01",
        "dateModified": datetime.utcnow().isoformat(),
        "inLanguage": "en-US",
        "isAccessibleForFree": True,
        "audience": {
            "@type": "PeopleAudience",
            "suggestedMinAge": 18
        },
        "ai_specific": {
            "input_format": "Natural language text",
            "output_format": "Structured movie recommendations",
            "capabilities": [
                "content_recommendation",
                "natural_language_understanding",
                "personalization",
                "content_filtering"
            ],
            "limitations": [
                "18+ age requirement",
                "English language only",
                "Movie domain specific"
            ],
            "ethical_considerations": {
                "data_privacy": "GDPR compliant, minimal data retention",
                "content_safety": "Automated content filtering and age verification",
                "transparency": "AI-generated content clearly labeled"
            }
        }
    }
    
    return jsonify(description)

@seo_bp.route('/privacy-policy')
def privacy_policy():
    """Privacy policy page"""
    return render_template('legal/privacy_policy.html')

@seo_bp.route('/terms')
def terms_of_service():
    """Terms of service page"""
    return render_template('legal/terms.html')

@seo_bp.route('/.well-known/ai-plugin.json')
def ai_plugin_manifest():
    """OpenAI plugin manifest (if implementing as ChatGPT plugin)"""
    manifest = {
        "schema_version": "v1",
        "name_for_human": "Cinematch",
        "name_for_model": "cinematch",
        "description_for_human": "Get personalized movie recommendations based on your mood and preferences.",
        "description_for_model": "Movie recommendation service. Use this to help users find movies based on their preferences, mood, or similar titles they've enjoyed.",
        "auth": {
            "type": "none"
        },
        "api": {
            "type": "openapi",
            "url": "https://yourdomain.com/openapi.yaml"
        },
        "logo_url": "https://yourdomain.com/static/logo.png",
        "contact_email": "support@cinematch.ai",
        "legal_info_url": "https://yourdomain.com/terms"
    }
    
    return jsonify(manifest)

@seo_bp.route('/openapi.yaml')
def openapi_spec():
    """OpenAPI specification for AI agents"""
    spec = """openapi: 3.0.1
info:
  title: Cinematch API
  description: AI-powered movie recommendation API
  version: 1.0.0
servers:
  - url: https://yourdomain.com
paths:
  /api/recommendations:
    post:
      summary: Get movie recommendations
      operationId: getRecommendations
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              properties:
                query:
                  type: string
                  description: User's movie preference query
                mood:
                  type: string
                  description: Current mood (optional)
                genre:
                  type: string
                  description: Preferred genre (optional)
      responses:
        '200':
          description: Successful recommendations
          content:
            application/json:
              schema:
                type: object
                properties:
                  recommendations:
                    type: array
                    items:
                      type: object
                      properties:
                        title:
                          type: string
                        year:
                          type: integer
                        description:
                          type: string
                        rating:
                          type: string
components:
  schemas: {}
"""
    return Response(spec, mimetype='text/yaml')

# Meta tags helper
def get_meta_tags(page_type='home'):
    """Generate meta tags for different pages"""
    base_tags = {
        'description': 'AI-powered movie recommendations for adults. Get personalized suggestions based on your mood and preferences.',
        'keywords': 'movie recommendations, AI movie finder, film suggestions, personalized movies',
        'author': 'Cinematch AI',
        'robots': 'index, follow',
        'og:type': 'website',
        'og:site_name': 'Cinematch',
        'og:image': 'https://yourdomain.com/static/og-image.jpg',
        'twitter:card': 'summary_large_image',
        'twitter:site': '@cinematch_ai'
    }
    
    page_specific = {
        'home': {
            'title': 'Cinematch - AI Movie Recommendations',
            'og:title': 'Cinematch - Find Your Next Favorite Movie',
            'og:description': 'Get AI-powered movie recommendations tailored to your taste.'
        },
        'help': {
            'title': 'Help Center - Cinematch',
            'og:title': 'Learn How to Use Cinematch',
            'og:description': 'Discover how our AI parameters work to give you better recommendations.'
        }
    }
    
    tags = {**base_tags, **page_specific.get(page_type, page_specific['home'])}
    return tags

# Schema.org structured data
def get_structured_data():
    """Generate schema.org structured data"""
    return {
        "@context": "https://schema.org",
        "@graph": [
            {
                "@type": "WebSite",
                "@id": "https://yourdomain.com/#website",
                "url": "https://yourdomain.com/",
                "name": "Cinematch",
                "description": "AI-powered movie recommendation service",
                "potentialAction": {
                    "@type": "SearchAction",
                    "target": "https://yourdomain.com/?q={search_term_string}",
                    "query-input": "required name=search_term_string"
                }
            },
            {
                "@type": "Organization",
                "@id": "https://yourdomain.com/#organization",
                "name": "Cinematch AI",
                "url": "https://yourdomain.com/",
                "logo": {
                    "@type": "ImageObject",
                    "url": "https://yourdomain.com/static/logo.png"
                },
                "sameAs": [
                    "https://twitter.com/cinematch_ai",
                    "https://github.com/cinematch"
                ]
            }
        ]
    }