# safety_monitor.py - Safety monitoring and compliance system

"""
Real-time safety monitoring system for Cinematch.
Provides violation tracking, compliance reporting, automated responses,
and safety analytics dashboard.
"""

import logging
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from collections import defaultdict, deque
from threading import Lock
from flask import current_app, request
from sqlalchemy import func, and_, or_

logger = logging.getLogger(__name__)

@dataclass
class SafetyEvent:
    """Represents a safety-related event"""
    event_id: str
    user_id: Optional[int]
    session_id: str
    event_type: str  # 'violation', 'warning', 'block', 'escalation'
    severity: str    # 'low', 'medium', 'high', 'critical'
    source: str      # 'content_filter', 'age_verification', 'rate_limiter'
    details: Dict[str, Any]
    timestamp: datetime
    ip_address: Optional[str]
    user_agent: Optional[str]
    resolved: bool = False
    resolution_notes: Optional[str] = None

@dataclass
class SafetyMetrics:
    """Safety metrics for monitoring dashboard"""
    total_events: int
    violations_by_severity: Dict[str, int]
    violations_by_type: Dict[str, int]
    blocked_users: int
    active_warnings: int
    compliance_score: float
    trend_data: Dict[str, List[int]]
    alert_level: str


class SafetyMonitor:
    """Real-time safety monitoring and alerting system"""
    
    def __init__(self):
        self.events_queue = deque(maxlen=10000)  # Ring buffer for recent events
        self.active_sessions = {}  # Track session safety status
        self.user_violations = defaultdict(list)  # Cache recent user violations
        self.metrics_cache = None
        self.metrics_cache_time = None
        self.cache_duration = timedelta(minutes=5)
        self.lock = Lock()
        
        # Alert thresholds
        self.alert_thresholds = {
            'violations_per_minute': 10,
            'critical_violations_per_hour': 5,
            'blocked_users_per_hour': 20,
            'compliance_score_minimum': 0.85
        }
        
        # Auto-response configurations
        self.auto_responses = {
            'critical_violation': {
                'action': 'immediate_block',
                'duration_minutes': 60,
                'escalate': True
            },
            'repeated_violations': {
                'action': 'temporary_restriction',
                'duration_minutes': 30,
                'threshold': 3
            },
            'pii_violation': {
                'action': 'content_block',
                'notify_admin': True
            }
        }
    
    def log_event(self, event: SafetyEvent) -> None:
        """Log a safety event for monitoring"""
        with self.lock:
            # Add to events queue
            self.events_queue.append(event)
            
            # Update user violation cache
            if event.user_id:
                self.user_violations[event.user_id].append(event)
                # Keep only recent violations (last 24 hours)
                cutoff = datetime.utcnow() - timedelta(hours=24)
                self.user_violations[event.user_id] = [
                    e for e in self.user_violations[event.user_id] 
                    if e.timestamp > cutoff
                ]
            
            # Update session status
            if event.event_type in ['violation', 'block']:
                self.active_sessions[event.session_id] = {
                    'status': 'flagged' if event.severity in ['low', 'medium'] else 'blocked',
                    'last_violation': event.timestamp,
                    'severity': event.severity
                }
        
        # Store in database
        self._persist_event(event)
        
        # Check for auto-responses
        self._check_auto_responses(event)
        
        # Check alert thresholds
        self._check_alert_thresholds()
    
    def _persist_event(self, event: SafetyEvent) -> None:
        """Persist event to database"""
        try:
            from models import db, SafetyViolation
            
            # Convert SafetyEvent to database record
            violation = SafetyViolation(
                user_id=event.user_id,
                violation_type=event.event_type,
                content_hash=event.details.get('content_hash', ''),
                severity=event.severity,
                details=event.details,
                ip_address=event.ip_address,
                user_agent=event.user_agent,
                resolved=event.resolved,
                resolution_notes=event.resolution_notes
            )
            
            db.session.add(violation)
            db.session.commit()
            
        except Exception as e:
            logger.error(f"Failed to persist safety event: {e}")
    
    def _check_auto_responses(self, event: SafetyEvent) -> None:
        """Check if automatic responses should be triggered"""
        try:
            # Critical violation immediate response
            if event.severity == 'critical':
                self._trigger_auto_response('critical_violation', event)
            
            # Repeated violations check
            if event.user_id:
                recent_violations = self.user_violations.get(event.user_id, [])
                violation_count = len([e for e in recent_violations if e.timestamp > datetime.utcnow() - timedelta(hours=1)])
                
                if violation_count >= self.auto_responses['repeated_violations']['threshold']:
                    self._trigger_auto_response('repeated_violations', event)
            
            # PII violation special handling
            if event.details.get('pii_detected'):
                self._trigger_auto_response('pii_violation', event)
                
        except Exception as e:
            logger.error(f"Error checking auto-responses: {e}")
    
    def _trigger_auto_response(self, response_type: str, event: SafetyEvent) -> None:
        """Trigger an automatic response to safety violation"""
        try:
            response_config = self.auto_responses.get(response_type)
            if not response_config:
                return
            
            action = response_config['action']
            
            if action == 'immediate_block':
                self._block_user(event.user_id, response_config.get('duration_minutes', 60))
            elif action == 'temporary_restriction':
                self._restrict_user(event.user_id, response_config.get('duration_minutes', 30))
            elif action == 'content_block':
                self._block_content(event.session_id)
            
            # Send notifications
            if response_config.get('escalate') or response_config.get('notify_admin'):
                self._send_alert(f"Auto-response triggered: {response_type}", event)
            
            # Log the response
            response_event = SafetyEvent(
                event_id=f"auto_response_{int(time.time())}",
                user_id=event.user_id,
                session_id=event.session_id,
                event_type='auto_response',
                severity='medium',
                source='safety_monitor',
                details={
                    'response_type': response_type,
                    'action': action,
                    'original_event': event.event_id
                },
                timestamp=datetime.utcnow(),
                ip_address=event.ip_address,
                user_agent=event.user_agent
            )
            
            self.log_event(response_event)
            
        except Exception as e:
            logger.error(f"Error triggering auto-response: {e}")
    
    def _block_user(self, user_id: int, duration_minutes: int) -> None:
        """Temporarily block a user"""
        try:
            from models import db, User
            
            user = User.query.get(user_id)
            if user:
                user.blocked_until = datetime.utcnow() + timedelta(minutes=duration_minutes)
                user.block_reason = f"Automatic safety block - {duration_minutes} minutes"
                db.session.commit()
                
                logger.warning(f"User {user_id} automatically blocked for {duration_minutes} minutes")
                
        except Exception as e:
            logger.error(f"Error blocking user {user_id}: {e}")
    
    def _restrict_user(self, user_id: int, duration_minutes: int) -> None:
        """Apply temporary restrictions to a user"""
        try:
            # Add user to restricted list in cache/database
            restriction_key = f"user_restricted:{user_id}"
            # This would integrate with your caching system (Redis)
            # cache.setex(restriction_key, duration_minutes * 60, "safety_restriction")
            
            logger.info(f"User {user_id} temporarily restricted for {duration_minutes} minutes")
            
        except Exception as e:
            logger.error(f"Error restricting user {user_id}: {e}")
    
    def _block_content(self, session_id: str) -> None:
        """Block content for a specific session"""
        try:
            self.active_sessions[session_id] = {
                'status': 'content_blocked',
                'blocked_at': datetime.utcnow(),
                'reason': 'safety_violation'
            }
            
            logger.info(f"Content blocked for session {session_id}")
            
        except Exception as e:
            logger.error(f"Error blocking content for session {session_id}: {e}")
    
    def _check_alert_thresholds(self) -> None:
        """Check if any alert thresholds have been exceeded"""
        try:
            now = datetime.utcnow()
            
            # Count violations in the last minute
            recent_events = [e for e in self.events_queue if e.timestamp > now - timedelta(minutes=1)]
            violations_per_minute = len([e for e in recent_events if e.event_type == 'violation'])
            
            if violations_per_minute >= self.alert_thresholds['violations_per_minute']:
                self._send_alert(f"High violation rate: {violations_per_minute}/minute", None)
            
            # Count critical violations in the last hour
            hour_ago = now - timedelta(hours=1)
            recent_critical = [e for e in self.events_queue 
                             if e.timestamp > hour_ago and e.severity == 'critical']
            
            if len(recent_critical) >= self.alert_thresholds['critical_violations_per_hour']:
                self._send_alert(f"Critical violation threshold exceeded: {len(recent_critical)}/hour", None)
            
        except Exception as e:
            logger.error(f"Error checking alert thresholds: {e}")
    
    def _send_alert(self, message: str, event: Optional[SafetyEvent]) -> None:
        """Send alert notification to administrators"""
        try:
            alert_data = {
                'message': message,
                'timestamp': datetime.utcnow().isoformat(),
                'severity': 'high',
                'event_details': asdict(event) if event else None
            }
            
            # Log alert
            logger.critical(f"SAFETY ALERT: {message}")
            
            # Here you would integrate with your notification system
            # - Send email to admins
            # - Post to Slack/Discord
            # - SMS alerts for critical issues
            # - Dashboard notifications
            
            # For now, just log to a special alert log
            alert_logger = logging.getLogger('safety_alerts')
            alert_logger.critical(json.dumps(alert_data))
            
        except Exception as e:
            logger.error(f"Error sending alert: {e}")
    
    def get_user_safety_status(self, user_id: int) -> Dict[str, Any]:
        """Get comprehensive safety status for a user"""
        try:
            recent_violations = self.user_violations.get(user_id, [])
            
            # Calculate risk score
            risk_score = 0
            for violation in recent_violations:
                if violation.severity == 'critical':
                    risk_score += 10
                elif violation.severity == 'high':
                    risk_score += 5
                elif violation.severity == 'medium':
                    risk_score += 2
                else:
                    risk_score += 1
            
            # Determine status
            if risk_score >= 20:
                status = 'high_risk'
            elif risk_score >= 10:
                status = 'medium_risk'
            elif risk_score >= 5:
                status = 'low_risk'
            else:
                status = 'good_standing'
            
            return {
                'user_id': user_id,
                'status': status,
                'risk_score': risk_score,
                'recent_violations': len(recent_violations),
                'last_violation': recent_violations[-1].timestamp.isoformat() if recent_violations else None,
                'violations_by_severity': {
                    'critical': len([v for v in recent_violations if v.severity == 'critical']),
                    'high': len([v for v in recent_violations if v.severity == 'high']),
                    'medium': len([v for v in recent_violations if v.severity == 'medium']),
                    'low': len([v for v in recent_violations if v.severity == 'low'])
                }
            }
            
        except Exception as e:
            logger.error(f"Error getting user safety status: {e}")
            return {'error': str(e), 'status': 'unknown'}
    
    def get_session_safety_status(self, session_id: str) -> Dict[str, Any]:
        """Get safety status for a specific session"""
        session_info = self.active_sessions.get(session_id, {'status': 'clean'})
        
        # Add recent events for this session
        session_events = [e for e in self.events_queue if e.session_id == session_id]
        recent_events = [e for e in session_events if e.timestamp > datetime.utcnow() - timedelta(hours=1)]
        
        return {
            'session_id': session_id,
            'status': session_info.get('status', 'clean'),
            'recent_events': len(recent_events),
            'last_activity': session_info.get('last_violation'),
            'event_types': list(set(e.event_type for e in recent_events))
        }
    
    def get_safety_metrics(self, hours: int = 24) -> SafetyMetrics:
        """Get comprehensive safety metrics for dashboard"""
        # Check cache first
        if (self.metrics_cache and self.metrics_cache_time and 
            datetime.utcnow() - self.metrics_cache_time < self.cache_duration):
            return self.metrics_cache
        
        try:
            cutoff = datetime.utcnow() - timedelta(hours=hours)
            
            # Get events from database for comprehensive metrics
            from models import SafetyViolation, User, db
            
            violations = db.session.query(SafetyViolation).filter(
                SafetyViolation.created_at >= cutoff
            ).all()
            
            # Count violations by severity
            violations_by_severity = defaultdict(int)
            violations_by_type = defaultdict(int)
            
            for violation in violations:
                violations_by_severity[violation.severity] += 1
                violations_by_type[violation.violation_type] += 1
            
            # Count blocked users
            blocked_users = db.session.query(User).filter(
                User.blocked_until.isnot(None),
                User.blocked_until > datetime.utcnow()
            ).count()
            
            # Calculate compliance score
            total_events = len(violations)
            critical_violations = violations_by_severity['critical']
            high_violations = violations_by_severity['high']
            
            if total_events == 0:
                compliance_score = 1.0
            else:
                # Score based on severity distribution
                severity_penalty = (critical_violations * 0.3 + high_violations * 0.1) / total_events
                compliance_score = max(0.0, 1.0 - severity_penalty)
            
            # Generate trend data (hourly buckets)
            trend_data = self._generate_trend_data(violations, hours)
            
            # Determine alert level
            alert_level = 'green'
            if critical_violations > 0 or compliance_score < 0.8:
                alert_level = 'red'
            elif high_violations > 5 or compliance_score < 0.9:
                alert_level = 'yellow'
            
            metrics = SafetyMetrics(
                total_events=total_events,
                violations_by_severity=dict(violations_by_severity),
                violations_by_type=dict(violations_by_type),
                blocked_users=blocked_users,
                active_warnings=len([v for v in violations if v.severity in ['medium', 'high']]),
                compliance_score=compliance_score,
                trend_data=trend_data,
                alert_level=alert_level
            )
            
            # Cache the results
            self.metrics_cache = metrics
            self.metrics_cache_time = datetime.utcnow()
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error generating safety metrics: {e}")
            return SafetyMetrics(
                total_events=0,
                violations_by_severity={},
                violations_by_type={},
                blocked_users=0,
                active_warnings=0,
                compliance_score=0.0,
                trend_data={},
                alert_level='unknown'
            )
    
    def _generate_trend_data(self, violations: List, hours: int) -> Dict[str, List[int]]:
        """Generate hourly trend data for violations"""
        try:
            now = datetime.utcnow()
            hourly_counts = defaultdict(lambda: defaultdict(int))
            
            for violation in violations:
                hour_bucket = violation.created_at.replace(minute=0, second=0, microsecond=0)
                hourly_counts[hour_bucket][violation.severity] += 1
            
            # Create time series data
            trend_data = {
                'timestamps': [],
                'critical': [],
                'high': [],
                'medium': [],
                'low': [],
                'total': []
            }
            
            for i in range(hours):
                hour = now - timedelta(hours=i)
                hour_bucket = hour.replace(minute=0, second=0, microsecond=0)
                
                trend_data['timestamps'].insert(0, hour_bucket.isoformat())
                
                counts = hourly_counts[hour_bucket]
                trend_data['critical'].insert(0, counts['critical'])
                trend_data['high'].insert(0, counts['high'])
                trend_data['medium'].insert(0, counts['medium'])
                trend_data['low'].insert(0, counts['low'])
                trend_data['total'].insert(0, sum(counts.values()))
            
            return trend_data
            
        except Exception as e:
            logger.error(f"Error generating trend data: {e}")
            return {}
    
    def get_compliance_report(self, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Generate comprehensive compliance report"""
        try:
            from models import SafetyViolation, User, db
            
            violations = db.session.query(SafetyViolation).filter(
                and_(
                    SafetyViolation.created_at >= start_date,
                    SafetyViolation.created_at <= end_date
                )
            ).all()
            
            report = {
                'period': {
                    'start': start_date.isoformat(),
                    'end': end_date.isoformat(),
                    'days': (end_date - start_date).days
                },
                'summary': {
                    'total_violations': len(violations),
                    'unique_users': len(set(v.user_id for v in violations if v.user_id)),
                    'violations_by_severity': defaultdict(int),
                    'violations_by_type': defaultdict(int),
                    'average_per_day': len(violations) / max((end_date - start_date).days, 1)
                },
                'top_violation_types': [],
                'repeat_offenders': [],
                'resolution_rate': 0.0,
                'compliance_score': 0.0
            }
            
            # Process violations
            for violation in violations:
                report['summary']['violations_by_severity'][violation.severity] += 1
                report['summary']['violations_by_type'][violation.violation_type] += 1
            
            # Convert defaultdicts to regular dicts
            report['summary']['violations_by_severity'] = dict(report['summary']['violations_by_severity'])
            report['summary']['violations_by_type'] = dict(report['summary']['violations_by_type'])
            
            # Top violation types
            violation_types = report['summary']['violations_by_type']
            report['top_violation_types'] = sorted(
                violation_types.items(), 
                key=lambda x: x[1], 
                reverse=True
            )[:10]
            
            # Find repeat offenders
            user_violation_counts = defaultdict(int)
            for violation in violations:
                if violation.user_id:
                    user_violation_counts[violation.user_id] += 1
            
            report['repeat_offenders'] = sorted(
                [(user_id, count) for user_id, count in user_violation_counts.items() if count > 1],
                key=lambda x: x[1],
                reverse=True
            )[:10]
            
            # Calculate resolution rate
            resolved_violations = len([v for v in violations if v.resolved])
            if violations:
                report['resolution_rate'] = resolved_violations / len(violations)
            
            # Calculate compliance score
            total_violations = len(violations)
            critical_violations = report['summary']['violations_by_severity'].get('critical', 0)
            high_violations = report['summary']['violations_by_severity'].get('high', 0)
            
            if total_violations == 0:
                report['compliance_score'] = 1.0
            else:
                severity_penalty = (critical_violations * 0.4 + high_violations * 0.2) / total_violations
                report['compliance_score'] = max(0.0, 1.0 - severity_penalty)
            
            return report
            
        except Exception as e:
            logger.error(f"Error generating compliance report: {e}")
            return {'error': str(e)}


# Global safety monitor instance
safety_monitor = SafetyMonitor()

def log_safety_event(event_type: str, severity: str, source: str, 
                    details: Dict[str, Any], user_id: Optional[int] = None,
                    session_id: Optional[str] = None) -> None:
    """Convenience function to log safety events"""
    try:
        # Generate event ID
        event_id = f"{source}_{event_type}_{int(time.time() * 1000)}"
        
        # Get session ID from Flask context if not provided
        if not session_id and request:
            session_id = request.cookies.get('session_id', 'anonymous')
        
        # Get request info if available
        ip_address = request.remote_addr if request else None
        user_agent = request.headers.get('User-Agent') if request else None
        
        event = SafetyEvent(
            event_id=event_id,
            user_id=user_id,
            session_id=session_id or 'unknown',
            event_type=event_type,
            severity=severity,
            source=source,
            details=details,
            timestamp=datetime.utcnow(),
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        safety_monitor.log_event(event)
        
    except Exception as e:
        logger.error(f"Error logging safety event: {e}")

def get_safety_dashboard_data() -> Dict[str, Any]:
    """Get comprehensive data for safety monitoring dashboard"""
    try:
        metrics = safety_monitor.get_safety_metrics(24)
        
        return {
            'metrics': asdict(metrics),
            'active_alerts': _get_active_alerts(),
            'recent_events': _get_recent_events(50),
            'system_status': _get_system_status()
        }
        
    except Exception as e:
        logger.error(f"Error getting dashboard data: {e}")
        return {'error': str(e)}

def _get_active_alerts() -> List[Dict[str, Any]]:
    """Get current active alerts"""
    # This would query your alerting system
    return []

def _get_recent_events(limit: int) -> List[Dict[str, Any]]:
    """Get recent safety events"""
    try:
        recent_events = list(safety_monitor.events_queue)[-limit:]
        return [asdict(event) for event in recent_events]
    except Exception as e:
        logger.error(f"Error getting recent events: {e}")
        return []

def _get_system_status() -> Dict[str, Any]:
    """Get overall system safety status"""
    try:
        metrics = safety_monitor.get_safety_metrics(1)  # Last hour
        
        status = 'healthy'
        if metrics.alert_level == 'red':
            status = 'critical'
        elif metrics.alert_level == 'yellow':
            status = 'warning'
        
        return {
            'status': status,
            'compliance_score': metrics.compliance_score,
            'active_monitors': ['content_filter', 'age_verification', 'rate_limiter'],
            'uptime': '99.9%',  # This would come from your monitoring system
            'last_updated': datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting system status: {e}")
        return {'status': 'unknown', 'error': str(e)}