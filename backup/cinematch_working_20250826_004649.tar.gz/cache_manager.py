# cache_manager.py - Replace Redis with PostgreSQL-based caching

import json
import pickle
from datetime import datetime, timedelta
from typing import Any, Optional, Union
import hashlib
from flask import current_app
from sqlalchemy import text

class PostgreSQLCache:
    """Redis-compatible cache using PostgreSQL"""
    
    def __init__(self, db):
        self.db = db
        self._ensure_cache_table()
    
    def _ensure_cache_table(self):
        """Create cache table if it doesn't exist"""
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS cache_store (
            key VARCHAR(255) PRIMARY KEY,
            value TEXT NOT NULL,
            expires_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            value_type VARCHAR(20) DEFAULT 'string'
        );
        
        CREATE INDEX IF NOT EXISTS idx_cache_expires ON cache_store(expires_at);
        """
        
        with current_app.app_context():
            self.db.session.execute(text(create_table_sql))
            self.db.session.commit()
    
    def _clean_expired(self):
        """Remove expired keys"""
        delete_sql = "DELETE FROM cache_store WHERE expires_at IS NOT NULL AND expires_at < :now"
        self.db.session.execute(text(delete_sql), {'now': datetime.utcnow()})
        self.db.session.commit()
    
    def set(self, key: str, value: Any, ex: Optional[int] = None) -> bool:
        """Set a key with optional expiration (seconds)"""
        try:
            # Clean expired entries periodically
            if hash(key) % 100 == 0:  # 1% chance to clean
                self._clean_expired()
            
            # Serialize value
            if isinstance(value, (str, int, float)):
                serialized = str(value)
                value_type = 'string'
            else:
                serialized = pickle.dumps(value).hex()
                value_type = 'pickle'
            
            expires_at = None
            if ex:
                expires_at = datetime.utcnow() + timedelta(seconds=ex)
            
            # Upsert
            upsert_sql = """
            INSERT INTO cache_store (key, value, expires_at, value_type) 
            VALUES (:key, :value, :expires_at, :value_type)
            ON CONFLICT (key) 
            DO UPDATE SET 
                value = :value,
                expires_at = :expires_at,
                value_type = :value_type,
                created_at = CURRENT_TIMESTAMP
            """
            
            self.db.session.execute(text(upsert_sql), {
                'key': key,
                'value': serialized,
                'expires_at': expires_at,
                'value_type': value_type
            })
            self.db.session.commit()
            return True
        except Exception as e:
            self.db.session.rollback()
            current_app.logger.error(f"Cache set error: {e}")
            return False
    
    def get(self, key: str) -> Optional[Any]:
        """Get a value by key"""
        try:
            # Check if exists and not expired
            select_sql = """
            SELECT value, value_type FROM cache_store 
            WHERE key = :key 
            AND (expires_at IS NULL OR expires_at > :now)
            """
            
            result = self.db.session.execute(
                text(select_sql), 
                {'key': key, 'now': datetime.utcnow()}
            ).first()
            
            if not result:
                return None
            
            value, value_type = result
            
            # Deserialize
            if value_type == 'pickle':
                return pickle.loads(bytes.fromhex(value))
            else:
                return value
                
        except Exception as e:
            current_app.logger.error(f"Cache get error: {e}")
            return None
    
    def delete(self, key: str) -> bool:
        """Delete a key"""
        try:
            delete_sql = "DELETE FROM cache_store WHERE key = :key"
            self.db.session.execute(text(delete_sql), {'key': key})
            self.db.session.commit()
            return True
        except Exception as e:
            self.db.session.rollback()
            return False
    
    def exists(self, key: str) -> bool:
        """Check if key exists and not expired"""
        try:
            check_sql = """
            SELECT 1 FROM cache_store 
            WHERE key = :key 
            AND (expires_at IS NULL OR expires_at > :now)
            LIMIT 1
            """
            
            result = self.db.session.execute(
                text(check_sql), 
                {'key': key, 'now': datetime.utcnow()}
            ).first()
            
            return result is not None
        except Exception:
            return False
    
    def setex(self, key: str, seconds: int, value: Any) -> bool:
        """Set with expiration (Redis compatibility)"""
        return self.set(key, value, ex=seconds)
    
    def ttl(self, key: str) -> int:
        """Get time to live in seconds"""
        try:
            ttl_sql = """
            SELECT EXTRACT(EPOCH FROM (expires_at - CURRENT_TIMESTAMP))::INTEGER 
            FROM cache_store 
            WHERE key = :key AND expires_at > CURRENT_TIMESTAMP
            """
            
            result = self.db.session.execute(text(ttl_sql), {'key': key}).scalar()
            return result if result else -1
        except Exception:
            return -1
    
    def incr(self, key: str) -> int:
        """Increment a counter"""
        try:
            # Use PostgreSQL's atomic increment
            incr_sql = """
            INSERT INTO cache_store (key, value, value_type) 
            VALUES (:key, '1', 'string')
            ON CONFLICT (key) 
            DO UPDATE SET value = (cache_store.value::INTEGER + 1)::TEXT
            RETURNING value::INTEGER
            """
            
            result = self.db.session.execute(text(incr_sql), {'key': key}).scalar()
            self.db.session.commit()
            return result
        except Exception as e:
            self.db.session.rollback()
            current_app.logger.error(f"Cache incr error: {e}")
            return 0
    
    def hset(self, name: str, key: str, value: Any) -> bool:
        """Hash set (Redis compatibility)"""
        hash_key = f"hash:{name}:{key}"
        return self.set(hash_key, value)
    
    def hget(self, name: str, key: str) -> Optional[Any]:
        """Hash get (Redis compatibility)"""
        hash_key = f"hash:{name}:{key}"
        return self.get(hash_key)
    
    def hgetall(self, name: str) -> dict:
        """Get all hash values"""
        try:
            pattern_sql = """
            SELECT key, value, value_type FROM cache_store 
            WHERE key LIKE :pattern 
            AND (expires_at IS NULL OR expires_at > :now)
            """
            
            results = self.db.session.execute(
                text(pattern_sql), 
                {'pattern': f'hash:{name}:%', 'now': datetime.utcnow()}
            ).fetchall()
            
            hash_dict = {}
            for key, value, value_type in results:
                # Extract the hash field from the key
                field = key.replace(f'hash:{name}:', '')
                
                # Deserialize value
                if value_type == 'pickle':
                    hash_dict[field] = pickle.loads(bytes.fromhex(value))
                else:
                    hash_dict[field] = value
            
            return hash_dict
        except Exception as e:
            current_app.logger.error(f"Cache hgetall error: {e}")
            return {}


# Session storage using PostgreSQL
class PostgreSQLSessionStore:
    """Session storage that replaces Redis sessions"""
    
    def __init__(self, db):
        self.db = db
        self._ensure_session_table()
    
    def _ensure_session_table(self):
        """Create session table if it doesn't exist"""
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS flask_sessions (
            session_id VARCHAR(255) PRIMARY KEY,
            data TEXT NOT NULL,
            expiry TIMESTAMP NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE INDEX IF NOT EXISTS idx_session_expiry ON flask_sessions(expiry);
        """
        
        with current_app.app_context():
            self.db.session.execute(text(create_table_sql))
            self.db.session.commit()
    
    def save_session(self, session_id: str, data: dict, expiry: timedelta) -> bool:
        """Save session data"""
        try:
            expires_at = datetime.utcnow() + expiry
            serialized = json.dumps(data)
            
            upsert_sql = """
            INSERT INTO flask_sessions (session_id, data, expiry) 
            VALUES (:session_id, :data, :expiry)
            ON CONFLICT (session_id) 
            DO UPDATE SET 
                data = :data,
                expiry = :expiry
            """
            
            self.db.session.execute(text(upsert_sql), {
                'session_id': session_id,
                'data': serialized,
                'expiry': expires_at
            })
            self.db.session.commit()
            return True
        except Exception as e:
            self.db.session.rollback()
            current_app.logger.error(f"Session save error: {e}")
            return False
    
    def get_session(self, session_id: str) -> Optional[dict]:
        """Get session data"""
        try:
            select_sql = """
            SELECT data FROM flask_sessions 
            WHERE session_id = :session_id AND expiry > :now
            """
            
            result = self.db.session.execute(
                text(select_sql), 
                {'session_id': session_id, 'now': datetime.utcnow()}
            ).scalar()
            
            if result:
                return json.loads(result)
            return None
        except Exception as e:
            current_app.logger.error(f"Session get error: {e}")
            return None
    
    def delete_session(self, session_id: str) -> bool:
        """Delete session"""
        try:
            delete_sql = "DELETE FROM flask_sessions WHERE session_id = :session_id"
            self.db.session.execute(text(delete_sql), {'session_id': session_id})
            self.db.session.commit()
            return True
        except Exception:
            self.db.session.rollback()
            return False
    
    def cleanup_expired(self):
        """Remove expired sessions"""
        try:
            delete_sql = "DELETE FROM flask_sessions WHERE expiry < :now"
            self.db.session.execute(text(delete_sql), {'now': datetime.utcnow()})
            self.db.session.commit()
        except Exception:
            self.db.session.rollback()


# Rate limiter storage using PostgreSQL
class PostgreSQLRateLimitStorage:
    """Rate limit storage for Flask-Limiter"""
    
    def __init__(self, db):
        self.db = db
        self.cache = PostgreSQLCache(db)
    
    def incr(self, key: str, expiry: int, elastic_expiry: bool = False) -> int:
        """Increment the counter for a given rate limit key"""
        count = self.cache.incr(f"rl:{key}")
        if count == 1:  # First increment, set expiry
            self.cache.setex(f"rl:{key}", expiry, count)
        return count
    
    def get(self, key: str) -> int:
        """Get the current counter for a given rate limit key"""
        value = self.cache.get(f"rl:{key}")
        return int(value) if value else 0
    
    def get_expiry(self, key: str) -> int:
        """Get expiry for a given key"""
        return self.cache.ttl(f"rl:{key}")
    
    def check(self) -> bool:
        """Check if storage is available"""
        try:
            self.cache.set("_limiter_check", "1", ex=1)
            return True
        except Exception:
            return False