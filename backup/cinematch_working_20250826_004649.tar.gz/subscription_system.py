# subscription_system.py - Subscription management with Stripe integration

import os
import stripe
import logging
from datetime import datetime, timedelta
from decimal import Decimal
from flask import current_app, request, jsonify, session
from flask_login import current_user
from functools import wraps

from models import db, User, UserSubscription, UsageTracking, PaymentMethod, SubscriptionEvent, RateLimitLog

# Configure Stripe
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY')

logger = logging.getLogger(__name__)

class SubscriptionManager:
    """Centralized subscription management"""
    
    # Stripe Price IDs (set these in your environment)
    STRIPE_PRICES = {
        'basic_monthly': os.environ.get('STRIPE_BASIC_MONTHLY_PRICE_ID'),
        'premium_monthly': os.environ.get('STRIPE_PREMIUM_MONTHLY_PRICE_ID'),
        'basic_yearly': os.environ.get('STRIPE_BASIC_YEARLY_PRICE_ID'),
        'premium_yearly': os.environ.get('STRIPE_PREMIUM_YEARLY_PRICE_ID'),
    }
    
    @classmethod
    def create_customer(cls, user):
        """Create a Stripe customer for the user"""
        try:
            customer = stripe.Customer.create(
                email=user.email,
                name=user.username,
                metadata={'user_id': str(user.id)}
            )
            
            # Create or update subscription record
            subscription = user.subscription
            if not subscription:
                subscription = UserSubscription(user_id=user.id)
                db.session.add(subscription)
            
            subscription.stripe_customer_id = customer.id
            db.session.commit()
            
            return customer
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error creating customer: {e}")
            raise
    
    @classmethod
    def create_checkout_session(cls, user, price_id, success_url, cancel_url):
        """Create a Stripe Checkout session for subscription"""
        try:
            # Ensure user has a Stripe customer ID
            if not user.subscription or not user.subscription.stripe_customer_id:
                cls.create_customer(user)
            
            customer_id = user.subscription.stripe_customer_id
            
            checkout_session = stripe.checkout.Session.create(
                customer=customer_id,
                payment_method_types=['card'],
                line_items=[{
                    'price': price_id,
                    'quantity': 1,
                }],
                mode='subscription',
                success_url=success_url,
                cancel_url=cancel_url,
                allow_promotion_codes=True,
                billing_address_collection='required',
                metadata={
                    'user_id': str(user.id)
                }
            )
            
            return checkout_session
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error creating checkout session: {e}")
            raise
    
    @classmethod
    def create_portal_session(cls, user, return_url):
        """Create a Stripe Customer Portal session"""
        try:
            if not user.subscription or not user.subscription.stripe_customer_id:
                raise ValueError("User has no Stripe customer ID")
            
            portal_session = stripe.billing_portal.Session.create(
                customer=user.subscription.stripe_customer_id,
                return_url=return_url
            )
            
            return portal_session
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error creating portal session: {e}")
            raise
    
    @classmethod
    def handle_subscription_created(cls, subscription_data):
        """Handle subscription.created webhook"""
        try:
            stripe_customer_id = subscription_data['customer']
            stripe_subscription_id = subscription_data['id']
            
            # Find user by customer ID
            user_subscription = UserSubscription.query.filter_by(
                stripe_customer_id=stripe_customer_id
            ).first()
            
            if not user_subscription:
                logger.error(f"No user found for customer {stripe_customer_id}")
                return False
            
            # Update subscription details
            user_subscription.stripe_subscription_id = stripe_subscription_id
            user_subscription.stripe_price_id = subscription_data['items']['data'][0]['price']['id']
            user_subscription.status = subscription_data['status']
            user_subscription.current_period_start = datetime.fromtimestamp(
                subscription_data['current_period_start']
            )
            user_subscription.current_period_end = datetime.fromtimestamp(
                subscription_data['current_period_end']
            )
            
            # Determine tier from price ID
            price_id = user_subscription.stripe_price_id
            if price_id in [cls.STRIPE_PRICES['basic_monthly'], cls.STRIPE_PRICES['basic_yearly']]:
                user_subscription.tier = 'basic'
            elif price_id in [cls.STRIPE_PRICES['premium_monthly'], cls.STRIPE_PRICES['premium_yearly']]:
                user_subscription.tier = 'premium'
            
            # Handle trial
            if subscription_data.get('trial_start'):
                user_subscription.trial_start = datetime.fromtimestamp(
                    subscription_data['trial_start']
                )
            if subscription_data.get('trial_end'):
                user_subscription.trial_end = datetime.fromtimestamp(
                    subscription_data['trial_end']
                )
            
            db.session.commit()
            logger.info(f"Updated subscription for user {user_subscription.user_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error handling subscription created: {e}")
            db.session.rollback()
            return False
    
    @classmethod
    def handle_subscription_updated(cls, subscription_data):
        """Handle subscription.updated webhook"""
        try:
            stripe_subscription_id = subscription_data['id']
            
            user_subscription = UserSubscription.query.filter_by(
                stripe_subscription_id=stripe_subscription_id
            ).first()
            
            if not user_subscription:
                logger.error(f"No subscription found for {stripe_subscription_id}")
                return False
            
            # Update subscription status and details
            user_subscription.status = subscription_data['status']
            user_subscription.current_period_start = datetime.fromtimestamp(
                subscription_data['current_period_start']
            )
            user_subscription.current_period_end = datetime.fromtimestamp(
                subscription_data['current_period_end']
            )
            user_subscription.cancel_at_period_end = subscription_data.get('cancel_at_period_end', False)
            
            if subscription_data.get('canceled_at'):
                user_subscription.cancelled_at = datetime.fromtimestamp(
                    subscription_data['canceled_at']
                )
            
            # Handle tier changes
            new_price_id = subscription_data['items']['data'][0]['price']['id']
            if new_price_id != user_subscription.stripe_price_id:
                user_subscription.stripe_price_id = new_price_id
                if new_price_id in [cls.STRIPE_PRICES['basic_monthly'], cls.STRIPE_PRICES['basic_yearly']]:
                    user_subscription.tier = 'basic'
                elif new_price_id in [cls.STRIPE_PRICES['premium_monthly'], cls.STRIPE_PRICES['premium_yearly']]:
                    user_subscription.tier = 'premium'
            
            db.session.commit()
            logger.info(f"Updated subscription for user {user_subscription.user_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error handling subscription updated: {e}")
            db.session.rollback()
            return False
    
    @classmethod
    def handle_subscription_deleted(cls, subscription_data):
        """Handle subscription.deleted webhook"""
        try:
            stripe_subscription_id = subscription_data['id']
            
            user_subscription = UserSubscription.query.filter_by(
                stripe_subscription_id=stripe_subscription_id
            ).first()
            
            if not user_subscription:
                logger.error(f"No subscription found for {stripe_subscription_id}")
                return False
            
            # Revert to free tier
            user_subscription.tier = 'free'
            user_subscription.status = 'cancelled'
            user_subscription.cancelled_at = datetime.utcnow()
            
            db.session.commit()
            logger.info(f"Cancelled subscription for user {user_subscription.user_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error handling subscription deleted: {e}")
            db.session.rollback()
            return False
    
    @classmethod
    def handle_invoice_payment_failed(cls, invoice_data):
        """Handle invoice.payment_failed webhook"""
        try:
            stripe_customer_id = invoice_data['customer']
            
            user_subscription = UserSubscription.query.filter_by(
                stripe_customer_id=stripe_customer_id
            ).first()
            
            if not user_subscription:
                logger.error(f"No user found for customer {stripe_customer_id}")
                return False
            
            # Update status to past_due
            user_subscription.status = 'past_due'
            db.session.commit()
            
            # TODO: Send notification email to user
            logger.warning(f"Payment failed for user {user_subscription.user_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error handling invoice payment failed: {e}")
            db.session.rollback()
            return False


class RateLimiter:
    """Handle tier-based rate limiting"""
    
    @staticmethod
    def check_rate_limit(user, endpoint='general'):
        """Check if user has exceeded their rate limit"""
        if not user.is_authenticated:
            return False, "Authentication required"
        
        # Get user's current tier and limits
        tier = user.current_tier
        rate_limit = user.get_rate_limit()
        
        # Premium users have unlimited access
        if tier == 'premium':
            return True, "Unlimited access"
        
        # Check daily usage
        daily_usage = user.get_daily_usage()
        
        if daily_usage >= rate_limit:
            # Log the rate limit hit
            RateLimitLog(
                user_id=user.id,
                ip_address=request.remote_addr if request else None,
                endpoint=endpoint,
                user_tier=tier,
                rate_limit=rate_limit,
                current_usage=daily_usage,
                user_agent=request.headers.get('User-Agent') if request else None,
                referer=request.headers.get('Referer') if request else None
            ).save()
            
            return False, f"Daily limit exceeded. Limit: {rate_limit}, Used: {daily_usage}"
        
        return True, f"Usage: {daily_usage}/{rate_limit}"
    
    @staticmethod
    def increment_usage(user, query_type='basic', agents=None, tokens=0, cost=0.0):
        """Increment user's usage count"""
        if user.is_authenticated:
            return UsageTracking.increment_usage(
                user_id=user.id,
                query_type=query_type,
                agents=agents,
                tokens=tokens,
                cost=cost
            )
        return None


# Decorators for route protection

def subscription_required(min_tier='free'):
    """Decorator to require minimum subscription tier"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                return jsonify({'error': 'Authentication required'}), 401
            
            tier_hierarchy = {'free': 0, 'basic': 1, 'premium': 2}
            user_tier_level = tier_hierarchy.get(current_user.current_tier, 0)
            required_tier_level = tier_hierarchy.get(min_tier, 0)
            
            if user_tier_level < required_tier_level:
                return jsonify({
                    'error': 'Subscription upgrade required',
                    'required_tier': min_tier,
                    'current_tier': current_user.current_tier
                }), 402
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def rate_limit_required(endpoint='general'):
    """Decorator to enforce rate limiting"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                return jsonify({'error': 'Authentication required'}), 401
            
            # Check rate limit
            allowed, message = RateLimiter.check_rate_limit(current_user, endpoint)
            
            if not allowed:
                return jsonify({
                    'error': 'Rate limit exceeded',
                    'message': message,
                    'current_tier': current_user.current_tier,
                    'upgrade_url': '/subscription/upgrade'
                }), 429
            
            # Execute the function
            result = f(*args, **kwargs)
            
            # Increment usage after successful execution
            RateLimiter.increment_usage(current_user)
            
            return result
        return decorated_function
    return decorator


def subscription_rate_limit(endpoint='general'):
    """Combined decorator for subscription and rate limiting"""
    def decorator(f):
        @wraps(f)
        @rate_limit_required(endpoint)
        def decorated_function(*args, **kwargs):
            return f(*args, **kwargs)
        return decorated_function
    return decorator


class UsageAnalytics:
    """Analytics for usage tracking"""
    
    @staticmethod
    def get_user_usage_stats(user_id, days=30):
        """Get usage statistics for a user"""
        from sqlalchemy import func
        from datetime import date
        
        start_date = date.today() - timedelta(days=days)
        
        stats = db.session.query(
            func.sum(UsageTracking.query_count).label('total_queries'),
            func.sum(UsageTracking.total_tokens).label('total_tokens'),
            func.sum(UsageTracking.total_cost).label('total_cost'),
            func.avg(UsageTracking.query_count).label('avg_daily_queries'),
            func.count(UsageTracking.id).label('active_days')
        ).filter(
            UsageTracking.user_id == user_id,
            UsageTracking.query_date >= start_date
        ).first()
        
        return {
            'total_queries': stats.total_queries or 0,
            'total_tokens': stats.total_tokens or 0,
            'total_cost': float(stats.total_cost or 0),
            'avg_daily_queries': float(stats.avg_daily_queries or 0),
            'active_days': stats.active_days or 0,
            'period_days': days
        }
    
    @staticmethod
    def get_tier_usage_distribution():
        """Get usage distribution by tier"""
        from sqlalchemy import func
        
        result = db.session.query(
            UserSubscription.tier,
            func.count(User.id).label('user_count'),
            func.sum(UsageTracking.query_count).label('total_queries')
        ).join(User).join(UsageTracking).group_by(UserSubscription.tier).all()
        
        return [
            {
                'tier': row.tier,
                'user_count': row.user_count,
                'total_queries': row.total_queries or 0
            }
            for row in result
        ]
    
    @staticmethod
    def predict_usage_trend(user_id, days_ahead=7):
        """Simple usage prediction based on historical data"""
        from sqlalchemy import func
        from datetime import date
        
        # Get last 30 days of usage
        start_date = date.today() - timedelta(days=30)
        
        usage_data = db.session.query(
            UsageTracking.query_date,
            UsageTracking.query_count
        ).filter(
            UsageTracking.user_id == user_id,
            UsageTracking.query_date >= start_date
        ).order_by(UsageTracking.query_date).all()
        
        if not usage_data:
            return {'prediction': 'insufficient_data'}
        
        # Simple moving average prediction
        recent_usage = [row.query_count for row in usage_data[-7:]]
        avg_usage = sum(recent_usage) / len(recent_usage)
        
        predicted_usage = avg_usage * days_ahead
        
        return {
            'predicted_queries': int(predicted_usage),
            'daily_average': avg_usage,
            'confidence': 'low' if len(usage_data) < 7 else 'medium',
            'recommendation': 'upgrade' if predicted_usage > 80 else 'current_tier'
        }


# Utility functions

def get_subscription_features(tier):
    """Get features for a subscription tier"""
    subscription = UserSubscription()
    subscription.tier = tier
    return subscription.get_tier_features()


def format_currency(amount, currency='USD'):
    """Format currency for display"""
    return f"${amount:.2f}" if currency == 'USD' else f"{amount:.2f} {currency}"


def validate_stripe_signature(payload, sig_header):
    """Validate Stripe webhook signature"""
    endpoint_secret = os.environ.get('STRIPE_ENDPOINT_SECRET')
    if not endpoint_secret:
        return False
    
    try:
        stripe.Webhook.construct_event(payload, sig_header, endpoint_secret)
        return True
    except ValueError:
        # Invalid payload
        return False
    except stripe.error.SignatureVerificationError:
        # Invalid signature
        return False