# Cinematch - AI-Powered Movie Recommendation Service

Cinematch is a sophisticated AI-powered movie recommendation platform that uses LangChain to orchestrate multiple LLMs (Claude, Gemini) with real-time parameter control, content safety guardrails, and privacy-first design.

## 🎬 Features

- **Multi-LLM Support**: Intelligent routing between Claude (Anthropic) and Gemini (Google) based on query type
- **Real-time Parameter Control**: Adjust Temperature and Top-K parameters via interactive sliders
- **Advanced Safety System**: Content filtering, age verification (18+), and PII detection
- **Privacy-First Design**: Consent management, minimal data retention, GDPR compliant
- **Vector Search**: Semantic movie search using PostgreSQL with pgvector
- **Custom API Routes**: Build and deploy custom AI-powered endpoints
- **SEO & AI Agent Optimization**: robots.txt, sitemap.xml, and ai.txt for search engines and AI crawlers

## 🚀 Quick Start

### Prerequisites

- Ubuntu 20.04/22.04 VPS with 4GB RAM minimum
- PostgreSQL with pgvector extension (or DigitalOcean Managed Database)
- Domain name with DNS pointing to your server
- API keys for OpenAI (required), Anthropic (optional), Google (optional)

### One-Command Installation

```bash
wget https://raw.githubusercontent.com/yourusername/cinematch/main/cinematch-install-script.sh
chmod +x cinematch-install-script.sh
sudo ./cinematch-install-script.sh
```

### Docker Installation

```bash
# Clone repository
git clone https://github.com/yourusername/cinematch.git
cd cinematch

# Copy environment template
cp .env.example .env
# Edit .env with your configuration

# Start with Docker Compose
docker-compose up -d

# Initialize database
docker-compose exec cinematch flask db upgrade
docker-compose exec cinematch flask init-db
docker-compose exec cinematch flask create-admin
```

## 📋 Configuration

### Environment Variables

Key variables to configure in `.env`:

```bash
# Required
SECRET_KEY=generate-with-python-secrets
DATABASE_URL=postgresql://user:pass@host:port/db
ENCRYPTION_KEY=generate-with-fernet

# API Keys (at least OpenAI required)
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=AIza...

# Admin
ADMIN_SECRET_PATH=random-admin-path-x7j9k2m4
```

### Database Setup

1. **Using DigitalOcean Managed Database** (Recommended):
   - Create a PostgreSQL cluster
   - Enable pgvector extension
   - Use connection string in DATABASE_URL

2. **Self-hosted PostgreSQL**:
   ```sql
   CREATE DATABASE cinematch;
   CREATE EXTENSION IF NOT EXISTS vector;
   ```

## 🏗️ Architecture

### Core Components

- **Flask Application** (`app.py`): Main application with route handling
- **LangChain Agent** (`movie_agent.py`): AI orchestration and routing
- **Guardrails System** (`guardrails.py`): Content safety and filtering
- **Cache Manager** (`cache_manager.py`): PostgreSQL-based caching (no Redis required)
- **Admin System** (`admin_routes.py`): Full admin panel with API key management

### Key Features Explained

#### 1. Temperature and Top-K Controls
Users can adjust AI parameters in real-time:
- **Temperature** (0.0-2.0): Controls randomness
- **Top-K** (1-100): Controls vocabulary diversity

#### 2. Multi-LLM Routing
Intelligent routing based on:
- Query complexity
- Content type
- Custom rules
- Cost optimization

#### 3. Privacy & Consent
- Explicit consent required
- Chat logs only stored when guardrails triggered
- IP anonymization options
- GDPR compliant

## 🛠️ Administration

### Admin Panel Access

```
https://yourdomain.com/[ADMIN_SECRET_PATH]/
```

### Admin Features

1. **API Key Management**: Add/update LLM API keys
2. **Route Builder**: Create custom API endpoints
3. **Safety Dashboard**: Monitor content filtering
4. **User Management**: Manage admin users
5. **SEO Settings**: Configure meta tags and AI agent access

### Creating Custom Routes

1. Navigate to Admin → Routes
2. Click "Create New Route"
3. Configure:
   - Path: `/api/custom/movie-mood`
   - Action: LLM Query
   - System Prompt: Custom instructions
   - Parameters: Temperature, Top-K settings

## 🔒 Security

### Built-in Security Features

- **Age Verification**: 18+ requirement with session tracking
- **Content Filtering**: Profanity, PII, and harmful content detection
- **Rate Limiting**: Configurable per-endpoint limits
- **CSRF Protection**: Token-based protection
- **SQL Injection Prevention**: Parameterized queries
- **XSS Protection**: Response sanitization

### Security Headers

Nginx automatically adds:
- Strict-Transport-Security
- X-Content-Type-Options
- X-Frame-Options
- Content-Security-Policy

## 📊 Monitoring

### Health Check

```bash
curl https://yourdomain.com/health
```

### Logs

- Application: `/var/www/cinematch/logs/cinematch.log`
- Nginx: `/var/log/nginx/access.log`
- Guardrails: Only triggered violations logged

### Metrics

Access real-time metrics in admin dashboard:
- Active sessions
- API response times
- Safety trigger rates
- LLM usage distribution

## 🔧 Maintenance

### Backup

Automated daily backups to DigitalOcean Spaces:

```bash
# Manual backup
docker-compose exec cinematch python backup.py

# Check backup status
cinematch-manage backup-status
```

### Updates

```bash
# Update application
cd /var/www/cinematch
git pull
cinematch-manage restart

# Update dependencies
source venv/bin/activate
pip install -r requirements.txt --upgrade
```

### Database Migrations

```bash
flask db migrate -m "Description"
flask db upgrade
```

## 🚨 Troubleshooting

### Common Issues

1. **"No API keys configured"**
   - Add at least OpenAI key in admin panel
   - Ensure keys are active

2. **"Age verification loop"**
   - Clear browser cookies
   - Check session configuration

3. **"Rate limit exceeded"**
   - Adjust limits in nginx.conf
   - Check for bot traffic

### Debug Mode

```bash
# Enable debug logging
export FLASK_DEBUG=1
cinematch-manage restart

# View real-time logs
cinematch-manage logs
```

## 🌟 Advanced Features

### LangChain Integration

Custom chains example:

```python
from movie_agent import MovieAgent

agent = MovieAgent(db, cache)
result = agent.process_request(
    session_id="test",
    query="Sci-fi movies like Inception",
    temperature=0.7,
    top_k=20
)
```

### Vector Search

Index movies programmatically:

```python
from movie_agent import MovieDocumentIndexer

indexer = MovieDocumentIndexer(embeddings, vector_store)
indexer.index_document(
    title="Inception",
    content="A mind-bending thriller about dream infiltration...",
    metadata={"year": 2010, "rating": "PG-13"}
)
```

## 📚 API Documentation

### Chat Endpoint

```bash
POST /api/chat
Content-Type: application/json

{
    "message": "Recommend a thriller",
    "temperature": 0.7,
    "top_k": 20
}
```

### Custom Routes

Access your custom routes at configured paths:

```bash
POST /api/custom/your-route
Content-Type: application/json

{
    "prompt": "Your query here"
}
```

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see LICENSE file for details.

## 🙏 Acknowledgments

- Built with [LangChain](https://langchain.com/)
- UI components from [Tailwind CSS](https://tailwindcss.com/)
- Vector search powered by [pgvector](https://github.com/pgvector/pgvector)

## 📞 Support

- Documentation: [https://docs.cinematch.ai](https://docs.cinematch.ai)
- Issues: [GitHub Issues](https://github.com/yourusername/cinematch/issues)
- Email: support@cinematch.ai

---

**Note**: This is an AI-powered service. All recommendations are generated by AI and should be verified independently. Users must be 18+ to use this service.