# admin_routes_extended.py - Extended admin routes for custom route creation

from flask import Blueprint, render_template, request, jsonify, redirect, url_for
from flask_login import login_required, current_user
from datetime import datetime
import json
import time
from auth import admin_required

admin_extended_bp = Blueprint('admin_routes', __name__, url_prefix='/admin')

@admin_extended_bp.route('/routes')
@login_required
@admin_required
def manage_routes():
    """Route management dashboard"""
    from app import db
    from models import CustomRoute
    
    routes = CustomRoute.query.order_by(CustomRoute.created_at.desc()).all()
    
    # Calculate statistics
    stats = {
        'total_routes': len(routes),
        'active_routes': sum(1 for r in routes if r.active),
        'api_routes': sum(1 for r in routes if r.action_type == 'llm_query'),
        'webhook_routes': sum(1 for r in routes if r.action_type == 'webhook')
    }
    
    return render_template('admin/routes.html', routes=routes, stats=stats)

@admin_extended_bp.route('/routes/create', methods=['GET'])
@login_required
@admin_required
def create_route():
    """Show route creation form"""
    return render_template('admin/create_route.html')

@admin_extended_bp.route('/routes/create', methods=['POST'])
@login_required
@admin_required
def create_route_post():
    """Create a new custom route"""
    from app import db, app
    from models import CustomRoute, AdminAuditLog
    
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['name', 'path', 'method', 'action_type']
    for field in required_fields:
        if not data.get(field):
            return jsonify({'error': f'Missing required field: {field}'}), 400
    
    # Validate path format
    if not data['path'].startswith('/'):
        return jsonify({'error': 'Path must start with /'}), 400
    
    # Check if path already exists
    existing = CustomRoute.query.filter_by(path=data['path']).first()
    if existing:
        return jsonify({'error': 'Route with this path already exists'}), 400
    
    # Build configuration based on action type
    config = {
        'action_type': data['action_type'],
        'temperature': data.get('temperature', 0.7),
        'top_k': data.get('top_k', 20),
        'max_tokens': data.get('max_tokens', 150),
        'cache_ttl': data.get('cache_ttl', 300)
    }
    
    if data['action_type'] == 'llm_query':
        config.update({
            'model': data.get('model', 'auto'),
            'system_prompt': data.get('system_prompt', ''),
            'response_format': data.get('response_format', 'json')
        })
    
    # Create route
    route = CustomRoute(
        name=data['name'],
        path=data['path'],
        method=data['method'],
        description=data.get('description', ''),
        action_type=data['action_type'],
        configuration=config,
        requires_auth=data.get('requires_auth', True),
        rate_limit=data.get('rate_limit', 60),
        active=True,
        created_by=current_user.id
    )
    
    db.session.add(route)
    
    # Log admin action
    audit = AdminAuditLog(
        user_id=current_user.id,
        action=f"Created custom route: {data['name']}",
        details={'route_path': data['path'], 'action_type': data['action_type']},
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    db.session.add(audit)
    
    db.session.commit()
    
    # Register the route dynamically
    _register_custom_route(app, route)
    
    return jsonify({'success': True, 'route_id': str(route.id)})

@admin_extended_bp.route('/routes/<uuid:route_id>/edit', methods=['GET'])
@login_required
@admin_required
def edit_route(route_id):
    """Edit route page"""
    from models import CustomRoute
    
    route = CustomRoute.query.get_or_404(route_id)
    return render_template('admin/edit_route.html', route=route)

@admin_extended_bp.route('/routes/<uuid:route_id>/update', methods=['POST'])
@login_required
@admin_required
def update_route(route_id):
    """Update an existing route"""
    from app import db
    from models import CustomRoute, AdminAuditLog
    
    route = CustomRoute.query.get_or_404(route_id)
    data = request.get_json()
    
    # Update fields
    route.name = data.get('name', route.name)
    route.description = data.get('description', route.description)
    route.configuration = data.get('configuration', route.configuration)
    route.requires_auth = data.get('requires_auth', route.requires_auth)
    route.rate_limit = data.get('rate_limit', route.rate_limit)
    
    # Log action
    audit = AdminAuditLog(
        user_id=current_user.id,
        action=f"Updated route: {route.name}",
        details={'route_id': str(route_id)},
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    db.session.add(audit)
    
    db.session.commit()
    
    return jsonify({'success': True})

@admin_extended_bp.route('/routes/<uuid:route_id>/toggle', methods=['POST'])
@login_required
@admin_required
def toggle_route(route_id):
    """Enable/disable a route"""
    from app import db
    from models import CustomRoute, AdminAuditLog
    
    route = CustomRoute.query.get_or_404(route_id)
    route.active = not route.active
    
    # Log action
    audit = AdminAuditLog(
        user_id=current_user.id,
        action=f"{'Enabled' if route.active else 'Disabled'} route: {route.name}",
        details={'route_id': str(route_id)},
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    db.session.add(audit)
    
    db.session.commit()
    
    return jsonify({'success': True, 'active': route.active})

@admin_extended_bp.route('/routes/<uuid:route_id>', methods=['DELETE'])
@login_required
@admin_required
def delete_route(route_id):
    """Delete a custom route"""
    from app import db
    from models import CustomRoute, AdminAuditLog
    
    route = CustomRoute.query.get_or_404(route_id)
    route_name = route.name
    
    # Log action first
    audit = AdminAuditLog(
        user_id=current_user.id,
        action=f"Deleted route: {route_name}",
        details={'route_path': route.path},
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    db.session.add(audit)
    
    db.session.delete(route)
    db.session.commit()
    
    return jsonify({'success': True})

@admin_extended_bp.route('/routes/<uuid:route_id>/test', methods=['POST'])
@login_required
@admin_required
def test_route(route_id):
    """Test a custom route"""
    from models import CustomRoute
    
    route = CustomRoute.query.get_or_404(route_id)
    test_data = request.get_json()
    
    if not route.active:
        return jsonify({'error': 'Route is inactive'}), 400
    
    # Execute route logic
    start_time = time.time()
    
    try:
        result = _execute_custom_route(route, test_data)
        execution_time = f"{(time.time() - start_time) * 1000:.2f}ms"
        
        return jsonify({
            'success': True,
            'result': result,
            'execution_time': execution_time
        })
    except Exception as e:
        return jsonify({
            'error': str(e),
            'execution_time': f"{(time.time() - start_time) * 1000:.2f}ms"
        }), 500

def _execute_custom_route(route, data):
    """Execute a custom route's logic"""
    config = route.configuration
    
    if route.action_type == 'llm_query':
        return _execute_llm_query(config, data)
    elif route.action_type == 'database_query':
        return _execute_database_query(config, data)
    elif route.action_type == 'webhook':
        return _execute_webhook(config, data)
    elif route.action_type == 'cache_lookup':
        return _execute_cache_lookup(config, data)
    else:
        raise ValueError(f"Unknown action type: {route.action_type}")

def _execute_llm_query(config, data):
    """Execute an LLM query"""
    from app import movie_agent
    
    # Build prompt
    prompt = data.get('prompt', '')
    if config.get('system_prompt'):
        prompt = f"{config['system_prompt']}\n\n{prompt}"
    
    # Process with movie agent
    result = movie_agent.process_request(
        session_id=data.get('session_id', 'test'),
        query=prompt,
        temperature=config.get('temperature', 0.7),
        top_k=config.get('top_k', 20)
    )
    
    # Format response based on configuration
    if config.get('response_format') == 'json':
        return {
            'response': result['response'],
            'metadata': {
                'llm_used': result['llm_used'],
                'response_time_ms': result['response_time_ms']
            }
        }
    else:
        return result['response']

def _execute_database_query(config, data):
    """Execute a database query"""
    # Placeholder for database query logic
    return {
        'status': 'not_implemented',
        'message': 'Database queries are not yet implemented'
    }

def _execute_webhook(config, data):
    """Execute a webhook call"""
    import requests
    
    webhook_url = config.get('webhook_url')
    if not webhook_url:
        raise ValueError("No webhook URL configured")
    
    # Make webhook request
    response = requests.post(
        webhook_url,
        json=data,
        headers=config.get('headers', {}),
        timeout=config.get('timeout', 10)
    )
    
    return {
        'status_code': response.status_code,
        'response': response.json() if response.headers.get('content-type') == 'application/json' else response.text
    }

def _execute_cache_lookup(config, data):
    """Execute a cache lookup"""
    from app import cache
    
    key = data.get('key')
    if not key:
        raise ValueError("No cache key provided")
    
    value = cache.get(key)
    
    return {
        'found': value is not None,
        'value': value,
        'ttl': cache.ttl(key) if value else -1
    }

def _register_custom_route(app, route):
    """Dynamically register a custom route with Flask"""
    from flask import request, jsonify
    from flask_limiter import Limiter
    from flask_login import login_required
    
    # Create route handler
    def custom_route_handler():
        # Check if route is active
        if not route.active:
            return jsonify({'error': 'Route is inactive'}), 503
        
        # Get request data
        if request.method in ['POST', 'PUT']:
            data = request.get_json() or {}
        else:
            data = request.args.to_dict()
        
        # Add session info
        data['session_id'] = request.headers.get('X-Session-ID', 'anonymous')
        
        try:
            result = _execute_custom_route(route, data)
            return jsonify(result)
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    # Apply decorators based on configuration
    if route.requires_auth:
        custom_route_handler = login_required(custom_route_handler)
    
    # Register with Flask
    endpoint_name = f"custom_route_{route.id}"
    app.add_url_rule(
        route.path,
        endpoint=endpoint_name,
        view_func=custom_route_handler,
        methods=[route.method]
    )

# Register all custom routes on app startup
def register_all_custom_routes(app):
    """Register all active custom routes"""
    from models import CustomRoute
    
    active_routes = CustomRoute.query.filter_by(active=True).all()
    
    for route in active_routes:
        try:
            _register_custom_route(app, route)
            print(f"Registered custom route: {route.path}")
        except Exception as e:
            print(f"Failed to register route {route.path}: {e}")

# Additional admin routes for LLM configuration
@admin_extended_bp.route('/routing-config')
@login_required
@admin_required
def routing_configuration():
    """LLM routing configuration page"""
    from models import RoutingConfiguration, ContentRoutingRule
    
    config = RoutingConfiguration.query.first()
    if not config:
        # Create default configuration
        config = RoutingConfiguration()
        from app import db
        db.session.add(config)
        db.session.commit()
    
    rules = ContentRoutingRule.query.order_by(ContentRoutingRule.priority.desc()).all()
    
    return render_template('admin/routing_config.html', 
                         routing_config=config, 
                         content_rules=rules)

@admin_extended_bp.route('/routing-config/update', methods=['POST'])
@login_required
@admin_required
def update_routing_config():
    """Update routing configuration"""
    from app import db
    from models import RoutingConfiguration
    
    data = request.get_json()
    
    config = RoutingConfiguration.query.first()
    if not config:
        config = RoutingConfiguration()
        db.session.add(config)
    
    config.use_claude_threshold = data.get('claude_threshold', 0.7)
    config.use_gemini_threshold = data.get('gemini_threshold', 0.3)
    config.content_length_threshold = data.get('content_length_threshold', 500)
    config.enable_cross_validation = data.get('enable_cross_validation', False)
    config.cross_validation_keywords = data.get('cross_validation_keywords', [])
    config.updated_by = current_user.id
    
    db.session.commit()
    
    return jsonify({'success': True})

@admin_extended_bp.route('/routing-rules/add', methods=['POST'])
@login_required
@admin_required
def add_routing_rule():
    """Add a new routing rule"""
    from app import db
    from models import ContentRoutingRule
    
    data = request.get_json()
    
    rule = ContentRoutingRule(
        rule_name=data['name'],
        condition_type=data['condition_type'],
        condition_value=data['condition_value'],
        target_llm=data['target_llm'],
        priority=data.get('priority', 1),
        active=True,
        created_by=current_user.id
    )
    
    db.session.add(rule)
    db.session.commit()
    
    return jsonify({'success': True, 'rule_id': str(rule.id)})

@admin_extended_bp.route('/routing-rules/<uuid:rule_id>', methods=['DELETE'])
@login_required
@admin_required
def delete_routing_rule(rule_id):
    """Delete a routing rule"""
    from app import db
    from models import ContentRoutingRule
    
    rule = ContentRoutingRule.query.get_or_404(rule_id)
    db.session.delete(rule)
    db.session.commit()
    
    return jsonify({'success': True})