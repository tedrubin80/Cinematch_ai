#!/usr/bin/env python3
# check_safety_integration.py - Validate safety system integration

"""
Integration check script for Cinematch safety systems.
Validates that all components are properly integrated and functional.
"""

import os
import sys
import importlib
from datetime import datetime

def print_status(message, status="INFO"):
    """Print status message with formatting"""
    icons = {
        "INFO": "ℹ️ ",
        "SUCCESS": "✅",
        "WARNING": "⚠️ ",
        "ERROR": "❌",
        "CHECKING": "🔍"
    }
    
    icon = icons.get(status, "• ")
    print(f"{icon} {message}")

def check_module_imports():
    """Check if all safety modules can be imported"""
    print_status("Checking module imports...", "CHECKING")
    
    modules_to_check = [
        'age_verification',
        'guardrails', 
        'parameter_controls',
        'safety_monitor',
        'safety_integration'
    ]
    
    all_imports_successful = True
    
    for module_name in modules_to_check:
        try:
            module = importlib.import_module(module_name)
            print_status(f"{module_name} - Module imported successfully", "SUCCESS")
            
            # Check for key classes/functions
            if module_name == 'age_verification':
                assert hasattr(module, 'AgeVerificationManager')
                assert hasattr(module, 'age_verified_required')
                
            elif module_name == 'guardrails':
                assert hasattr(module, 'ContentFilter')
                assert hasattr(module, 'ResponseSanitizer')
                assert hasattr(module, 'content_filter_required')
                
            elif module_name == 'parameter_controls':
                assert hasattr(module, 'ParameterController')
                assert hasattr(module, 'parameter_controls_required')
                
            elif module_name == 'safety_monitor':
                assert hasattr(module, 'SafetyMonitor')
                assert hasattr(module, 'log_safety_event')
                
            elif module_name == 'safety_integration':
                assert hasattr(module, 'integrate_safety_systems')
                assert hasattr(module, 'ai_endpoint_protection')
            
            print_status(f"{module_name} - All required components found", "SUCCESS")
            
        except ImportError as e:
            print_status(f"{module_name} - Import failed: {e}", "ERROR")
            all_imports_successful = False
        except AssertionError as e:
            print_status(f"{module_name} - Missing required components", "ERROR") 
            all_imports_successful = False
        except Exception as e:
            print_status(f"{module_name} - Unexpected error: {e}", "ERROR")
            all_imports_successful = False
    
    return all_imports_successful

def check_database_models():
    """Check if safety database models are available"""
    print_status("Checking database models...", "CHECKING")
    
    try:
        from models import (
            AgeVerification, SafetyViolation, ParameterUsage, 
            SafetyReport, SafetyLog, User, UserSubscription
        )
        
        models_to_check = [
            ('AgeVerification', AgeVerification),
            ('SafetyViolation', SafetyViolation), 
            ('ParameterUsage', ParameterUsage),
            ('SafetyReport', SafetyReport),
            ('SafetyLog', SafetyLog)
        ]
        
        for model_name, model_class in models_to_check:
            # Check that model has required fields
            if hasattr(model_class, '__table__'):
                print_status(f"{model_name} - Database model available", "SUCCESS")
            else:
                print_status(f"{model_name} - Model missing table definition", "WARNING")
        
        return True
        
    except ImportError as e:
        print_status(f"Database models import failed: {e}", "ERROR")
        return False

def check_template_files():
    """Check if template files exist"""
    print_status("Checking template files...", "CHECKING")
    
    template_files = [
        'templates/components/age_verification_modal.html',
        'templates/components/parameter_controls.html', 
        'templates/components/safety_dashboard.html',
        'templates/index_with_safety.html'
    ]
    
    all_templates_exist = True
    
    for template_file in template_files:
        if os.path.exists(template_file):
            # Check file size to ensure it's not empty
            size = os.path.getsize(template_file)
            if size > 100:  # Reasonable minimum size
                print_status(f"{template_file} - Template exists and has content ({size} bytes)", "SUCCESS")
            else:
                print_status(f"{template_file} - Template exists but may be empty ({size} bytes)", "WARNING")
        else:
            print_status(f"{template_file} - Template file missing", "ERROR")
            all_templates_exist = False
    
    return all_templates_exist

def check_configuration():
    """Check safety system configuration"""
    print_status("Checking safety configuration...", "CHECKING")
    
    try:
        from safety_integration import get_safety_config
        
        # This would need an app context in a real scenario
        # For now, just check if the function exists
        print_status("Safety configuration function available", "SUCCESS")
        return True
        
    except ImportError:
        print_status("Safety configuration not available", "WARNING")
        return False
    except Exception as e:
        print_status(f"Configuration check error: {e}", "ERROR")
        return False

def check_integration_points():
    """Check integration points with main application"""
    print_status("Checking integration points...", "CHECKING")
    
    integration_checks = []
    
    # Check if app.py has been updated
    try:
        with open('app.py', 'r') as f:
            app_content = f.read()
            
        if 'safety_integration' in app_content:
            print_status("app.py - Safety integration import found", "SUCCESS")
            integration_checks.append(True)
        else:
            print_status("app.py - Safety integration import not found", "WARNING")
            integration_checks.append(False)
            
        if 'integrate_safety_systems' in app_content:
            print_status("app.py - Safety integration call found", "SUCCESS") 
            integration_checks.append(True)
        else:
            print_status("app.py - Safety integration call not found", "WARNING")
            integration_checks.append(False)
            
    except FileNotFoundError:
        print_status("app.py - File not found", "ERROR")
        integration_checks.append(False)
    
    return all(integration_checks)

def check_dependencies():
    """Check if required dependencies are installed"""
    print_status("Checking Python dependencies...", "CHECKING")
    
    required_packages = [
        'flask',
        'flask_sqlalchemy', 
        'flask_login',
        'werkzeug',
        'sqlalchemy',
        'psycopg2',  # or psycopg2-binary
        'redis',
        'celery'
    ]
    
    optional_packages = [
        'better-profanity',
        'profanity-check2',
        'textblob',
        'spacy'
    ]
    
    all_required_available = True
    
    for package in required_packages:
        try:
            importlib.import_module(package.replace('-', '_'))
            print_status(f"{package} - Required dependency available", "SUCCESS")
        except ImportError:
            print_status(f"{package} - Required dependency missing", "ERROR")
            all_required_available = False
    
    for package in optional_packages:
        try:
            importlib.import_module(package.replace('-', '_'))
            print_status(f"{package} - Optional dependency available", "SUCCESS")
        except ImportError:
            print_status(f"{package} - Optional dependency missing (functionality may be limited)", "WARNING")
    
    return all_required_available

def check_file_structure():
    """Check if all safety system files exist"""
    print_status("Checking file structure...", "CHECKING")
    
    required_files = [
        'age_verification.py',
        'guardrails.py',
        'parameter_controls.py', 
        'safety_monitor.py',
        'safety_integration.py',
        'models.py',
        'test_safety_systems.py'
    ]
    
    all_files_exist = True
    
    for file_name in required_files:
        if os.path.exists(file_name):
            size = os.path.getsize(file_name)
            print_status(f"{file_name} - File exists ({size} bytes)", "SUCCESS")
        else:
            print_status(f"{file_name} - File missing", "ERROR")
            all_files_exist = False
    
    return all_files_exist

def check_database_connection():
    """Check database connectivity"""
    print_status("Checking database connection...", "CHECKING")
    
    try:
        # This is a basic check - in a real scenario you'd test actual connectivity
        print_status("Database connection check skipped (requires running app)", "INFO")
        return True
    except Exception as e:
        print_status(f"Database connection error: {e}", "ERROR")
        return False

def generate_integration_report():
    """Generate a comprehensive integration report"""
    print("\n" + "=" * 60)
    print("🛡️  CINEMATCH SAFETY SYSTEMS INTEGRATION REPORT")
    print("=" * 60)
    print(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    checks = [
        ("File Structure", check_file_structure),
        ("Module Imports", check_module_imports),
        ("Database Models", check_database_models),
        ("Template Files", check_template_files),
        ("Dependencies", check_dependencies),
        ("Integration Points", check_integration_points),
        ("Configuration", check_configuration),
    ]
    
    results = []
    
    for check_name, check_function in checks:
        print(f"\n📋 {check_name}")
        print("-" * 40)
        try:
            result = check_function()
            results.append((check_name, result))
        except Exception as e:
            print_status(f"Check failed with error: {e}", "ERROR")
            results.append((check_name, False))
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 INTEGRATION SUMMARY")
    print("=" * 60)
    
    passed_checks = sum(1 for _, result in results if result)
    total_checks = len(results)
    
    for check_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{check_name:.<40} {status}")
    
    print(f"\nOverall: {passed_checks}/{total_checks} checks passed")
    
    if passed_checks == total_checks:
        print("\n🎉 ALL CHECKS PASSED - SAFETY SYSTEMS FULLY INTEGRATED!")
        print("\n🚀 Ready for production deployment with comprehensive safety features:")
        print("   • Age verification with legal compliance")
        print("   • Advanced content filtering and guardrails") 
        print("   • AI parameter controls with tier-based limits")
        print("   • Real-time safety monitoring and violation tracking")
        print("   • Response sanitization and PII protection")
        print("   • Comprehensive audit logging and compliance reporting")
        
    elif passed_checks >= total_checks * 0.8:
        print("\n⚠️  MOSTLY INTEGRATED - Minor issues detected")
        print("Review warnings above and address any missing components.")
        
    else:
        print("\n❌ INTEGRATION INCOMPLETE - Critical issues detected") 
        print("Please address the errors above before deploying.")
    
    return passed_checks / total_checks

if __name__ == '__main__':
    print("🔍 Starting Safety Systems Integration Check...")
    
    try:
        integration_score = generate_integration_report()
        
        print(f"\n📈 Integration Score: {integration_score:.1%}")
        
        if integration_score >= 1.0:
            sys.exit(0)  # Success
        elif integration_score >= 0.8:
            sys.exit(1)  # Warning
        else:
            sys.exit(2)  # Error
            
    except KeyboardInterrupt:
        print("\n\n⏹️  Integration check interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ Integration check failed with error: {e}")
        sys.exit(1)