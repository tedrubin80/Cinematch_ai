# parameter_controls.py - AI parameter control and safety system

"""
AI parameter control system for Cinematch.
Provides safe parameter adjustment with user controls, validation,
and automatic safety overrides for temperature, top-K, and other AI settings.
"""

import logging
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple, Union
from dataclasses import dataclass, asdict
from flask import session, request
from flask_login import current_user
from functools import wraps

logger = logging.getLogger(__name__)

@dataclass
class ParameterPreset:
    """Predefined parameter preset"""
    name: str
    description: str
    temperature: float
    top_k: int
    max_tokens: int
    frequency_penalty: float
    presence_penalty: float
    safety_level: str  # 'safe', 'moderate', 'advanced'
    user_tier_required: str  # 'free', 'basic', 'premium'

@dataclass
class ParameterValidationResult:
    """Result of parameter validation"""
    is_valid: bool
    validated_params: Dict[str, Any]
    warnings: List[str]
    errors: List[str]
    safety_overrides: List[str]

@dataclass
class ParameterUsageLog:
    """Log entry for parameter usage"""
    user_id: Optional[int]
    session_id: str
    parameters: Dict[str, Any]
    preset_used: Optional[str]
    safety_overrides: List[str]
    timestamp: datetime
    request_context: Dict[str, Any]

# Predefined parameter presets
PARAMETER_PRESETS = {
    'conservative': ParameterPreset(
        name='Conservative',
        description='Safe, predictable responses with low creativity',
        temperature=0.3,
        top_k=20,
        max_tokens=500,
        frequency_penalty=0.0,
        presence_penalty=0.0,
        safety_level='safe',
        user_tier_required='free'
    ),
    'balanced': ParameterPreset(
        name='Balanced',
        description='Good balance of creativity and reliability',
        temperature=0.7,
        top_k=40,
        max_tokens=800,
        frequency_penalty=0.1,
        presence_penalty=0.1,
        safety_level='moderate',
        user_tier_required='basic'
    ),
    'creative': ParameterPreset(
        name='Creative',
        description='High creativity with more varied responses',
        temperature=1.0,
        top_k=60,
        max_tokens=1000,
        frequency_penalty=0.2,
        presence_penalty=0.2,
        safety_level='moderate',
        user_tier_required='basic'
    ),
    'experimental': ParameterPreset(
        name='Experimental',
        description='Maximum creativity and experimentation',
        temperature=1.5,
        top_k=100,
        max_tokens=1500,
        frequency_penalty=0.3,
        presence_penalty=0.3,
        safety_level='advanced',
        user_tier_required='premium'
    ),
    'focused': ParameterPreset(
        name='Focused',
        description='Highly deterministic responses for analytical tasks',
        temperature=0.1,
        top_k=10,
        max_tokens=600,
        frequency_penalty=0.0,
        presence_penalty=0.0,
        safety_level='safe',
        user_tier_required='free'
    )
}

# Parameter limits by user tier
TIER_LIMITS = {
    'free': {
        'temperature': {'min': 0.1, 'max': 0.8, 'default': 0.3},
        'top_k': {'min': 10, 'max': 40, 'default': 20},
        'max_tokens': {'min': 100, 'max': 500, 'default': 300},
        'frequency_penalty': {'min': 0.0, 'max': 0.2, 'default': 0.0},
        'presence_penalty': {'min': 0.0, 'max': 0.2, 'default': 0.0},
        'allowed_presets': ['conservative', 'focused']
    },
    'basic': {
        'temperature': {'min': 0.1, 'max': 1.2, 'default': 0.7},
        'top_k': {'min': 5, 'max': 60, 'default': 40},
        'max_tokens': {'min': 100, 'max': 1000, 'default': 600},
        'frequency_penalty': {'min': 0.0, 'max': 0.3, 'default': 0.1},
        'presence_penalty': {'min': 0.0, 'max': 0.3, 'default': 0.1},
        'allowed_presets': ['conservative', 'balanced', 'creative', 'focused']
    },
    'premium': {
        'temperature': {'min': 0.0, 'max': 2.0, 'default': 0.7},
        'top_k': {'min': 1, 'max': 100, 'default': 40},
        'max_tokens': {'min': 50, 'max': 2000, 'default': 800},
        'frequency_penalty': {'min': 0.0, 'max': 0.5, 'default': 0.1},
        'presence_penalty': {'min': 0.0, 'max': 0.5, 'default': 0.1},
        'allowed_presets': list(PARAMETER_PRESETS.keys())
    }
}

# Safety thresholds that trigger automatic overrides
SAFETY_THRESHOLDS = {
    'high_creativity_warning': {
        'temperature': 1.5,
        'message': 'High creativity settings may produce unpredictable results'
    },
    'extreme_settings': {
        'temperature': 1.8,
        'top_k': 90,
        'message': 'Extreme settings detected - consider using a preset'
    },
    'token_limit_warning': {
        'max_tokens': 1500,
        'message': 'High token limits may increase processing time and cost'
    }
}


class ParameterController:
    """Main parameter control and validation system"""
    
    def __init__(self):
        self.usage_history = {}  # Track parameter usage patterns
        self.safety_overrides_count = {}  # Track safety override frequency
        
    def get_user_tier(self, user=None) -> str:
        """Get user's subscription tier"""
        if not user and current_user.is_authenticated:
            user = current_user
        
        if user and hasattr(user, 'current_tier'):
            return user.current_tier
        elif user and hasattr(user, 'subscription') and user.subscription:
            return user.subscription.tier
        else:
            return 'free'
    
    def get_available_presets(self, user_tier: str) -> Dict[str, ParameterPreset]:
        """Get presets available to user based on their tier"""
        allowed_presets = TIER_LIMITS[user_tier]['allowed_presets']
        return {name: preset for name, preset in PARAMETER_PRESETS.items() 
                if name in allowed_presets}
    
    def get_parameter_limits(self, user_tier: str) -> Dict[str, Dict[str, float]]:
        """Get parameter limits for user's tier"""
        return TIER_LIMITS.get(user_tier, TIER_LIMITS['free'])
    
    def apply_preset(self, preset_name: str, user_tier: str) -> ParameterValidationResult:
        """Apply a predefined parameter preset"""
        if preset_name not in PARAMETER_PRESETS:
            return ParameterValidationResult(
                is_valid=False,
                validated_params={},
                warnings=[],
                errors=[f"Unknown preset: {preset_name}"],
                safety_overrides=[]
            )
        
        preset = PARAMETER_PRESETS[preset_name]
        
        # Check if user has access to this preset
        allowed_presets = TIER_LIMITS[user_tier]['allowed_presets']
        if preset_name not in allowed_presets:
            return ParameterValidationResult(
                is_valid=False,
                validated_params={},
                warnings=[],
                errors=[f"Preset '{preset_name}' requires {preset.user_tier_required} tier or higher"],
                safety_overrides=[]
            )
        
        # Extract parameters from preset
        params = {
            'temperature': preset.temperature,
            'top_k': preset.top_k,
            'max_tokens': preset.max_tokens,
            'frequency_penalty': preset.frequency_penalty,
            'presence_penalty': preset.presence_penalty
        }
        
        # Validate the preset parameters (they should always be valid)
        validation_result = self.validate_parameters(params, user_tier)
        
        # Log preset usage
        self._log_parameter_usage(params, preset_name)
        
        return validation_result
    
    def validate_parameters(self, params: Dict[str, Any], user_tier: str) -> ParameterValidationResult:
        """Validate and sanitize AI parameters"""
        limits = self.get_parameter_limits(user_tier)
        validated_params = {}
        warnings = []
        errors = []
        safety_overrides = []
        
        # Validate each parameter
        for param_name, value in params.items():
            if param_name not in limits:
                warnings.append(f"Unknown parameter: {param_name}")
                continue
            
            param_limits = limits[param_name]
            min_val = param_limits['min']
            max_val = param_limits['max']
            default_val = param_limits['default']
            
            try:
                # Convert to appropriate type
                if isinstance(default_val, float):
                    value = float(value)
                elif isinstance(default_val, int):
                    value = int(value)
                
                # Check bounds
                if value < min_val:
                    safety_overrides.append(f"{param_name} below minimum ({min_val}), using minimum")
                    value = min_val
                elif value > max_val:
                    safety_overrides.append(f"{param_name} above maximum ({max_val}), using maximum")
                    value = max_val
                
                # Check safety thresholds
                self._check_safety_thresholds(param_name, value, warnings)
                
                validated_params[param_name] = value
                
            except (ValueError, TypeError) as e:
                errors.append(f"Invalid value for {param_name}: {value}")
                validated_params[param_name] = default_val
                safety_overrides.append(f"Using default value for {param_name}")
        
        # Add any missing parameters with defaults
        for param_name, param_config in limits.items():
            if param_name not in validated_params and param_name not in ['allowed_presets']:
                validated_params[param_name] = param_config['default']
        
        # Perform combination safety checks
        self._check_parameter_combinations(validated_params, warnings, safety_overrides)
        
        # Log parameter validation
        self._log_parameter_usage(validated_params, None, safety_overrides)
        
        is_valid = len(errors) == 0
        
        return ParameterValidationResult(
            is_valid=is_valid,
            validated_params=validated_params,
            warnings=warnings,
            errors=errors,
            safety_overrides=safety_overrides
        )
    
    def _check_safety_thresholds(self, param_name: str, value: Union[int, float], 
                                warnings: List[str]) -> None:
        """Check if parameter values exceed safety thresholds"""
        for threshold_name, threshold_config in SAFETY_THRESHOLDS.items():
            if param_name in threshold_config:
                threshold_value = threshold_config[param_name]
                if value >= threshold_value:
                    warnings.append(threshold_config['message'])
    
    def _check_parameter_combinations(self, params: Dict[str, Any], 
                                    warnings: List[str], safety_overrides: List[str]) -> None:
        """Check for potentially problematic parameter combinations"""
        
        # High temperature + low top_k can be problematic
        if params.get('temperature', 0) > 1.0 and params.get('top_k', 100) < 20:
            warnings.append("High temperature with low top_k may produce repetitive results")
        
        # Very high frequency penalty can suppress creativity
        if params.get('frequency_penalty', 0) > 0.3:
            warnings.append("High frequency penalty may overly suppress word repetition")
        
        # Extreme combinations
        if (params.get('temperature', 0) > 1.5 and 
            params.get('frequency_penalty', 0) > 0.2 and 
            params.get('presence_penalty', 0) > 0.2):
            warnings.append("Extreme parameter combination detected - results may be unpredictable")
        
        # Token limit with high creativity
        if params.get('max_tokens', 0) > 1000 and params.get('temperature', 0) > 1.2:
            warnings.append("High token limit with high creativity may increase processing time")
    
    def _log_parameter_usage(self, params: Dict[str, Any], preset_name: Optional[str], 
                           safety_overrides: List[str] = None) -> None:
        """Log parameter usage for analytics and monitoring"""
        try:
            user_id = getattr(current_user, 'id', None) if current_user.is_authenticated else None
            session_id = session.get('session_id', 'anonymous')
            
            usage_log = ParameterUsageLog(
                user_id=user_id,
                session_id=session_id,
                parameters=params,
                preset_used=preset_name,
                safety_overrides=safety_overrides or [],
                timestamp=datetime.utcnow(),
                request_context={
                    'ip_address': request.remote_addr if request else None,
                    'user_agent': request.headers.get('User-Agent') if request else None
                }
            )
            
            # Store in database
            self._persist_usage_log(usage_log)
            
            # Update in-memory tracking
            if user_id:
                if user_id not in self.usage_history:
                    self.usage_history[user_id] = []
                self.usage_history[user_id].append(usage_log)
                
                # Keep only recent history
                cutoff = datetime.utcnow() - timedelta(days=7)
                self.usage_history[user_id] = [
                    log for log in self.usage_history[user_id] 
                    if log.timestamp > cutoff
                ]
            
            # Track safety overrides
            if safety_overrides:
                override_key = f"safety_overrides:{session_id}"
                self.safety_overrides_count[override_key] = self.safety_overrides_count.get(override_key, 0) + len(safety_overrides)
            
        except Exception as e:
            logger.error(f"Error logging parameter usage: {e}")
    
    def _persist_usage_log(self, usage_log: ParameterUsageLog) -> None:
        """Persist parameter usage log to database"""
        try:
            from models import db, ParameterUsage
            
            param_usage = ParameterUsage(
                user_id=usage_log.user_id,
                session_id=usage_log.session_id,
                parameters=usage_log.parameters,
                preset_used=usage_log.preset_used,
                safety_overrides=usage_log.safety_overrides,
                request_context=usage_log.request_context
            )
            
            db.session.add(param_usage)
            db.session.commit()
            
        except Exception as e:
            logger.error(f"Failed to persist parameter usage log: {e}")
    
    def get_user_parameter_history(self, user_id: int, days: int = 30) -> Dict[str, Any]:
        """Get parameter usage history for a user"""
        try:
            from models import ParameterUsage
            
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            usage_records = ParameterUsage.query.filter(
                ParameterUsage.user_id == user_id,
                ParameterUsage.created_at >= cutoff_date
            ).all()
            
            # Analyze usage patterns
            preset_usage = {}
            parameter_trends = {'temperature': [], 'top_k': [], 'max_tokens': []}
            total_overrides = 0
            
            for record in usage_records:
                # Count preset usage
                if record.preset_used:
                    preset_usage[record.preset_used] = preset_usage.get(record.preset_used, 0) + 1
                
                # Track parameter trends
                params = record.parameters
                for param_name in parameter_trends:
                    if param_name in params:
                        parameter_trends[param_name].append(params[param_name])
                
                # Count safety overrides
                if record.safety_overrides:
                    total_overrides += len(record.safety_overrides)
            
            # Calculate averages
            avg_parameters = {}
            for param_name, values in parameter_trends.items():
                if values:
                    avg_parameters[param_name] = sum(values) / len(values)
            
            return {
                'total_sessions': len(usage_records),
                'preset_usage': preset_usage,
                'average_parameters': avg_parameters,
                'parameter_trends': parameter_trends,
                'total_safety_overrides': total_overrides,
                'most_used_preset': max(preset_usage, key=preset_usage.get) if preset_usage else None
            }
            
        except Exception as e:
            logger.error(f"Error getting user parameter history: {e}")
            return {'error': str(e)}
    
    def get_optimal_preset_recommendation(self, user_id: Optional[int] = None) -> Tuple[str, str]:
        """Recommend optimal preset based on user history and tier"""
        try:
            user_tier = self.get_user_tier()
            
            # For new users or free tier, recommend conservative
            if not user_id or user_tier == 'free':
                return 'conservative', 'Recommended for new users and safe exploration'
            
            # Get user history
            history = self.get_user_parameter_history(user_id, 14)
            
            if history.get('error') or history.get('total_sessions', 0) < 3:
                # Not enough data, use tier-based recommendation
                tier_recommendations = {
                    'basic': 'balanced',
                    'premium': 'creative'
                }
                recommended = tier_recommendations.get(user_tier, 'conservative')
                return recommended, f'Recommended for {user_tier} tier users'
            
            # Analyze usage patterns
            avg_temp = history.get('average_parameters', {}).get('temperature', 0.3)
            most_used = history.get('most_used_preset')
            overrides = history.get('total_safety_overrides', 0)
            
            # Too many overrides? Recommend safer preset
            if overrides > 5:
                return 'conservative', 'Recommended due to frequent safety overrides'
            
            # Based on temperature preference
            if avg_temp < 0.5:
                return 'focused', 'Based on your preference for deterministic responses'
            elif avg_temp > 1.0:
                if user_tier == 'premium':
                    return 'experimental', 'Based on your preference for high creativity'
                else:
                    return 'creative', 'Based on your preference for creative responses'
            else:
                return 'balanced', 'Based on your balanced parameter usage'
                
        except Exception as e:
            logger.error(f"Error getting preset recommendation: {e}")
            return 'conservative', 'Default safe recommendation'


# Global parameter controller instance
parameter_controller = ParameterController()


def parameter_controls_required(f):
    """Decorator to ensure parameter controls are applied to AI requests"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            # Get user tier
            user_tier = parameter_controller.get_user_tier()
            
            # Check if custom parameters were provided
            custom_params = request.json.get('ai_parameters') if request.is_json else None
            preset_name = request.json.get('preset') if request.is_json else None
            
            if preset_name:
                # Apply preset
                validation_result = parameter_controller.apply_preset(preset_name, user_tier)
            elif custom_params:
                # Validate custom parameters
                validation_result = parameter_controller.validate_parameters(custom_params, user_tier)
            else:
                # Use default parameters for tier
                limits = parameter_controller.get_parameter_limits(user_tier)
                default_params = {param: config['default'] for param, config in limits.items() 
                                if param != 'allowed_presets'}
                validation_result = parameter_controller.validate_parameters(default_params, user_tier)
            
            if not validation_result.is_valid:
                return {
                    'error': 'Invalid AI parameters',
                    'details': validation_result.errors,
                    'warnings': validation_result.warnings
                }, 400
            
            # Add validated parameters to request context
            request.validated_ai_parameters = validation_result.validated_params
            request.parameter_warnings = validation_result.warnings
            request.parameter_safety_overrides = validation_result.safety_overrides
            
            return f(*args, **kwargs)
            
        except Exception as e:
            logger.error(f"Error in parameter controls decorator: {e}")
            # Continue with default parameters on error
            return f(*args, **kwargs)
    
    return decorated_function


def get_user_parameter_interface(user_tier: str) -> Dict[str, Any]:
    """Get parameter interface configuration for frontend"""
    limits = parameter_controller.get_parameter_limits(user_tier)
    presets = parameter_controller.get_available_presets(user_tier)
    
    # Build slider configurations
    parameter_controls = {}
    for param_name, config in limits.items():
        if param_name != 'allowed_presets':
            parameter_controls[param_name] = {
                'min': config['min'],
                'max': config['max'],
                'default': config['default'],
                'step': 0.1 if isinstance(config['default'], float) else 1,
                'description': _get_parameter_description(param_name)
            }
    
    return {
        'user_tier': user_tier,
        'parameter_controls': parameter_controls,
        'available_presets': {name: asdict(preset) for name, preset in presets.items()},
        'recommendations': {
            'preset': parameter_controller.get_optimal_preset_recommendation(),
            'tips': _get_parameter_tips(user_tier)
        }
    }


def _get_parameter_description(param_name: str) -> str:
    """Get user-friendly description for parameter"""
    descriptions = {
        'temperature': 'Controls creativity and randomness (0.0 = deterministic, 2.0 = very creative)',
        'top_k': 'Limits word choices to top K most likely (lower = more focused)',
        'max_tokens': 'Maximum length of AI response',
        'frequency_penalty': 'Reduces repetition of words (0.0 = no penalty, 0.5 = strong penalty)',
        'presence_penalty': 'Encourages new topics (0.0 = no penalty, 0.5 = strong penalty)'
    }
    return descriptions.get(param_name, 'AI parameter')


def _get_parameter_tips(user_tier: str) -> List[str]:
    """Get helpful tips for parameter usage"""
    base_tips = [
        "Start with presets and adjust gradually",
        "Lower temperature for factual queries, higher for creative tasks",
        "Use top_k to control response focus and variety"
    ]
    
    tier_tips = {
        'basic': ["Try the 'balanced' preset for most tasks", "Experiment with temperature between 0.3-1.0"],
        'premium': ["Use 'experimental' preset for maximum creativity", "High temperature + high top_k = maximum diversity"]
    }
    
    return base_tips + tier_tips.get(user_tier, [])


# Analytics functions
def get_parameter_usage_analytics(days: int = 30) -> Dict[str, Any]:
    """Get system-wide parameter usage analytics"""
    try:
        from models import ParameterUsage, db
        from sqlalchemy import func
        
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        usage_records = db.session.query(ParameterUsage).filter(
            ParameterUsage.created_at >= cutoff_date
        ).all()
        
        analytics = {
            'total_sessions': len(usage_records),
            'unique_users': len(set(r.user_id for r in usage_records if r.user_id)),
            'preset_popularity': {},
            'parameter_distributions': {},
            'safety_override_rate': 0.0,
            'tier_usage': {'free': 0, 'basic': 0, 'premium': 0}
        }
        
        total_overrides = 0
        
        for record in usage_records:
            # Preset popularity
            if record.preset_used:
                analytics['preset_popularity'][record.preset_used] = \
                    analytics['preset_popularity'].get(record.preset_used, 0) + 1
            
            # Parameter distributions
            for param, value in record.parameters.items():
                if param not in analytics['parameter_distributions']:
                    analytics['parameter_distributions'][param] = []
                analytics['parameter_distributions'][param].append(value)
            
            # Safety overrides
            if record.safety_overrides:
                total_overrides += len(record.safety_overrides)
        
        # Calculate override rate
        if usage_records:
            analytics['safety_override_rate'] = total_overrides / len(usage_records)
        
        # Calculate parameter statistics
        for param, values in analytics['parameter_distributions'].items():
            if values:
                analytics['parameter_distributions'][param] = {
                    'min': min(values),
                    'max': max(values),
                    'avg': sum(values) / len(values),
                    'median': sorted(values)[len(values)//2]
                }
        
        return analytics
        
    except Exception as e:
        logger.error(f"Error getting parameter analytics: {e}")
        return {'error': str(e)}