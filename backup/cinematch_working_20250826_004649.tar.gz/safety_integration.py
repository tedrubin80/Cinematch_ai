# safety_integration.py - Integration module for all safety systems

"""
Integration module for Cinematch safety and guardrails systems.
This module provides the main integration functions to connect all
safety components including age verification, content filtering,
parameter controls, and safety monitoring to the main application.
"""

import logging
from flask import Flask, Blueprint, request, jsonify, render_template, session
from flask_login import current_user
from functools import wraps

# Import all safety modules
from age_verification import AgeVerificationManager, age_verified_required
from guardrails import ContentFilter, ResponseSanitizer, content_filter_required, get_user_safety_score
from parameter_controls import ParameterController, parameter_controls_required, get_user_parameter_interface
from safety_monitor import SafetyMonitor, safety_monitor, log_safety_event, get_safety_dashboard_data

logger = logging.getLogger(__name__)

# Create blueprint for safety routes
safety_bp = Blueprint('safety', __name__, url_prefix='/api/safety')

def integrate_safety_systems(app: Flask):
    """
    Integrate all safety systems with the Flask app.
    
    This function should be called in your main app.py create_app() function
    to add all the safety and guardrails features.
    """
    
    # 1. Initialize safety components
    try:
        content_filter = ContentFilter()
        response_sanitizer = ResponseSanitizer()
        parameter_controller = ParameterController()
        age_verification_manager = AgeVerificationManager()
        
        logger.info("Safety components initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize safety components: {e}")
        raise
    
    # 2. Register safety blueprint
    app.register_blueprint(safety_bp)
    
    # 3. Add safety configuration
    app.config.setdefault('SAFETY_ENABLED', True)
    app.config.setdefault('AGE_VERIFICATION_REQUIRED', True)
    app.config.setdefault('CONTENT_FILTERING_STRICT_MODE', False)
    app.config.setdefault('PARAMETER_VALIDATION_ENABLED', True)
    app.config.setdefault('SAFETY_MONITORING_ENABLED', True)
    
    # 4. Add template globals for safety info
    @app.template_global()
    def is_age_verified():
        """Template function to check age verification status"""
        try:
            return age_verification_manager.check_verification_status(
                session.get('session_id', ''),
                request.remote_addr
            )['is_verified']
        except:
            return False
    
    @app.template_global()
    def get_user_safety_status():
        """Template function to get user's safety status"""
        if current_user.is_authenticated:
            return get_user_safety_score(current_user.id)
        return None
    
    @app.template_global()
    def get_parameter_controls():
        """Template function to get parameter controls for current user"""
        if current_user.is_authenticated:
            tier = getattr(current_user, 'current_tier', 'free')
            return get_user_parameter_interface(tier)
        return get_user_parameter_interface('free')
    
    # 5. Add before_request handlers for safety checks
    @app.before_request
    def safety_before_request():
        """Run safety checks before each request"""
        if not app.config.get('SAFETY_ENABLED', True):
            return
        
        # Skip safety checks for static files and safety endpoints
        if (request.endpoint and 
            (request.endpoint.startswith('static') or
             request.endpoint.startswith('safety'))):
            return
        
        # Age verification check - temporarily disabled to fix errors
        # TODO: Implement proper age verification check
        pass
    
    # 6. Add after_request handlers for response sanitization
    @app.after_request
    def sanitize_responses(response):
        """Sanitize responses for safety"""
        if not app.config.get('SAFETY_ENABLED', True):
            return response
        
        # Only sanitize API responses, not template pages
        if response.mimetype == 'application/json' and request.path.startswith('/api/'):
            try:
                # Sanitize JSON response content
                import json
                data = response.get_json()
                if data and isinstance(data, dict):
                    # Sanitize specific fields that might contain AI responses
                    sanitizable_fields = ['response', 'content', 'message', 'text']
                    for field in sanitizable_fields:
                        if field in data and isinstance(data[field], str):
                            data[field] = response_sanitizer.sanitize_response(data[field])
                    response.set_data(json.dumps(data))
            except Exception as e:
                logger.error(f"Error sanitizing response: {e}")
        
        return response
    
    # 7. Add error handlers for safety-related errors
    @app.errorhandler(403)
    def handle_safety_forbidden(e):
        """Handle safety-related forbidden errors"""
        if request.is_json:
            return jsonify({'error': 'Access forbidden by safety policy'}), 403
        return render_template('errors/safety_forbidden.html'), 403
    
    @app.errorhandler(429)
    def handle_safety_rate_limit(e):
        """Handle safety rate limiting"""
        if request.is_json:
            return jsonify({'error': 'Rate limit exceeded'}), 429
        return render_template('errors/rate_limit.html'), 429
    
    # 8. Add CLI commands for safety management
    @app.cli.command()
    def init_safety_db():
        """Initialize safety database tables"""
        from models import db
        try:
            from models import (AgeVerification, SafetyViolation, ParameterUsage, 
                               SafetyReport, SafetyLog)
            
            print("Creating safety system tables...")
            db.create_all()
            print("✅ Safety database initialized successfully!")
            
        except Exception as e:
            print(f"❌ Error initializing safety database: {e}")
            db.session.rollback()
    
    @app.cli.command()
    def safety_stats():
        """Show safety system statistics"""
        try:
            from models import SafetyViolation, AgeVerification, ParameterUsage, db
            from sqlalchemy import func
            from datetime import datetime, timedelta
            
            # Get stats from last 7 days
            week_ago = datetime.utcnow() - timedelta(days=7)
            
            # Violation stats
            violations = db.session.query(
                SafetyViolation.severity,
                func.count(SafetyViolation.id).label('count')
            ).filter(SafetyViolation.created_at >= week_ago).group_by(SafetyViolation.severity).all()
            
            # Age verification stats
            age_verifications = db.session.query(func.count(AgeVerification.id)).filter(
                AgeVerification.verified_at >= week_ago
            ).scalar()
            
            # Parameter usage stats
            parameter_usage_count = db.session.query(func.count(ParameterUsage.id)).filter(
                ParameterUsage.created_at >= week_ago
            ).scalar()
            
            print("\n🛡️  Safety System Statistics (Last 7 Days):")
            print("-" * 50)
            print(f"Age Verifications: {age_verifications or 0}")
            print(f"Parameter Usage Records: {parameter_usage_count or 0}")
            print("\n📊 Violations by Severity:")
            total_violations = 0
            for severity, count in violations:
                print(f"  {severity.capitalize():10}: {count:4d}")
                total_violations += count
            print(f"  {'Total':10}: {total_violations:4d}")
            
            if total_violations == 0:
                print("\n✅ No safety violations detected - system operating normally!")
            elif total_violations < 10:
                print("\n✅ Low violation rate - system operating well")
            else:
                print("\n⚠️  Elevated violation rate - consider reviewing safety policies")
            
        except Exception as e:
            print(f"❌ Error getting safety stats: {e}")
    
    @app.cli.command()
    @app.cli.argument('session_id')
    def verify_age_session(session_id):
        """Manually verify age for a session (admin use)"""
        try:
            result = age_verification_manager.verify_age(
                session_id, 18, 'US', 'admin_override'
            )
            
            if result['success']:
                print(f"✅ Session {session_id} age verified successfully")
            else:
                print(f"❌ Failed to verify age for session {session_id}: {result['error']}")
                
        except Exception as e:
            print(f"❌ Error verifying age: {e}")
    
    logger.info("Safety systems integrated successfully")
    return app


# Safety API Routes
@safety_bp.route('/dashboard')
def safety_dashboard():
    """Get safety dashboard data"""
    try:
        hours = int(request.args.get('hours', 24))
        dashboard_data = get_safety_dashboard_data()
        
        return jsonify({
            'success': True,
            'data': dashboard_data
        })
        
    except Exception as e:
        logger.error(f"Error getting safety dashboard data: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to load dashboard data'
        }), 500

@safety_bp.route('/verify-age', methods=['POST'])
def verify_age():
    """API endpoint for age verification"""
    try:
        data = request.get_json()
        required_fields = ['birth_month', 'birth_day', 'birth_year', 'country']
        
        if not all(field in data for field in required_fields):
            return jsonify({
                'success': False,
                'error': 'Missing required fields'
            }), 400
        
        # Calculate age
        from datetime import date
        birth_date = date(
            int(data['birth_year']),
            int(data['birth_month']),
            int(data['birth_day'])
        )
        today = date.today()
        age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
        
        session_id = session.get('session_id', request.remote_addr)
        age_manager = AgeVerificationManager()
        
        result = age_manager.verify_age(
            session_id,
            age,
            data['country'],
            'self_declaration',
            user_agent=request.headers.get('User-Agent')
        )
        
        if result['success']:
            # Store verification token in session
            session['age_verified'] = True
            session['age_verification_token'] = result.get('verification_token')
            
            # Log the successful verification
            log_safety_event(
                'age_verification',
                'low',
                'age_verification',
                {
                    'age': age,
                    'country': data['country'],
                    'method': 'self_declaration'
                },
                current_user.id if current_user.is_authenticated else None,
                session_id
            )
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error in age verification: {e}")
        return jsonify({
            'success': False,
            'error': 'Verification failed'
        }), 500

@safety_bp.route('/check-age-verification')
def check_age_verification():
    """Check if current session is age verified"""
    try:
        session_id = session.get('session_id', request.remote_addr)
        age_manager = AgeVerificationManager()
        
        result = age_manager.check_verification_status(session_id, request.remote_addr)
        
        return jsonify({
            'verified': result['is_verified'],
            'verification_token': session.get('age_verification_token')
        })
        
    except Exception as e:
        logger.error(f"Error checking age verification: {e}")
        return jsonify({'verified': False})

@safety_bp.route('/parameter-controls/settings')
def get_parameter_settings():
    """Get parameter control settings for current user"""
    try:
        user_tier = 'free'
        if current_user.is_authenticated:
            user_tier = getattr(current_user, 'current_tier', 'free')
        
        parameter_controller = ParameterController()
        interface_data = get_user_parameter_interface(user_tier)
        
        # Add recommendations
        if current_user.is_authenticated:
            recommendations = {
                'preset': parameter_controller.get_optimal_preset_recommendation(current_user.id)
            }
        else:
            recommendations = {
                'preset': ('conservative', 'Recommended for new users')
            }
        
        interface_data['recommendations'] = recommendations
        
        return jsonify({
            'success': True,
            **interface_data
        })
        
    except Exception as e:
        logger.error(f"Error getting parameter settings: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to load parameter settings'
        }), 500

@safety_bp.route('/user-safety-status')
def get_user_safety_status():
    """Get safety status for current user"""
    try:
        if not current_user.is_authenticated:
            return jsonify({
                'success': False,
                'error': 'Authentication required'
            }), 401
        
        safety_score = get_user_safety_score(current_user.id)
        
        return jsonify({
            'success': True,
            'safety_status': safety_score
        })
        
    except Exception as e:
        logger.error(f"Error getting user safety status: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to get safety status'
        }), 500

@safety_bp.route('/content-filter', methods=['POST'])
def filter_content():
    """API endpoint for content filtering"""
    try:
        data = request.get_json()
        if not data or 'content' not in data:
            return jsonify({
                'success': False,
                'error': 'Content is required'
            }), 400
        
        content_filter = ContentFilter()
        user_id = current_user.id if current_user.is_authenticated else None
        strict_mode = data.get('strict_mode', False)
        
        result = content_filter.filter_content(data['content'], user_id, strict_mode)
        
        return jsonify({
            'success': True,
            'is_safe': result.is_safe,
            'filtered_content': result.filtered_content,
            'violations': result.violations,
            'severity': result.severity,
            'confidence': result.confidence,
            'processing_time_ms': result.processing_time_ms
        })
        
    except Exception as e:
        logger.error(f"Error filtering content: {e}")
        return jsonify({
            'success': False,
            'error': 'Content filtering failed'
        }), 500


# Decorator factory for AI endpoint protection
def ai_endpoint_protection(require_age_verification=True, enable_content_filtering=True, 
                          enable_parameter_validation=True, strict_mode=False):
    """
    Comprehensive decorator for AI endpoints that combines all safety measures.
    
    Args:
        require_age_verification: Whether to require age verification
        enable_content_filtering: Whether to enable content filtering
        enable_parameter_validation: Whether to validate AI parameters
        strict_mode: Whether to use strict content filtering
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Apply decorators in order based on configuration
            if require_age_verification:
                # Check age verification
                session_id = session.get('session_id', request.remote_addr)
                age_manager = AgeVerificationManager()
                verification_status = age_manager.check_verification_status(session_id, request.remote_addr)
                
                if not verification_status['is_verified']:
                    return jsonify({
                        'error': 'Age verification required',
                        'redirect': '/age-verification'
                    }), 403
            
            # Apply content filtering if enabled
            if enable_content_filtering:
                content_filter_decorator = content_filter_required(strict_mode)
                f = content_filter_decorator(f)
            
            # Apply parameter validation if enabled
            if enable_parameter_validation:
                f = parameter_controls_required(f)
            
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator


# Utility functions for integration
def get_safety_config():
    """Get current safety configuration"""
    from flask import current_app
    return {
        'safety_enabled': current_app.config.get('SAFETY_ENABLED', True),
        'age_verification_required': current_app.config.get('AGE_VERIFICATION_REQUIRED', True),
        'content_filtering_strict_mode': current_app.config.get('CONTENT_FILTERING_STRICT_MODE', False),
        'parameter_validation_enabled': current_app.config.get('PARAMETER_VALIDATION_ENABLED', True),
        'safety_monitoring_enabled': current_app.config.get('SAFETY_MONITORING_ENABLED', True)
    }

def log_ai_request(endpoint, user_id, parameters, response_data, safety_checks):
    """Log AI request with safety information"""
    try:
        log_safety_event(
            'ai_request',
            'low',
            'ai_endpoint',
            {
                'endpoint': endpoint,
                'parameters': parameters,
                'response_length': len(str(response_data)),
                'safety_checks': safety_checks
            },
            user_id,
            session.get('session_id')
        )
    except Exception as e:
        logger.error(f"Error logging AI request: {e}")

def validate_ai_response(response_content):
    """Validate AI response for safety"""
    try:
        content_filter = ContentFilter()
        response_sanitizer = ResponseSanitizer()
        
        # Filter the response content
        filter_result = content_filter.filter_content(response_content)
        
        # Sanitize the response
        sanitized_response = response_sanitizer.sanitize_response(filter_result.filtered_content)
        
        return {
            'is_safe': filter_result.is_safe,
            'sanitized_content': sanitized_response,
            'violations': filter_result.violations,
            'safety_score': 1.0 - filter_result.confidence if not filter_result.is_safe else 1.0
        }
    except Exception as e:
        logger.error(f"Error validating AI response: {e}")
        return {
            'is_safe': False,
            'sanitized_content': 'Response blocked for safety',
            'violations': [{'type': 'validation_error', 'message': 'Unable to validate response'}],
            'safety_score': 0.0
        }


# Example integration in main app.py:
"""
# Add this to your main app.py create_app() function:

from safety_integration import integrate_safety_systems, ai_endpoint_protection

def create_app():
    app = Flask(__name__)
    
    # ... existing app configuration ...
    
    # Initialize safety systems
    integrate_safety_systems(app)
    
    # Example of protecting an AI endpoint
    @app.route('/api/ai/recommend', methods=['POST'])
    @ai_endpoint_protection(
        require_age_verification=True,
        enable_content_filtering=True,
        enable_parameter_validation=True,
        strict_mode=False
    )
    def ai_recommend():
        # Your AI endpoint logic here
        # Parameters will be validated
        # Content will be filtered
        # Age verification will be checked
        pass
    
    return app
"""