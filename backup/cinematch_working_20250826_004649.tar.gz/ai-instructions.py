# ai_instructions.py - AI Agent behavior and instruction management

from typing import Dict, List, Optional
from datetime import datetime
import json
from sqlalchemy import Column, String, Text, Boolean, DateTime, Integer, JSON
from models import db

class AIInstruction(db.Model):
    """Store AI agent instructions and behavior configurations"""
    __tablename__ = 'ai_instructions'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    instruction_type = db.Column(db.String(50), nullable=False)  # 'system', 'behavior', 'context', 'style'
    content = db.Column(db.Text, nullable=False)
    priority = db.Column(db.Integer, default=1)  # Higher priority instructions override lower
    active = db.Column(db.Boolean, default=True)
    conditions = db.Column(JSON)  # Conditions when this instruction applies
    metadata = db.Column(JSON)  # Additional configuration
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.String(36), db.ForeignKey('users.id'))


class AIInstructionManager:
    """Manage AI agent instructions and behaviors"""
    
    def __init__(self, db, cache):
        self.db = db
        self.cache = cache
        self.default_instructions = self._load_default_instructions()
    
    def _load_default_instructions(self) -> Dict[str, str]:
        """Load default system instructions"""
        return {
            'system': """You are Cinematch, an AI movie recommendation assistant designed specifically for adult audiences (18+). 
Your primary goal is to provide personalized, thoughtful movie recommendations based on user preferences, mood, and context.

Core behaviors:
1. Always be helpful, friendly, and enthusiastic about movies
2. Provide specific movie recommendations with brief explanations
3. Consider content ratings and age-appropriateness
4. Ask clarifying questions when needed to better understand preferences
5. Avoid recommending the same movies repeatedly unless specifically requested
6. Include diverse recommendations across genres, eras, and cultures when appropriate""",
            
            'style': """Communication style:
- Be conversational but professional
- Use movie-related emojis occasionally 🎬 🍿 🎭
- Keep responses concise but informative
- Show enthusiasm for great films
- Be honest about movie qualities (both strengths and weaknesses)
- Use casual language but avoid slang that might date quickly""",
            
            'behavior': """Behavioral guidelines:
- Never break character as a movie recommendation AI
- Don't discuss topics unrelated to movies, TV shows, or entertainment
- Politely redirect off-topic conversations back to movie recommendations
- If asked about your nature, acknowledge you're an AI designed for movie recommendations
- Respect user preferences without judgment
- Be culturally sensitive and inclusive in recommendations""",
            
            'context': """Context awareness:
- Remember the user is 18+ (verified)
- Consider time of day, day of week, and seasons when relevant
- Account for current events or trends in movie releases
- Understand different viewing contexts (date night, family time, solo viewing, etc.)
- Consider platform availability when possible
- Be aware of movie franchises and series connections""",
            
            'safety': """Safety protocols:
- Never recommend content that violates platform guidelines
- Respect content warnings and trigger sensitivities
- Don't make assumptions about user demographics beyond age verification
- Avoid recommending pirated content or illegal viewing methods
- Include content warnings for potentially sensitive material
- Maintain appropriate boundaries in conversations""",
            
            'recommendation_strategy': """Recommendation approach:
1. Start with 3-5 solid recommendations unless more are requested
2. Include a mix of popular and hidden gems
3. Briefly explain why each movie fits the request
4. Mention key details: year, director, main actors, genre
5. Note any content warnings or ratings
6. Suggest similar movies if the user likes a recommendation
7. Be prepared to explain your reasoning if asked""",
            
            'special_instructions': """Special behaviors:
- For "surprise me" requests: Be creative and unexpected
- For specific genres: Show deep knowledge and enthusiasm
- For mood-based requests: Focus on emotional resonance
- For "nothing to watch" complaints: Be extra helpful and engaging
- For repeat users: Try to remember previous interactions if context allows
- For controversial films: Present balanced perspectives"""
        }
    
    def get_instructions_for_context(self, context: Dict) -> str:
        """Get compiled instructions based on context"""
        cache_key = f"ai_instructions:{json.dumps(context, sort_keys=True)}"
        cached = self.cache.get(cache_key)
        if cached:
            return cached
        
        # Start with default instructions
        compiled_instructions = []
        
        # Add active system instructions
        system_instructions = AIInstruction.query.filter_by(
            active=True,
            instruction_type='system'
        ).order_by(AIInstruction.priority.desc()).all()
        
        for instruction in system_instructions:
            if self._check_conditions(instruction.conditions, context):
                compiled_instructions.append(instruction.content)
        
        # Add behavior instructions
        behavior_instructions = AIInstruction.query.filter_by(
            active=True,
            instruction_type='behavior'
        ).order_by(AIInstruction.priority.desc()).all()
        
        for instruction in behavior_instructions:
            if self._check_conditions(instruction.conditions, context):
                compiled_instructions.append(instruction.content)
        
        # Add style instructions
        style_instructions = AIInstruction.query.filter_by(
            active=True,
            instruction_type='style'
        ).order_by(AIInstruction.priority.desc()).all()
        
        for instruction in style_instructions:
            if self._check_conditions(instruction.conditions, context):
                compiled_instructions.append(instruction.content)
        
        # Add context-specific instructions
        context_instructions = AIInstruction.query.filter_by(
            active=True,
            instruction_type='context'
        ).order_by(AIInstruction.priority.desc()).all()
        
        for instruction in context_instructions:
            if self._check_conditions(instruction.conditions, context):
                compiled_instructions.append(instruction.content)
        
        # Compile final instructions
        final_instructions = "\n\n".join(compiled_instructions)
        
        # Add dynamic context
        final_instructions += self._add_dynamic_context(context)
        
        # Cache the result
        self.cache.setex(cache_key, 3600, final_instructions)
        
        return final_instructions
    
    def _check_conditions(self, conditions: Dict, context: Dict) -> bool:
        """Check if conditions match the current context"""
        if not conditions:
            return True
        
        for key, value in conditions.items():
            if key not in context:
                return False
            
            # Handle different condition types
            if isinstance(value, list):
                if context[key] not in value:
                    return False
            elif isinstance(value, dict):
                # Handle complex conditions
                if 'min' in value and context[key] < value['min']:
                    return False
                if 'max' in value and context[key] > value['max']:
                    return False
                if 'equals' in value and context[key] != value['equals']:
                    return False
                if 'contains' in value and value['contains'] not in context[key]:
                    return False
            else:
                if context[key] != value:
                    return False
        
        return True
    
    def _add_dynamic_context(self, context: Dict) -> str:
        """Add dynamic context information to instructions"""
        dynamic_parts = ["\n\nCurrent context:"]
        
        # Time context
        now = datetime.now()
        time_of_day = "evening" if now.hour >= 18 else "afternoon" if now.hour >= 12 else "morning"
        day_of_week = now.strftime("%A")
        
        dynamic_parts.append(f"- Current time: {time_of_day} on {day_of_week}")
        
        # User context
        if 'user_mood' in context:
            dynamic_parts.append(f"- User mood: {context['user_mood']}")
        
        if 'viewing_context' in context:
            dynamic_parts.append(f"- Viewing context: {context['viewing_context']}")
        
        if 'previous_recommendations' in context:
            dynamic_parts.append(f"- Recently recommended: {', '.join(context['previous_recommendations'][:3])}")
        
        if 'genre_preferences' in context:
            dynamic_parts.append(f"- Known preferences: {', '.join(context['genre_preferences'])}")
        
        # Seasonal context
        month = now.month
        if month in [12, 1, 2]:
            dynamic_parts.append("- Season: Winter (consider holiday/cozy films)")
        elif month in [3, 4, 5]:
            dynamic_parts.append("- Season: Spring (consider uplifting/renewal themes)")
        elif month in [6, 7, 8]:
            dynamic_parts.append("- Season: Summer (consider blockbusters/adventure)")
        else:
            dynamic_parts.append("- Season: Fall (consider atmospheric/dramatic films)")
        
        return "\n".join(dynamic_parts)
    
    def add_instruction(self, name: str, instruction_type: str, content: str, 
                       priority: int = 1, conditions: Optional[Dict] = None,
                       metadata: Optional[Dict] = None, created_by: Optional[str] = None) -> AIInstruction:
        """Add a new instruction"""
        instruction = AIInstruction(
            name=name,
            instruction_type=instruction_type,
            content=content,
            priority=priority,
            conditions=conditions or {},
            metadata=metadata or {},
            created_by=created_by
        )
        
        self.db.session.add(instruction)
        self.db.session.commit()
        
        # Clear cache
        self.cache.delete("ai_instructions:*")
        
        return instruction
    
    def update_instruction(self, instruction_id: int, **kwargs) -> Optional[AIInstruction]:
        """Update an existing instruction"""
        instruction = AIInstruction.query.get(instruction_id)
        if not instruction:
            return None
        
        for key, value in kwargs.items():
            if hasattr(instruction, key):
                setattr(instruction, key, value)
        
        instruction.updated_at = datetime.utcnow()
        self.db.session.commit()
        
        # Clear cache
        self.cache.delete("ai_instructions:*")
        
        return instruction
    
    def get_instruction_by_name(self, name: str) -> Optional[AIInstruction]:
        """Get instruction by name"""
        return AIInstruction.query.filter_by(name=name).first()
    
    def get_all_instructions(self, instruction_type: Optional[str] = None, active_only: bool = True) -> List[AIInstruction]:
        """Get all instructions, optionally filtered"""
        query = AIInstruction.query
        
        if instruction_type:
            query = query.filter_by(instruction_type=instruction_type)
        
        if active_only:
            query = query.filter_by(active=True)
        
        return query.order_by(AIInstruction.priority.desc()).all()
    
    def toggle_instruction(self, instruction_id: int) -> bool:
        """Toggle instruction active status"""
        instruction = AIInstruction.query.get(instruction_id)
        if instruction:
            instruction.active = not instruction.active
            self.db.session.commit()
            # Clear cache
            self.cache.delete("ai_instructions:*")
            return True
        return False
    
    def delete_instruction(self, instruction_id: int) -> bool:
        """Delete an instruction"""
        instruction = AIInstruction.query.get(instruction_id)
        if instruction:
            self.db.session.delete(instruction)
            self.db.session.commit()
            # Clear cache
            self.cache.delete("ai_instructions:*")
            return True
        return False
    
    def load_default_instructions_to_db(self):
        """Load default instructions into database if not exists"""
        for name, content in self.default_instructions.items():
            if not self.get_instruction_by_name(f"default_{name}"):
                self.add_instruction(
                    name=f"default_{name}",
                    instruction_type=name if name in ['system', 'behavior', 'context', 'style'] else 'behavior',
                    content=content,
                    priority=1,
                    metadata={'is_default': True}
                )
    
    def export_instructions(self) -> Dict:
        """Export all instructions for backup"""
        instructions = self.get_all_instructions(active_only=False)
        return {
            'exported_at': datetime.utcnow().isoformat(),
            'instructions': [
                {
                    'name': i.name,
                    'type': i.instruction_type,
                    'content': i.content,
                    'priority': i.priority,
                    'active': i.active,
                    'conditions': i.conditions,
                    'metadata': i.metadata
                }
                for i in instructions
            ]
        }
    
    def import_instructions(self, data: Dict) -> int:
        """Import instructions from backup"""
        count = 0
        for instruction_data in data.get('instructions', []):
            existing = self.get_instruction_by_name(instruction_data['name'])
            if existing:
                self.update_instruction(
                    existing.id,
                    content=instruction_data['content'],
                    priority=instruction_data.get('priority', 1),
                    active=instruction_data.get('active', True),
                    conditions=instruction_data.get('conditions', {}),
                    metadata=instruction_data.get('metadata', {})
                )
            else:
                self.add_instruction(
                    name=instruction_data['name'],
                    instruction_type=instruction_data['type'],
                    content=instruction_data['content'],
                    priority=instruction_data.get('priority', 1),
                    conditions=instruction_data.get('conditions', {}),
                    metadata=instruction_data.get('metadata', {})
                )
            count += 1
        
        return count