# movie_agent.py - LangChain-based movie recommendation agent

from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationBufferMemory
from langchain.schema import BaseOutputParser
from langchain_anthropic import ChatAnthropic
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import PGVector
from typing import Dict, List, Optional, Any
import json
import time
import re
from datetime import datetime

class MovieAgent:
    """Main movie recommendation agent using LangChain"""
    
    def __init__(self, db, cache):
        self.db = db
        self.cache = cache
        self.embeddings = None
        self.vector_store = None
        self.llm_router = LLMRouter(db, cache)
        
        # Initialize embeddings if OpenAI key is available
        self._init_embeddings()
        
        # Movie recommendation prompt
        self.movie_prompt = PromptTemplate(
            input_variables=["query", "context", "chat_history"],
            template="""You are Cinematch, an AI movie recommendation assistant. You help users find movies they'll love based on their preferences.

Context from knowledge base:
{context}

Chat History:
{chat_history}

User Query: {query}

Instructions:
1. Provide personalized movie recommendations based on the user's request
2. Consider the chat history for context about their preferences
3. Include brief, engaging descriptions for each recommendation
4. If asked about mature content, remind users this service is 18+ only
5. Format your response in a conversational, friendly tone
6. Use emojis sparingly to enhance the experience (🎬 🍿 ⭐)

Response:"""
        )
        
        # Safety check prompt
        self.safety_prompt = PromptTemplate(
            input_variables=["query"],
            template="""Analyze if this movie request might require age verification or contains inappropriate content:

Query: {query}

Return a JSON response:
{{
    "requires_age_check": boolean,
    "content_rating": "G" | "PG" | "PG-13" | "R" | "NC-17",
    "reason": "brief explanation if age check needed"
}}"""
        )
    
    def _init_embeddings(self):
        """Initialize embeddings and vector store"""
        from models import APIKey
        
        # Check for OpenAI API key
        openai_key = APIKey.query.filter_by(service='openai', is_active=True).first()
        if openai_key:
            from app import cipher_suite
            decrypted_key = cipher_suite.decrypt(openai_key.encrypted_key.encode()).decode()
            
            self.embeddings = OpenAIEmbeddings(openai_api_key=decrypted_key)
            
            # Initialize PGVector store
            from sqlalchemy import create_engine
            from app import app
            
            self.vector_store = PGVector(
                connection_string=app.config['SQLALCHEMY_DATABASE_URI'],
                embedding_function=self.embeddings,
                collection_name="movie_documents"
            )
    
    def process_request(self, session_id: str, query: str, temperature: float = 0.7, top_k: int = 20) -> Dict:
        """Process a movie recommendation request"""
        start_time = time.time()
        
        # Get relevant context from vector store
        context = self._get_relevant_context(query) if self.vector_store else ""
        
        # Get chat history
        chat_history = self._get_chat_history(session_id)
        
        # Check safety first
        safety_check = self._check_content_safety(query)
        
        # Route to appropriate LLM
        llm_config = self.llm_router.route_query(query, safety_check)
        llm = self._get_llm(llm_config['llm'], temperature, top_k)
        
        # Create chain
        chain = LLMChain(
            llm=llm,
            prompt=self.movie_prompt,
            verbose=True
        )
        
        # Generate response
        response = chain.run(
            query=query,
            context=context,
            chat_history=chat_history
        )
        
        # Calculate response time
        response_time_ms = int((time.time() - start_time) * 1000)
        
        return {
            'response': response,
            'llm_used': llm_config['llm'],
            'requires_age_verification': safety_check.get('requires_age_check', False),
            'content_rating': safety_check.get('content_rating', 'PG'),
            'response_time_ms': response_time_ms
        }
    
    def _get_relevant_context(self, query: str, k: int = 3) -> str:
        """Retrieve relevant context from vector store"""
        if not self.vector_store:
            return ""
        
        try:
            # Search for similar documents
            docs = self.vector_store.similarity_search(query, k=k)
            
            # Format context
            context_parts = []
            for doc in docs:
                context_parts.append(f"- {doc.page_content}")
            
            return "\n".join(context_parts) if context_parts else ""
        except Exception as e:
            print(f"Error retrieving context: {e}")
            return ""
    
    def _get_chat_history(self, session_id: str, limit: int = 5) -> str:
        """Get recent chat history for context"""
        cache_key = f"chat_history:{session_id}"
        cached = self.cache.get(cache_key)
        
        if cached:
            return cached
        
        # Get from database
        from models import ChatLog
        recent_chats = ChatLog.query.filter_by(
            session_id=session_id
        ).order_by(ChatLog.created_at.desc()).limit(limit).all()
        
        history_parts = []
        for chat in reversed(recent_chats):
            if chat.user_input and chat.bot_response:
                history_parts.append(f"User: {chat.user_input}")
                history_parts.append(f"Assistant: {chat.bot_response}")
        
        history = "\n".join(history_parts)
        
        # Cache for 5 minutes
        self.cache.setex(cache_key, 300, history)
        
        return history
    
    def _check_content_safety(self, query: str) -> Dict:
        """Check if content requires age verification"""
        # Quick keyword check
        mature_keywords = ['horror', 'violent', 'adult', 'explicit', 'gore', 'rated r', 'nc-17']
        query_lower = query.lower()
        
        for keyword in mature_keywords:
            if keyword in query_lower:
                return {
                    'requires_age_check': True,
                    'content_rating': 'R',
                    'reason': f'Query contains mature content keyword: {keyword}'
                }
        
        return {
            'requires_age_check': False,
            'content_rating': 'PG',
            'reason': None
        }
    
    def _get_llm(self, llm_type: str, temperature: float, top_k: int):
        """Get configured LLM instance"""
        from models import APIKey
        from app import cipher_suite
        
        if llm_type == 'claude':
            api_key = APIKey.query.filter_by(service='anthropic', is_active=True).first()
            if api_key:
                decrypted_key = cipher_suite.decrypt(api_key.encrypted_key.encode()).decode()
                return ChatAnthropic(
                    anthropic_api_key=decrypted_key,
                    model_name="claude-3-sonnet-20240229",
                    temperature=temperature,
                    top_k=top_k
                )
        
        # Default to Gemini
        api_key = APIKey.query.filter_by(service='google', is_active=True).first()
        if api_key:
            decrypted_key = cipher_suite.decrypt(api_key.encrypted_key.encode()).decode()
            return ChatGoogleGenerativeAI(
                google_api_key=decrypted_key,
                model="gemini-pro",
                temperature=temperature,
                top_k=top_k
            )
        
        raise ValueError("No LLM API keys configured")


class LLMRouter:
    """Routes queries to appropriate LLM based on content"""
    
    def __init__(self, db, cache):
        self.db = db
        self.cache = cache
    
    def route_query(self, query: str, safety_check: Dict) -> Dict:
        """Determine which LLM to use for the query"""
        from models import RoutingConfiguration, ContentRoutingRule
        
        # Get routing configuration
        config = RoutingConfiguration.query.first()
        if not config:
            return {'llm': 'gemini', 'reason': 'default'}
        
        # Check custom routing rules first
        rules = ContentRoutingRule.query.filter_by(
            active=True
        ).order_by(ContentRoutingRule.priority.desc()).all()
        
        for rule in rules:
            if self._match_rule(query, rule):
                return {
                    'llm': rule.target_llm,
                    'reason': f'matched_rule:{rule.rule_name}'
                }
        
        # Apply default routing logic
        query_length = len(query)
        
        # Use Claude for mature content
        if safety_check.get('requires_age_check'):
            return {'llm': 'claude', 'reason': 'mature_content'}
        
        # Use Claude for long, complex queries
        if query_length > config.content_length_threshold:
            return {'llm': 'claude', 'reason': 'complex_query'}
        
        # Check if cross-validation is needed
        if config.enable_cross_validation:
            for keyword in config.cross_validation_keywords or []:
                if keyword.lower() in query.lower():
                    return {'llm': 'both', 'reason': 'cross_validation'}
        
        # Default routing based on thresholds
        import random
        rand = random.random()
        
        if rand < config.use_claude_threshold:
            return {'llm': 'claude', 'reason': 'threshold'}
        else:
            return {'llm': 'gemini', 'reason': 'threshold'}
    
    def _match_rule(self, query: str, rule) -> bool:
        """Check if query matches a routing rule"""
        if rule.condition_type == 'keyword':
            return rule.condition_value.lower() in query.lower()
        elif rule.condition_type == 'regex':
            import re
            return bool(re.search(rule.condition_value, query, re.IGNORECASE))
        elif rule.condition_type == 'sentiment':
            # Simple sentiment check (could be enhanced)
            return float(rule.condition_value) > 0.5
        
        return False


class MovieDocumentIndexer:
    """Index movie documents for vector search"""
    
    def __init__(self, embeddings, vector_store):
        self.embeddings = embeddings
        self.vector_store = vector_store
    
    def index_document(self, title: str, content: str, metadata: Dict = None):
        """Index a movie document"""
        from models import MovieDocument
        from app import db
        
        # Generate embedding
        embedding = self.embeddings.embed_query(content)
        
        # Store in database
        doc = MovieDocument(
            title=title,
            content=content,
            metadata=metadata or {},
            embedding=embedding
        )
        
        db.session.add(doc)
        db.session.commit()
        
        # Add to vector store
        self.vector_store.add_texts(
            texts=[content],
            metadatas=[{"title": title, **metadata}] if metadata else [{"title": title}]
        )
        
        return doc.id
    
    def search_movies(self, query: str, k: int = 5) -> List[Dict]:
        """Search for movies using vector similarity"""
        docs = self.vector_store.similarity_search_with_score(query, k=k)
        
        results = []
        for doc, score in docs:
            results.append({
                'title': doc.metadata.get('title', 'Unknown'),
                'content': doc.page_content,
                'score': score,
                'metadata': doc.metadata
            })
        
        return results