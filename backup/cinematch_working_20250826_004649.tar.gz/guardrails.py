# guardrails.py - Comprehensive content safety and guardrails system

"""
Advanced content safety system for Cinematch.
Provides multi-layer content filtering, PII detection, profanity blocking,
harmful content detection, and safety compliance monitoring.
"""

import re
import html
import logging
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from flask import current_app, request, session
from functools import wraps

# Import profanity detection libraries (install with: pip install better-profanity profanity-check2)
try:
    from better_profanity import profanity
    profanity.load_censor_words()
    PROFANITY_AVAILABLE = True
except ImportError:
    PROFANITY_AVAILABLE = False
    
try:
    from profanity_check import predict as profanity_predict
    PROFANITY_CHECK_AVAILABLE = True
except ImportError:
    PROFANITY_CHECK_AVAILABLE = False

logger = logging.getLogger(__name__)

@dataclass
class FilterResult:
    """Result of content filtering operation"""
    is_safe: bool
    filtered_content: str
    violations: List[Dict[str, Any]]
    severity: str  # 'low', 'medium', 'high', 'critical'
    confidence: float
    processing_time_ms: int

@dataclass
class PIIDetectionResult:
    """Result of PII detection scan"""
    has_pii: bool
    detected_types: List[str]
    masked_content: str
    pii_count: int
    locations: List[Dict[str, Any]]

# Comprehensive PII detection patterns
PII_PATTERNS = {
    'email': {
        'pattern': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        'replacement': '[EMAIL_REDACTED]',
        'severity': 'medium',
        'description': 'Email address'
    },
    'phone': {
        'pattern': r'(\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',
        'replacement': '[PHONE_REDACTED]',
        'severity': 'medium',
        'description': 'Phone number'
    },
    'ssn': {
        'pattern': r'\b\d{3}-?\d{2}-?\d{4}\b',
        'replacement': '[SSN_REDACTED]',
        'severity': 'high',
        'description': 'Social Security Number'
    },
    'credit_card': {
        'pattern': r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',
        'replacement': '[CARD_REDACTED]',
        'severity': 'high',
        'description': 'Credit card number'
    },
    'ip_address': {
        'pattern': r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
        'replacement': '[IP_REDACTED]',
        'severity': 'low',
        'description': 'IP address'
    },
    'address': {
        'pattern': r'\d+\s+[A-Za-z\s]+(?:Street|St|Avenue|Ave|Road|Rd|Drive|Dr|Lane|Ln|Boulevard|Blvd)',
        'replacement': '[ADDRESS_REDACTED]',
        'severity': 'medium',
        'description': 'Street address'
    },
    'url': {
        'pattern': r'https?://[^\s<>"{}|\\^`\[\]]+',
        'replacement': '[URL_REDACTED]',
        'severity': 'low',
        'description': 'URL'
    },
    'financial': {
        'pattern': r'\b(?:routing|account|bank)\s*(?:number|#)?\s*:?\s*\d{6,}\b',
        'replacement': '[FINANCIAL_REDACTED]',
        'severity': 'high',
        'description': 'Financial information'
    }
}

# Harmful content keywords and patterns (comprehensive list)
HARMFUL_KEYWORDS = {
    'violence': [
        'kill', 'murder', 'assassinate', 'torture', 'harm', 'hurt', 'attack',
        'assault', 'violence', 'weapon', 'bomb', 'explosive', 'terrorist',
        'suicide', 'self-harm', 'cutting', 'overdose'
    ],
    'hate_speech': [
        'racist', 'sexist', 'homophobic', 'transphobic', 'bigot', 'supremacist',
        'nazi', 'fascist', 'slur', 'discrimination', 'prejudice'
    ],
    'adult_content': [
        'pornography', 'explicit', 'sexual', 'nude', 'naked', 'erotic',
        'xxx', 'adult', 'mature', 'nsfw', 'sexual content'
    ],
    'illegal_activity': [
        'drugs', 'cocaine', 'heroin', 'methamphetamine', 'cannabis', 'marijuana',
        'trafficking', 'smuggling', 'fraud', 'scam', 'illegal', 'criminal',
        'hacking', 'piracy', 'counterfeiting', 'money laundering'
    ],
    'personal_info': [
        'social security', 'credit card', 'bank account', 'password', 'private key',
        'confidential', 'classified', 'personal information', 'identity theft'
    ],
    'manipulation': [
        'grooming', 'manipulation', 'coercion', 'exploitation', 'predator',
        'stalking', 'harassment', 'bullying', 'intimidation', 'blackmail'
    ]
}

# Context-aware phrases that require special handling
CONTEXTUAL_PATTERNS = {
    'medical_advice': [
        r'\b(?:diagnose|treatment|medication|medical advice|health condition)\b',
        r'\b(?:doctor said|medical professional|prescription)\b'
    ],
    'financial_advice': [
        r'\b(?:investment advice|financial planning|tax advice)\b',
        r'\b(?:stock tip|crypto investment|trading advice)\b'
    ],
    'legal_advice': [
        r'\b(?:legal advice|lawyer|attorney|legal counsel)\b',
        r'\b(?:sue|lawsuit|legal action|court case)\b'
    ]
}

class ContentFilter:
    """Advanced content filtering and safety system"""
    
    def __init__(self):
        self.violation_cache = {}
        self.whitelist_cache = set()
        self.load_custom_word_lists()
        
    def load_custom_word_lists(self):
        """Load custom profanity and safety word lists"""
        try:
            # Load from configuration files if available
            custom_profanity_path = current_app.config.get('CUSTOM_PROFANITY_LIST')
            if custom_profanity_path:
                with open(custom_profanity_path, 'r') as f:
                    custom_words = [line.strip().lower() for line in f.readlines()]
                    if PROFANITY_AVAILABLE:
                        profanity.add_censor_words(custom_words)
                        
        except Exception as e:
            logger.warning(f"Could not load custom word lists: {e}")
    
    def detect_pii(self, content: str) -> PIIDetectionResult:
        """Detect personally identifiable information in content"""
        start_time = datetime.utcnow()
        
        detected_types = []
        locations = []
        masked_content = content
        pii_count = 0
        
        for pii_type, config in PII_PATTERNS.items():
            pattern = config['pattern']
            matches = list(re.finditer(pattern, content, re.IGNORECASE))
            
            if matches:
                detected_types.append(pii_type)
                pii_count += len(matches)
                
                for match in matches:
                    locations.append({
                        'type': pii_type,
                        'start': match.start(),
                        'end': match.end(),
                        'text': match.group(),
                        'severity': config['severity']
                    })
                
                # Mask PII in content
                masked_content = re.sub(
                    pattern, 
                    config['replacement'], 
                    masked_content, 
                    flags=re.IGNORECASE
                )
        
        processing_time = (datetime.utcnow() - start_time).total_seconds() * 1000
        
        return PIIDetectionResult(
            has_pii=bool(detected_types),
            detected_types=detected_types,
            masked_content=masked_content,
            pii_count=pii_count,
            locations=locations
        )
    
    def mask_pii(self, content: str) -> str:
        """Mask PII in content while preserving readability"""
        result = self.detect_pii(content)
        return result.masked_content
    
    def detect_profanity(self, content: str) -> Dict[str, Any]:
        """Multi-method profanity detection with confidence scoring"""
        results = {
            'has_profanity': False,
            'confidence': 0.0,
            'methods_used': [],
            'detected_words': []
        }
        
        content_lower = content.lower()
        
        # Method 1: better-profanity library
        if PROFANITY_AVAILABLE:
            has_profanity_bp = profanity.contains_profanity(content)
            if has_profanity_bp:
                results['has_profanity'] = True
                results['confidence'] = max(results['confidence'], 0.8)
                results['methods_used'].append('better_profanity')
                
                # Extract profane words
                profane_words = [word for word in content_lower.split() 
                               if profanity.contains_profanity(word)]
                results['detected_words'].extend(profane_words)
        
        # Method 2: profanity-check library
        if PROFANITY_CHECK_AVAILABLE:
            try:
                profanity_score = profanity_predict([content])[0]
                if profanity_score > 0.8:
                    results['has_profanity'] = True
                    results['confidence'] = max(results['confidence'], profanity_score)
                    results['methods_used'].append('profanity_check')
            except Exception as e:
                logger.warning(f"Profanity check library error: {e}")
        
        # Method 3: Custom keyword matching
        custom_profanity = self._custom_profanity_check(content_lower)
        if custom_profanity['has_profanity']:
            results['has_profanity'] = True
            results['confidence'] = max(results['confidence'], custom_profanity['confidence'])
            results['methods_used'].append('custom_keywords')
            results['detected_words'].extend(custom_profanity['words'])
        
        return results
    
    def _custom_profanity_check(self, content: str) -> Dict[str, Any]:
        """Custom profanity detection using keyword lists"""
        # Basic profanity word list (expand as needed)
        profane_words = [
            'damn', 'hell', 'shit', 'fuck', 'bitch', 'ass', 'asshole',
            'bastard', 'crap', 'piss', 'whore', 'slut', 'cunt'
        ]
        
        detected_words = []
        for word in profane_words:
            if word in content:
                detected_words.append(word)
        
        return {
            'has_profanity': bool(detected_words),
            'confidence': 0.7 if detected_words else 0.0,
            'words': detected_words
        }
    
    def detect_harmful_content(self, content: str) -> Dict[str, Any]:
        """Detect harmful content using keyword analysis and context"""
        content_lower = content.lower()
        detected_categories = []
        severity_score = 0
        matched_keywords = []
        
        for category, keywords in HARMFUL_KEYWORDS.items():
            category_matches = []
            for keyword in keywords:
                if keyword in content_lower:
                    category_matches.append(keyword)
                    matched_keywords.append({
                        'keyword': keyword,
                        'category': category,
                        'context': self._extract_context(content, keyword)
                    })
            
            if category_matches:
                detected_categories.append({
                    'category': category,
                    'matches': category_matches,
                    'count': len(category_matches)
                })
                
                # Assign severity scores
                severity_weights = {
                    'violence': 0.9,
                    'hate_speech': 0.8,
                    'adult_content': 0.6,
                    'illegal_activity': 0.9,
                    'personal_info': 0.7,
                    'manipulation': 0.8
                }
                severity_score = max(severity_score, severity_weights.get(category, 0.5))
        
        # Check contextual patterns
        contextual_issues = self._check_contextual_patterns(content_lower)
        if contextual_issues:
            detected_categories.extend(contextual_issues)
            severity_score = max(severity_score, 0.4)
        
        return {
            'has_harmful_content': bool(detected_categories),
            'categories': detected_categories,
            'severity_score': severity_score,
            'matched_keywords': matched_keywords,
            'confidence': min(severity_score + 0.1, 1.0)
        }
    
    def _extract_context(self, content: str, keyword: str, context_length: int = 50) -> str:
        """Extract context around a keyword for analysis"""
        content_lower = content.lower()
        keyword_lower = keyword.lower()
        
        index = content_lower.find(keyword_lower)
        if index == -1:
            return ""
        
        start = max(0, index - context_length)
        end = min(len(content), index + len(keyword) + context_length)
        
        return content[start:end].strip()
    
    def _check_contextual_patterns(self, content: str) -> List[Dict[str, Any]]:
        """Check for contextual patterns that might indicate inappropriate content"""
        issues = []
        
        for pattern_type, patterns in CONTEXTUAL_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    issues.append({
                        'category': f'contextual_{pattern_type}',
                        'matches': [pattern_type],
                        'count': 1,
                        'note': f'Content may contain {pattern_type.replace("_", " ")}'
                    })
        
        return issues
    
    def sanitize_html(self, content: str) -> str:
        """Sanitize HTML content to prevent XSS attacks"""
        # Escape HTML characters
        sanitized = html.escape(content)
        
        # Remove potentially dangerous HTML tags
        dangerous_tags = [
            'script', 'iframe', 'object', 'embed', 'form', 'input',
            'button', 'textarea', 'select', 'option', 'link', 'style'
        ]
        
        for tag in dangerous_tags:
            # Remove opening tags
            sanitized = re.sub(f'<{tag}[^>]*>', '', sanitized, flags=re.IGNORECASE)
            # Remove closing tags
            sanitized = re.sub(f'</{tag}>', '', sanitized, flags=re.IGNORECASE)
        
        # Remove javascript: and data: URLs
        sanitized = re.sub(r'javascript:', '', sanitized, flags=re.IGNORECASE)
        sanitized = re.sub(r'data:', '', sanitized, flags=re.IGNORECASE)
        
        return sanitized
    
    def filter_content(self, content: str, user_id: Optional[int] = None, 
                      strict_mode: bool = False) -> FilterResult:
        """Main content filtering function with comprehensive safety checks"""
        start_time = datetime.utcnow()
        violations = []
        severity = 'low'
        is_safe = True
        
        # Input validation
        if not content or not isinstance(content, str):
            return FilterResult(
                is_safe=False,
                filtered_content="",
                violations=[{'type': 'invalid_input', 'message': 'Invalid content provided'}],
                severity='high',
                confidence=1.0,
                processing_time_ms=0
            )
        
        filtered_content = content
        
        # 1. PII Detection and Masking
        pii_result = self.detect_pii(content)
        if pii_result.has_pii:
            violations.append({
                'type': 'pii_detected',
                'details': pii_result.detected_types,
                'count': pii_result.pii_count,
                'locations': pii_result.locations
            })
            filtered_content = pii_result.masked_content
            
            # Determine severity based on PII types
            high_severity_pii = ['ssn', 'credit_card', 'financial']
            if any(pii_type in high_severity_pii for pii_type in pii_result.detected_types):
                severity = 'high'
                is_safe = False
            else:
                severity = max(severity, 'medium')
        
        # 2. Profanity Detection
        profanity_result = self.detect_profanity(filtered_content)
        if profanity_result['has_profanity']:
            violations.append({
                'type': 'profanity_detected',
                'confidence': profanity_result['confidence'],
                'methods': profanity_result['methods_used'],
                'words': profanity_result['detected_words']
            })
            
            if strict_mode or profanity_result['confidence'] > 0.8:
                is_safe = False
                severity = max(severity, 'medium')
            
            # Filter out profanity
            if PROFANITY_AVAILABLE:
                filtered_content = profanity.censor(filtered_content)
        
        # 3. Harmful Content Detection
        harmful_result = self.detect_harmful_content(filtered_content)
        if harmful_result['has_harmful_content']:
            violations.append({
                'type': 'harmful_content',
                'categories': harmful_result['categories'],
                'severity_score': harmful_result['severity_score'],
                'keywords': harmful_result['matched_keywords']
            })
            
            if harmful_result['severity_score'] > 0.7:
                is_safe = False
                severity = 'high'
            elif harmful_result['severity_score'] > 0.5:
                severity = max(severity, 'medium')
        
        # 4. HTML Sanitization
        sanitized_content = self.sanitize_html(filtered_content)
        if sanitized_content != filtered_content:
            violations.append({
                'type': 'html_sanitized',
                'message': 'HTML content was sanitized for security'
            })
        filtered_content = sanitized_content
        
        # 5. Length and Format Validation
        if len(content) > 10000:  # Configurable limit
            violations.append({
                'type': 'content_too_long',
                'length': len(content),
                'limit': 10000
            })
            severity = max(severity, 'medium')
            filtered_content = filtered_content[:10000] + "... [content truncated]"
        
        # Calculate confidence score
        total_violations = len(violations)
        confidence = min(0.3 + (total_violations * 0.2), 1.0) if violations else 0.1
        
        # Log violations if user provided
        if violations and user_id:
            self._log_safety_violation(user_id, violations, severity, content[:500])
        
        processing_time = int((datetime.utcnow() - start_time).total_seconds() * 1000)
        
        return FilterResult(
            is_safe=is_safe,
            filtered_content=filtered_content,
            violations=violations,
            severity=severity,
            confidence=confidence,
            processing_time_ms=processing_time
        )
    
    def _log_safety_violation(self, user_id: int, violations: List[Dict], 
                             severity: str, content_sample: str):
        """Log safety violations to database"""
        try:
            from models import db, SafetyViolation
            
            violation_types = [v['type'] for v in violations]
            
            safety_violation = SafetyViolation(
                user_id=user_id,
                violation_type='|'.join(violation_types),
                content_hash=hashlib.sha256(content_sample.encode()).hexdigest(),
                severity=severity,
                details={'violations': violations, 'content_sample': content_sample},
                ip_address=request.remote_addr if request else None
            )
            
            db.session.add(safety_violation)
            db.session.commit()
            
            logger.warning(f"Safety violation logged for user {user_id}: {violation_types}")
            
        except Exception as e:
            logger.error(f"Failed to log safety violation: {e}")
    
# Decorator for content filtering
def content_filter_required(strict_mode: bool = False):
    """Decorator to enforce content filtering on route inputs"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            from flask import request, jsonify, current_user
            
            content_filter = ContentFilter()
            
            # Check form data and JSON data for content to filter
            content_to_check = []
            
            if request.is_json and request.json:
                for key, value in request.json.items():
                    if isinstance(value, str) and len(value.strip()) > 0:
                        content_to_check.append((key, value))
            
            if request.form:
                for key, value in request.form.items():
                    if isinstance(value, str) and len(value.strip()) > 0:
                        content_to_check.append((key, value))
            
            # Filter all content
            violations_found = False
            for field_name, content in content_to_check:
                user_id = getattr(current_user, 'id', None) if current_user.is_authenticated else None
                result = content_filter.filter_content(content, user_id, strict_mode)
                
                if not result.is_safe:
                    violations_found = True
                    logger.warning(f"Content filter violation in field '{field_name}': {result.violations}")
            
            if violations_found and strict_mode:
                if request.is_json:
                    return jsonify({
                        'error': 'Content policy violation',
                        'message': 'Your content contains inappropriate material and cannot be processed.'
                    }), 400
                else:
                    from flask import flash, redirect, url_for
                    flash('Your content violates our community guidelines. Please revise and try again.', 'error')
                    return redirect(url_for('index'))
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# Safety monitoring utilities
def get_user_safety_score(user_id: int) -> Dict[str, Any]:
    """Calculate user's safety score based on violation history"""
    try:
        from models import SafetyViolation, db
        from sqlalchemy import func
        
        # Get violation counts by severity from last 30 days
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        
        violations = db.session.query(
            SafetyViolation.severity,
            func.count(SafetyViolation.id).label('count')
        ).filter(
            SafetyViolation.user_id == user_id,
            SafetyViolation.created_at >= thirty_days_ago
        ).group_by(SafetyViolation.severity).all()
        
        # Calculate weighted score
        severity_weights = {'low': 1, 'medium': 3, 'high': 7, 'critical': 15}
        total_score = 0
        violation_counts = {'low': 0, 'medium': 0, 'high': 0, 'critical': 0}
        
        for severity, count in violations:
            weight = severity_weights.get(severity, 1)
            total_score += count * weight
            violation_counts[severity] = count
        
        # Determine safety level (lower scores are better)
        if total_score == 0:
            safety_level = 'excellent'
        elif total_score <= 5:
            safety_level = 'good'
        elif total_score <= 15:
            safety_level = 'warning'
        else:
            safety_level = 'restricted'
        
        return {
            'safety_score': total_score,
            'safety_level': safety_level,
            'violation_counts': violation_counts,
            'total_violations': sum(violation_counts.values()),
            'assessment_date': datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error calculating safety score for user {user_id}: {e}")
        return {
            'safety_score': 0,
            'safety_level': 'unknown',
            'violation_counts': {'low': 0, 'medium': 0, 'high': 0, 'critical': 0},
            'total_violations': 0,
            'error': str(e)
        }


# Legacy compatibility classes for backward compatibility
class ContentGuardrails:
    """Legacy wrapper for ContentFilter - maintains backward compatibility"""
    
    def __init__(self, db, cache):
        self.content_filter = ContentFilter()
        self.db = db
        self.cache = cache
    
    def check_content(self, content: str, session_id: str) -> Dict:
        """Legacy method - converts new FilterResult to old format"""
        result = self.content_filter.filter_content(content, None, False)
        
        return {
            'safe': result.is_safe,
            'reasons': [v['type'] for v in result.violations],
            'severity': result.severity,
            'action': 'block' if not result.is_safe and result.severity == 'high' else 'allow',
            'details': {'violations': result.violations}
        }
    

class ResponseSanitizer:
    """Sanitize AI responses before sending to users"""
    
    def __init__(self):
        self.unsafe_patterns = [
            # Only block inline scripts, not CDN/external scripts
            (r'<script[^>]*>(?!\s*$).*?</script>', '[removed]'),  # Inline scripts with content
            (r'javascript:', '[removed]'),
            (r'on\w+\s*=', '[removed]='),
            (r'<iframe[^>]*>.*?</iframe>', '[removed]'),
            (r'\b(?:eval|exec)\s*\(', '[removed](')
        ]
    
    def sanitize_response(self, response: str) -> str:
        """Clean response of any potentially harmful content"""
        sanitized = response
        
        # Remove potentially harmful patterns
        for pattern, replacement in self.unsafe_patterns:
            sanitized = re.sub(pattern, replacement, sanitized, flags=re.IGNORECASE | re.DOTALL)
        
        # Ensure response doesn't contain PII
        sanitized = self._remove_pii(sanitized)
        
        # Add AI disclaimer if discussing real people
        if self._mentions_real_person(sanitized):
            sanitized += "\n\n*Note: This is an AI-generated response about fictional content.*"
        
        return sanitized
    
    def _remove_pii(self, text: str) -> str:
        """Remove any PII from response"""
        # Use the same PII patterns from ContentFilter
        for pii_type, config in PII_PATTERNS.items():
            text = re.sub(config['pattern'], config['replacement'], text, flags=re.IGNORECASE)
        return text
    
    def _mentions_real_person(self, text: str) -> bool:
        """Check if text mentions real people"""
        # Simple check for common patterns
        real_person_patterns = [
            r'\b(?:President|CEO|Director|Actor|Actress)\s+[A-Z][a-z]+\s+[A-Z][a-z]+',
            r'\b(?:Mr\.|Mrs\.|Ms\.|Dr\.)\s+[A-Z][a-z]+\s+[A-Z][a-z]+'
        ]
        
        for pattern in real_person_patterns:
            if re.search(pattern, text):
                return True
        
        return False


class SafetyManager:
    """Manage overall safety policies and compliance"""
    
    @staticmethod
    def get_violation_summary(user_id: int, days: int = 30) -> Dict[str, Any]:
        """Get comprehensive violation summary for a user"""
        try:
            from models import SafetyViolation, db
            from sqlalchemy import func
            
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            violations = db.session.query(SafetyViolation).filter(
                SafetyViolation.user_id == user_id,
                SafetyViolation.created_at >= cutoff_date
            ).all()
            
            summary = {
                'total_violations': len(violations),
                'by_severity': {'low': 0, 'medium': 0, 'high': 0, 'critical': 0},
                'by_type': {},
                'recent_activity': [],
                'risk_level': 'low',
                'recommended_action': 'none'
            }
            
            for violation in violations:
                # Count by severity
                summary['by_severity'][violation.severity] = summary['by_severity'].get(violation.severity, 0) + 1
                
                # Count by type
                v_type = violation.violation_type
                summary['by_type'][v_type] = summary['by_type'].get(v_type, 0) + 1
                
                # Add to recent activity
                summary['recent_activity'].append({
                    'date': violation.created_at.isoformat(),
                    'type': violation.violation_type,
                    'severity': violation.severity
                })
            
            # Calculate risk level
            critical_count = summary['by_severity']['critical']
            high_count = summary['by_severity']['high']
            
            if critical_count > 0 or high_count > 3:
                summary['risk_level'] = 'critical'
                summary['recommended_action'] = 'suspend'
            elif high_count > 1 or summary['total_violations'] > 10:
                summary['risk_level'] = 'high' 
                summary['recommended_action'] = 'warn'
            elif summary['total_violations'] > 5:
                summary['risk_level'] = 'medium'
                summary['recommended_action'] = 'monitor'
            
            return summary
            
        except Exception as e:
            logger.error(f"Error getting violation summary for user {user_id}: {e}")
            return {'error': str(e), 'total_violations': 0}