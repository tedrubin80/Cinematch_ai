# app_minimal.py - Minimal Cinematch Flask Application for testing
import os
import logging
from datetime import datetime
from flask import Flask, render_template, jsonify, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix

# Initialize extensions
db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()
limiter = Limiter(key_func=get_remote_address, storage_uri="memory://")

def create_app():
    """Minimal application factory"""
    app = Flask(__name__)
    
    # Load configuration from environment
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['ADMIN_SECRET_PATH'] = os.environ.get('ADMIN_SECRET_PATH', 'admin')
    
    # Security: Handle proxy headers correctly
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)
    
    # Initialize extensions with app
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    limiter.init_app(app)
    
    # Configure CORS
    CORS(app)
    
    # Configure login manager
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    
    # Set up basic logging
    logging.basicConfig(level=logging.INFO)
    app.logger.info('Cinematch minimal startup')
    
    # Health check endpoint
    @app.route('/health')
    @limiter.exempt
    def health_check():
        """Health check endpoint for monitoring"""
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'version': '1.0.0'
        })
    
    # Basic route
    @app.route('/')
    def index():
        return jsonify({
            'message': 'Cinematch is running!',
            'admin_path': f"/{app.config['ADMIN_SECRET_PATH']}/api",
            'timestamp': datetime.utcnow().isoformat()
        })
    
    # Import and register minimal admin API management
    try:
        from admin_api_management import api_mgmt_bp
        admin_path = app.config.get('ADMIN_SECRET_PATH', 'admin')
        app.register_blueprint(api_mgmt_bp, url_prefix=f'/{admin_path}')
        app.logger.info('Admin API management registered')
    except Exception as e:
        app.logger.error(f'Failed to register admin API management: {e}')
    
    return app

# Create application instance
app = create_app()

if __name__ == '__main__':
    app.run(debug=False, host='127.0.0.1', port=5000)