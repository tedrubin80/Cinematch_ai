#!/bin/bash

# Cinematch Installation Script
# For Ubuntu 20.04/22.04 VPS with 4GB RAM and 4 CPUs

set -e  # Exit on error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root (use sudo)"
   exit 1
fi

print_status "Starting Cinematch installation..."

# Get user inputs
read -p "Enter your domain name (e.g., example.com): " DOMAIN_NAME
read -p "Enter admin username: " ADMIN_USERNAME
read -p "Enter admin email: " ADMIN_EMAIL
read -sp "Enter admin password: " ADMIN_PASSWORD
echo
read -p "Enter DigitalOcean Spaces Access Key: " DO_SPACES_KEY
read -sp "Enter DigitalOcean Spaces Secret Key: " DO_SPACES_SECRET
echo
read -p "Enter OpenAI API Key (for embeddings): " OPENAI_API_KEY
read -p "Enter Anthropic API Key (optional, press enter to skip): " ANTHROPIC_API_KEY
read -p "Enter Google API Key (optional, press enter to skip): " GOOGLE_API_KEY

# Generate secure keys
SECRET_KEY=$(openssl rand -hex 32)
ENCRYPTION_KEY=$(python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")
ADMIN_SECRET_PATH="admin-$(openssl rand -hex 8)"

print_status "Generated secure keys and admin path: /$ADMIN_SECRET_PATH/"

# Update system
print_status "Updating system packages..."
apt update && apt upgrade -y

# Install system dependencies
print_status "Installing system dependencies..."
apt install -y \
    python3.11 \
    python3.11-venv \
    python3.11-dev \
    python3-pip \
    postgresql-client \
    libpq-dev \
    redis-server \
    nginx \
    supervisor \
    git \
    curl \
    wget \
    build-essential \
    libssl-dev \
    libffi-dev \
    libnss3 \
    libnspr4 \
    libatk1.0-0 \
    libatk-bridge2.0-0 \
    libcups2 \
    libdrm2 \
    libdbus-1-3 \
    libatspi2.0-0 \
    libx11-6 \
    libxcomposite1 \
    libxdamage1 \
    libxext6 \
    libxfixes3 \
    libxrandr2 \
    libgbm1 \
    libxcb1 \
    libxkbcommon0 \
    libgtk-3-0 \
    libpango-1.0-0 \
    libcairo2 \
    libasound2 \
    certbot \
    python3-certbot-nginx

# Create application directory
print_status "Creating application directory..."
mkdir -p /var/www/cinematch
cd /var/www/cinematch

# Create Python virtual environment
print_status "Creating Python virtual environment..."
python3.11 -m venv venv
source venv/bin/activate

# Create requirements.txt
print_status "Creating requirements.txt..."
cat > requirements.txt << 'EOF'
Flask==2.3.2
flask-sqlalchemy==3.0.5
flask-login==0.6.2
flask-migrate==4.0.4
flask-limiter==3.3.1
flask-cors==4.0.0
gunicorn==21.2.0
celery==5.3.1
redis==4.6.0
psycopg2-binary==2.9.7
pgvector==0.2.2
boto3==1.28.17
playwright==1.36.0
beautifulsoup4==4.12.2
requests==2.31.0
langchain==0.0.250
langchain-anthropic
langchain-google-genai
openai==0.27.8
cryptography==41.0.3
numpy==1.24.3
python-dotenv==1.0.0
EOF

# Install Python packages
print_status "Installing Python packages (this may take a while)..."
pip install --upgrade pip
pip install -r requirements.txt

# Install Playwright browsers
print_status "Installing Playwright browsers..."
playwright install chromium
playwright install-deps chromium

# Create .env file
print_status "Creating environment configuration..."
cat > .env << EOF
SECRET_KEY=$SECRET_KEY
ENCRYPTION_KEY=$ENCRYPTION_KEY
ADMIN_SECRET_PATH=$ADMIN_SECRET_PATH
DO_SPACES_KEY=$DO_SPACES_KEY
DO_SPACES_SECRET=$DO_SPACES_SECRET
OPENAI_API_KEY=$OPENAI_API_KEY
ANTHROPIC_API_KEY=$ANTHROPIC_API_KEY
GOOGLE_API_KEY=$GOOGLE_API_KEY
REDIS_URL=redis://localhost:6379/0
EOF

# Create directory structure first
print_status "Creating directory structure..."
mkdir -p templates/admin
mkdir -p static/css
mkdir -p static/js
mkdir -p logs

# Note: Git clone will be done at the end of the script for browser authentication

# Create a simple wsgi.py file
cat > wsgi.py << 'EOF'
from app import app

if __name__ == "__main__":
    app.run()
EOF

# Configure Redis
print_status "Configuring Redis..."
systemctl enable redis-server
systemctl start redis-server

# Create systemd service for the Flask app
print_status "Creating systemd service..."
cat > /etc/systemd/system/cinematch.service << EOF
[Unit]
Description=Cinematch Flask Application
After=network.target postgresql.service redis.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/cinematch
Environment="PATH=/var/www/cinematch/venv/bin"
ExecStart=/var/www/cinematch/venv/bin/gunicorn --workers 4 --bind unix:cinematch.sock -m 007 wsgi:app

[Install]
WantedBy=multi-user.target
EOF

# Create systemd service for Celery worker
cat > /etc/systemd/system/cinematch-celery.service << EOF
[Unit]
Description=Cinematch Celery Worker
After=network.target postgresql.service redis.service

[Service]
Type=forking
User=www-data
Group=www-data
WorkingDirectory=/var/www/cinematch
Environment="PATH=/var/www/cinematch/venv/bin"
ExecStart=/var/www/cinematch/venv/bin/celery -A app.celery worker --loglevel=info --detach

[Install]
WantedBy=multi-user.target
EOF

# Create systemd service for Celery beat
cat > /etc/systemd/system/cinematch-celery-beat.service << EOF
[Unit]
Description=Cinematch Celery Beat
After=network.target postgresql.service redis.service

[Service]
Type=forking
User=www-data
Group=www-data
WorkingDirectory=/var/www/cinematch
Environment="PATH=/var/www/cinematch/venv/bin"
ExecStart=/var/www/cinematch/venv/bin/celery -A app.celery beat --loglevel=info --detach

[Install]
WantedBy=multi-user.target
EOF

# Configure Nginx
print_status "Configuring Nginx..."
cat > /etc/nginx/sites-available/cinematch << EOF
server {
    listen 80;
    server_name $DOMAIN_NAME www.$DOMAIN_NAME;

    location / {
        include proxy_params;
        proxy_pass http://unix:/var/www/cinematch/cinematch.sock;
    }

    location /static {
        alias /var/www/cinematch/static;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Hide from search engines
    location = /robots.txt {
        add_header Content-Type text/plain;
        return 200 "User-agent: *\nDisallow: /\n";
    }

    # Security headers
    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options DENY;
    add_header X-XSS-Protection "1; mode=block";
    add_header X-Robots-Tag "noindex, nofollow";
}
EOF

# Enable the site
ln -sf /etc/nginx/sites-available/cinematch /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Create log directory
mkdir -p /var/log/cinematch

# Set permissions
print_status "Setting permissions..."
chown -R www-data:www-data /var/www/cinematch
chmod -R 755 /var/www/cinematch
chmod 600 /var/www/cinematch/.env

# Create database initialization script
print_status "Creating database initialization script..."
cat > /var/www/cinematch/init_db.py << 'EOF'
#!/usr/bin/env python3
import os
import sys
from app import app, db, init_pgvector, User, APIKey

def init_database():
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # Initialize pgvector extension
        init_pgvector()
        
        # Create admin user
        admin_username = os.environ.get('ADMIN_USERNAME', 'admin')
        admin_email = os.environ.get('ADMIN_EMAIL', 'admin@example.com')
        admin_password = os.environ.get('ADMIN_PASSWORD', 'changeme')
        
        admin = User.query.filter_by(username=admin_username).first()
        if not admin:
            admin = User(
                username=admin_username,
                email=admin_email,
                is_admin=True
            )
            admin.set_password(admin_password)
            db.session.add(admin)
            db.session.commit()
            print(f"Admin user created: {admin_username}")
        
        # Add API keys if provided
        if os.environ.get('OPENAI_API_KEY'):
            api_key = APIKey.query.filter_by(service='openai').first()
            if not api_key:
                api_key = APIKey(service='openai')
            api_key.set_key(os.environ.get('OPENAI_API_KEY'))
            db.session.add(api_key)
        
        if os.environ.get('ANTHROPIC_API_KEY'):
            api_key = APIKey.query.filter_by(service='anthropic').first()
            if not api_key:
                api_key = APIKey(service='anthropic')
            api_key.set_key(os.environ.get('ANTHROPIC_API_KEY'))
            db.session.add(api_key)
        
        if os.environ.get('GOOGLE_API_KEY'):
            api_key = APIKey.query.filter_by(service='google').first()
            if not api_key:
                api_key = APIKey(service='google')
            api_key.set_key(os.environ.get('GOOGLE_API_KEY'))
            db.session.add(api_key)
        
        db.session.commit()
        print("Database initialized successfully!")

if __name__ == '__main__':
    init_database()
EOF

# Initialize database
print_status "Initializing database..."
cd /var/www/cinematch
source venv/bin/activate
export FLASK_APP=app.py
export ADMIN_USERNAME="$ADMIN_USERNAME"
export ADMIN_EMAIL="$ADMIN_EMAIL"
export ADMIN_PASSWORD="$ADMIN_PASSWORD"

# Note: Database should already exist on DigitalOcean
# Just initialize the tables and pgvector
python init_db.py

# Reload systemd and start services
print_status "Starting services..."
systemctl daemon-reload
systemctl enable cinematch cinematch-celery cinematch-celery-beat
systemctl start cinematch cinematch-celery cinematch-celery-beat

# Test and reload Nginx
nginx -t
systemctl reload nginx

# Setup SSL with Let's Encrypt
print_status "Setting up SSL certificate..."
certbot --nginx -d $DOMAIN_NAME -d www.$DOMAIN_NAME --non-interactive --agree-tos --email $ADMIN_EMAIL

# Create a helper script for managing the application
cat > /usr/local/bin/cinematch-manage << 'EOF'
#!/bin/bash
cd /var/www/cinematch
source venv/bin/activate
export FLASK_APP=app.py

case "$1" in
    restart)
        systemctl restart cinematch cinematch-celery cinematch-celery-beat
        ;;
    stop)
        systemctl stop cinematch cinematch-celery cinematch-celery-beat
        ;;
    start)
        systemctl start cinematch cinematch-celery cinematch-celery-beat
        ;;
    status)
        systemctl status cinematch cinematch-celery cinematch-celery-beat
        ;;
    logs)
        journalctl -u cinematch -f
        ;;
    shell)
        flask shell
        ;;
    *)
        echo "Usage: cinematch-manage {restart|stop|start|status|logs|shell}"
        exit 1
        ;;
esac
EOF

chmod +x /usr/local/bin/cinematch-manage

# Create backup script
cat > /usr/local/bin/cinematch-backup << 'EOF'
#!/bin/bash
BACKUP_DIR="/var/backups/cinematch"
mkdir -p $BACKUP_DIR
DATE=$(date +%Y%m%d_%H%M%S)

# Backup database
PGPASSWORD=$DB_PASSWORD pg_dump -h $DB_HOST -U $DB_USER -d $DB_NAME > $BACKUP_DIR/db_backup_$DATE.sql

# Backup .env file
cp /var/www/cinematch/.env $BACKUP_DIR/env_backup_$DATE

# Keep only last 7 days of backups
find $BACKUP_DIR -type f -mtime +7 -delete

echo "Backup completed: $BACKUP_DIR"
EOF

chmod +x /usr/local/bin/cinematch-backup

# Add cron job for backups
echo "0 2 * * * /usr/local/bin/cinematch-backup" | crontab -

# Final summary
print_status "Installation completed successfully!"
echo
echo "====================================="
echo "INSTALLATION SUMMARY"
echo "====================================="
echo "Domain: https://$DOMAIN_NAME"
echo "Admin URL: https://$DOMAIN_NAME/$ADMIN_SECRET_PATH/"
echo "Admin Username: $ADMIN_USERNAME"
echo "Admin Email: $ADMIN_EMAIL"
echo
echo "Commands available:"
echo "  cinematch-manage restart   - Restart all services"
echo "  cinematch-manage status    - Check service status"
echo "  cinematch-manage logs      - View application logs"
echo "  cinematch-manage shell     - Open Flask shell"
echo
echo "IMPORTANT: Save these credentials securely!"
echo "Admin Path: /$ADMIN_SECRET_PATH/"
echo "====================================="

# Save installation info
cat > /root/cinematch-install-info.txt << EOF
Cinematch Installation Info
==========================
Date: $(date)
Domain: https://$DOMAIN_NAME
Admin URL: https://$DOMAIN_NAME/$ADMIN_SECRET_PATH/
Admin Username: $ADMIN_USERNAME
Admin Email: $ADMIN_EMAIL
Secret Key: $SECRET_KEY
Encryption Key: $ENCRYPTION_KEY

This file contains sensitive information. Keep it secure!
EOF

chmod 600 /root/cinematch-install-info.txt

print_status "Installation info saved to /root/cinematch-install-info.txt"

# Git clone at the end for browser authentication
echo
echo "====================================="
echo "FINAL STEP: CLONE REPOSITORY"
echo "====================================="
echo
print_warning "Now we need to clone your GitHub repository."
print_warning "This will open a browser window for authentication."
echo
echo "The repository will be cloned to a temporary directory first,"
echo "then the files will be moved to the correct location."
echo
read -p "Press ENTER to continue with git clone..."

# Create temporary directory for cloning
TEMP_DIR="/tmp/cinematch-clone-$(date +%s)"
mkdir -p $TEMP_DIR

print_status "Cloning repository from GitHub..."
echo "You may be prompted to authenticate in your browser."
echo

# Change to temp directory and clone
cd $TEMP_DIR
git clone https://github.com/tedrubin80/Cinematch.git

# Check if clone was successful
if [ -d "Cinematch" ]; then
    print_status "Repository cloned successfully!"
    
    # Copy files to the application directory
    print_status "Copying application files..."
    cp -r Cinematch/* /var/www/cinematch/
    cp -r Cinematch/.[^.]* /var/www/cinematch/ 2>/dev/null || true
    
    # Set proper ownership
    chown -R www-data:www-data /var/www/cinematch
    
    # Clean up temp directory
    rm -rf $TEMP_DIR
    
    # Restart services with the new code
    print_status "Restarting services with new code..."
    systemctl restart cinematch cinematch-celery cinematch-celery-beat
    
    echo
    print_status "Application deployed successfully!"
    echo
    echo "====================================="
    echo "DEPLOYMENT COMPLETE!"
    echo "====================================="
    echo "Your Cinematch application is now running at:"
    echo "Main site: https://$DOMAIN_NAME"
    echo "Admin panel: https://$DOMAIN_NAME/$ADMIN_SECRET_PATH/"
    echo
    echo "To update the application in the future:"
    echo "cd /var/www/cinematch && git pull && cinematch-manage restart"
    echo "====================================="
else
    print_error "Git clone failed!"
    echo
    echo "Please manually clone the repository:"
    echo "1. cd /var/www/cinematch"
    echo "2. git clone https://github.com/tedrubin80/Cinematch.git ."
    echo "3. chown -R www-data:www-data /var/www/cinematch"
    echo "4. cinematch-manage restart"
fi
