# admin_routes.py - Admin routes for Cinematch

from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash
from flask_login import login_required, current_user
from datetime import datetime, timedelta
from sqlalchemy import func
import psutil
import json

# Import decorators and models from auth.py
from auth import admin_required

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/')
@login_required
@admin_required
def dashboard():
    """Admin dashboard with statistics"""
    from models import db, User, Session, ChatLog, APIKey, MovieDocument
    
    # Calculate statistics
    stats = {
        'total_users': User.query.count(),
        'new_users_today': User.query.filter(
            User.created_at >= datetime.utcnow().date()
        ).count(),
        'active_sessions': Session.query.filter(
            Session.last_activity >= datetime.utcnow() - timedelta(minutes=30)
        ).count(),
        'total_messages': ChatLog.query.count(),
        'messages_today': ChatLog.query.filter(
            ChatLog.created_at >= datetime.utcnow().date()
        ).count(),
        'api_health': 100,  # Calculate based on API response times
        'vector_count': MovieDocument.query.count()
    }
    
    # Recent activities
    recent_activities = []
    
    # Get recent user registrations
    recent_users = User.query.order_by(User.created_at.desc()).limit(3).all()
    for user in recent_users:
        recent_activities.append({
            'icon': 'user-plus',
            'color': 'green',
            'description': f'New user registered: {user.username}',
            'time_ago': get_time_ago(user.created_at)
        })
    
    # Get recent chat logs
    recent_chats = ChatLog.query.order_by(ChatLog.created_at.desc()).limit(3).all()
    for chat in recent_chats:
        recent_activities.append({
            'icon': 'comment',
            'color': 'blue',
            'description': f'Chat message processed ({chat.llm_used})',
            'time_ago': get_time_ago(chat.created_at)
        })
    
    # Sort activities by time
    recent_activities.sort(key=lambda x: x['time_ago'])
    
    # API status
    api_status = {
        'openai': APIKey.query.filter_by(service='openai', is_active=True).first() is not None,
        'anthropic': APIKey.query.filter_by(service='anthropic', is_active=True).first() is not None,
        'google': APIKey.query.filter_by(service='google', is_active=True).first() is not None
    }
    
    # Server info
    server_info = {
        'cpu_percent': psutil.cpu_percent(interval=1),
        'memory_percent': psutil.virtual_memory().percent,
        'disk_percent': psutil.disk_usage('/').percent
    }
    
    return render_template('admin/dashboard.html',
                         stats=stats,
                         recent_activities=recent_activities[:5],
                         api_status=api_status,
                         server_info=server_info)

@admin_bp.route('/users')
@login_required
@admin_required
def users():
    """User management page"""
    from models import db, User
    
    page = request.args.get('page', 1, type=int)
    users = User.query.order_by(User.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    # Calculate additional stats
    active_users = User.query.filter_by(is_active=True).count()
    admin_users = User.query.filter_by(is_admin=True).count()
    new_today = User.query.filter(User.created_at >= datetime.utcnow().date()).count()
    
    return render_template('admin/users.html', 
                         users=users,
                         active_users=active_users,
                         admin_users=admin_users,
                         new_today=new_today)

@admin_bp.route('/users/<uuid:user_id>/toggle-admin', methods=['POST'])
@login_required
@admin_required
def toggle_admin(user_id):
    """Toggle admin status for a user"""
    from models import db, User, AdminAuditLog
    
    user = User.query.get_or_404(user_id)
    
    # Prevent removing your own admin status
    if user.id == current_user.id:
        return jsonify({'error': 'Cannot modify your own admin status'}), 400
    
    user.is_admin = not user.is_admin
    
    # Log the action
    audit = AdminAuditLog(
        user_id=current_user.id,
        action=f"{'Granted' if user.is_admin else 'Revoked'} admin status for {user.username}",
        details={'target_user_id': str(user_id)},
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    
    db.session.add(audit)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'is_admin': user.is_admin,
        'message': f"Admin status {'granted' if user.is_admin else 'revoked'}"
    })

@admin_bp.route('/users/<uuid:user_id>/disable', methods=['POST'])
@login_required
@admin_required
def disable_user(user_id):
    """Disable/enable a user account"""
    from models import db, User, AdminAuditLog
    
    user = User.query.get_or_404(user_id)
    
    # Prevent disabling your own account
    if user.id == current_user.id:
        return jsonify({'error': 'Cannot disable your own account'}), 400
    
    user.is_active = not user.is_active
    
    # Log the action
    audit = AdminAuditLog(
        user_id=current_user.id,
        action=f"{'Enabled' if user.is_active else 'Disabled'} user {user.username}",
        details={'target_user_id': str(user_id)},
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    
    db.session.add(audit)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'is_active': user.is_active,
        'message': f"User {'enabled' if user.is_active else 'disabled'}"
    })

@admin_bp.route('/api-keys')
@login_required
@admin_required
def api_keys():
    """API key management page"""
    from models import APIKey
    
    keys = {
        'openai': APIKey.query.filter_by(service='openai').first(),
        'anthropic': APIKey.query.filter_by(service='anthropic').first(),
        'google': APIKey.query.filter_by(service='google').first()
    }
    
    return render_template('admin/api_keys.html', api_keys=keys)

@admin_bp.route('/api-keys/update', methods=['POST'])
@login_required
@admin_required
def update_api_key():
    """Update an API key"""
    from models import db, APIKey, AdminAuditLog
    
    data = request.get_json()
    service = data.get('service')
    key_value = data.get('key')
    
    if not service or not key_value:
        return jsonify({'error': 'Missing service or key'}), 400
    
    # Validate service
    if service not in ['openai', 'anthropic', 'google']:
        return jsonify({'error': 'Invalid service'}), 400
    
    # Update or create key
    api_key = APIKey.query.filter_by(service=service).first()
    if not api_key:
        api_key = APIKey(service=service)
        db.session.add(api_key)
    
    from models import cipher_suite
    api_key.encrypted_key = cipher_suite.encrypt(key_value.encode()).decode()
    api_key.is_active = True
    api_key.updated_at = datetime.utcnow()
    api_key.updated_by = current_user.id
    
    # Log the action
    audit = AdminAuditLog(
        user_id=current_user.id,
        action=f"Updated {service} API key",
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    db.session.add(audit)
    
    db.session.commit()
    
    return jsonify({'success': True, 'message': f'{service} API key updated'})

@admin_bp.route('/security')
@login_required
@admin_required
def security():
    """Security dashboard"""
    from models import db, SecurityLog, SafetyLog
    
    # Get security statistics
    last_24h = datetime.utcnow() - timedelta(hours=24)
    
    security_stats = {
        'failed_logins': SecurityLog.query.filter(
            SecurityLog.event_type == 'failed_login',
            SecurityLog.timestamp >= last_24h
        ).count(),
        'blocked_requests': SafetyLog.query.filter(
            SafetyLog.action == 'block',
            SafetyLog.timestamp >= last_24h
        ).count(),
        'rate_limits': SecurityLog.query.filter(
            SecurityLog.event_type == 'rate_limit',
            SecurityLog.timestamp >= last_24h
        ).count()
    }
    
    # Determine threat level
    total_incidents = sum(security_stats.values())
    if total_incidents > 100:
        threat_level = "High"
    elif total_incidents > 50:
        threat_level = "Medium"
    else:
        threat_level = "Low"
    
    # Recent security events
    recent_events = SecurityLog.query.order_by(
        SecurityLog.timestamp.desc()
    ).limit(20).all()
    
    # Top blocked IPs
    blocked_ips = db.session.query(
        SecurityLog.ip_address,
        func.count(SecurityLog.id).label('count')
    ).filter(
        SecurityLog.event_type.in_(['blocked_ip', 'rate_limit']),
        SecurityLog.timestamp >= last_24h
    ).group_by(SecurityLog.ip_address).order_by(
        func.count(SecurityLog.id).desc()
    ).limit(10).all()
    
    return render_template('admin/security.html',
                         security_stats=security_stats,
                         recent_events=recent_events,
                         blocked_ips=blocked_ips,
                         threat_level=threat_level)

@admin_bp.route('/activity-log')
@login_required
@admin_required
def activity_log():
    """View all admin activity logs"""
    from models import AdminAuditLog, User
    
    page = request.args.get('page', 1, type=int)
    
    # Get filter parameters
    user_id = request.args.get('user_id')
    action = request.args.get('action')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    # Build query
    query = AdminAuditLog.query
    
    if user_id:
        query = query.filter_by(user_id=user_id)
    if action:
        query = query.filter(AdminAuditLog.action.contains(action))
    if start_date:
        query = query.filter(AdminAuditLog.timestamp >= datetime.fromisoformat(start_date))
    if end_date:
        query = query.filter(AdminAuditLog.timestamp <= datetime.fromisoformat(end_date))
    
    logs = query.order_by(
        AdminAuditLog.timestamp.desc()
    ).paginate(page=page, per_page=50, error_out=False)
    
    # Get admin users for filter dropdown
    admin_users = User.query.filter_by(is_admin=True).all()
    
    return render_template('admin/activity_log.html', 
                         logs=logs,
                         admin_users=admin_users)

@admin_bp.route('/api/stats')
@login_required
@admin_required
def api_stats():
    """API endpoint for real-time stats"""
    from models import db, Session, ChatLog
    
    stats = {
        'active_sessions': Session.query.filter(
            Session.last_activity >= datetime.utcnow() - timedelta(minutes=5)
        ).count(),
        'messages_last_hour': ChatLog.query.filter(
            ChatLog.created_at >= datetime.utcnow() - timedelta(hours=1)
        ).count(),
        'timestamp': datetime.utcnow().isoformat()
    }
    
    return jsonify(stats)

# Route management endpoints
@admin_bp.route('/routes')
@login_required
@admin_required
def manage_routes():
    """Route management page"""
    from models import CustomRoute
    
    routes = CustomRoute.query.order_by(CustomRoute.created_at.desc()).all()
    
    # Calculate stats
    stats = {
        'total_routes': len(routes),
        'active_routes': sum(1 for r in routes if r.active),
        'api_routes': sum(1 for r in routes if r.path.startswith('/api/')),
        'webhook_routes': sum(1 for r in routes if r.action_type == 'webhook')
    }
    
    return render_template('admin/routes.html', routes=routes, stats=stats)

@admin_bp.route('/routes/create')
@login_required
@admin_required
def create_route():
    """Create route page"""
    return render_template('admin/create_route.html')

@admin_bp.route('/routes/<uuid:route_id>/edit')
@login_required
@admin_required
def edit_route(route_id):
    """Edit route page"""
    from models import CustomRoute
    route = CustomRoute.query.get_or_404(route_id)
    return render_template('admin/edit_route.html', route=route)

@admin_bp.route('/routes/create', methods=['POST'])
@login_required
@admin_required
def create_route_action():
    """Create a new route"""
    from models import db, CustomRoute
    
    data = request.get_json()
    
    # Validate required fields
    if not all(k in data for k in ['name', 'path', 'method', 'action_type']):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Check if route already exists
    if CustomRoute.query.filter_by(path=data['path'], method=data['method']).first():
        return jsonify({'error': 'Route already exists'}), 400
    
    try:
        # Build configuration
        config = {
            'model': data.get('model'),
            'temperature': data.get('temperature', 0.7),
            'top_k': data.get('top_k', 10),
            'max_tokens': data.get('max_tokens', 150),
            'response_format': data.get('response_format', 'json'),
            'system_prompt': data.get('system_prompt', ''),
            'cache_ttl': data.get('cache_ttl', 300)
        }
        
        route = CustomRoute(
            name=data['name'],
            path=data['path'],
            method=data['method'],
            description=data.get('description', ''),
            action_type=data['action_type'],
            configuration=config,
            requires_auth=data.get('requires_auth', True),
            rate_limit=data.get('rate_limit', 60),
            active=True,
            created_by=current_user.id
        )
        
        db.session.add(route)
        db.session.commit()
        
        log_admin_action(f"Created route: {data['name']}")
        
        return jsonify({'success': True, 'id': str(route.id)})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/routes/<uuid:route_id>', methods=['PUT'])
@login_required
@admin_required
def update_route(route_id):
    """Update an existing route"""
    from models import db, CustomRoute
    
    route = CustomRoute.query.get_or_404(route_id)
    data = request.get_json()
    
    try:
        # Update fields
        route.name = data.get('name', route.name)
        route.path = data.get('path', route.path)
        route.method = data.get('method', route.method)
        route.description = data.get('description', route.description)
        route.action_type = data.get('action_type', route.action_type)
        route.requires_auth = data.get('requires_auth', route.requires_auth)
        route.rate_limit = data.get('rate_limit', route.rate_limit)
        route.active = data.get('active', route.active)
        
        # Update configuration
        if 'configuration' in data:
            route.configuration = data['configuration']
        else:
            # Build configuration from individual fields
            config = {
                'model': data.get('model'),
                'temperature': data.get('temperature', 0.7),
                'top_k': data.get('top_k', 10),
                'max_tokens': data.get('max_tokens', 150),
                'response_format': data.get('response_format', 'json'),
                'system_prompt': data.get('system_prompt', ''),
                'cache_ttl': data.get('cache_ttl', 300)
            }
            route.configuration = config
        
        db.session.commit()
        
        log_admin_action(f"Updated route: {route.name}")
        
        return jsonify({'success': True})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/routes/<uuid:route_id>/toggle', methods=['POST'])
@login_required
@admin_required
def toggle_route(route_id):
    """Toggle route active status"""
    from models import db, CustomRoute
    
    route = CustomRoute.query.get_or_404(route_id)
    route.active = not route.active
    db.session.commit()
    
    log_admin_action(f"{'Activated' if route.active else 'Deactivated'} route: {route.name}")
    
    return jsonify({'success': True, 'active': route.active})

@admin_bp.route('/routes/<uuid:route_id>', methods=['DELETE'])
@login_required
@admin_required
def delete_route(route_id):
    """Delete a route"""
    from models import db, CustomRoute
    
    route = CustomRoute.query.get_or_404(route_id)
    name = route.name
    
    db.session.delete(route)
    db.session.commit()
    
    log_admin_action(f"Deleted route: {name}")
    
    return jsonify({'success': True})

@admin_bp.route('/routes/<uuid:route_id>/test', methods=['POST'])
@login_required
@admin_required
def test_route(route_id):
    """Test a route with sample data"""
    from models import CustomRoute
    import time
    
    route = CustomRoute.query.get_or_404(route_id)
    test_data = request.get_json()
    
    start_time = time.time()
    
    try:
        # Simulate route execution based on action type
        if route.action_type == 'llm_query':
            # Simulate LLM response
            result = {
                'response': 'This is a simulated response for testing.',
                'model_used': route.configuration.get('model', 'unknown')
            }
        else:
            result = {'message': f'Route {route.name} executed successfully'}
        
        execution_time = f"{(time.time() - start_time) * 1000:.2f}ms"
        
        return jsonify({
            'success': True,
            'result': result,
            'execution_time': execution_time
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Helper functions
def get_time_ago(timestamp):
    """Get human-readable time ago string"""
    if not timestamp:
        return 'Never'
    
    delta = datetime.utcnow() - timestamp
    
    if delta.days > 0:
        return f'{delta.days} days ago'
    elif delta.seconds > 3600:
        return f'{delta.seconds // 3600} hours ago'
    elif delta.seconds > 60:
        return f'{delta.seconds // 60} minutes ago'
    else:
        return 'Just now'

def log_admin_action(action, details=None):
    """Log an admin action"""
    from models import db, AdminAuditLog
    
    log = AdminAuditLog(
        user_id=current_user.id,
        action=action,
        details=details,
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    
    db.session.add(log)
    db.session.commit()

# AI Instructions Management Routes
@admin_bp.route('/ai-instructions')
@login_required
@admin_required
def ai_instructions():
    """AI Instructions management page"""
    from models import db
    from ai_instructions import AIInstruction
    
    instructions = AIInstruction.query.order_by(
        AIInstruction.priority.desc(),
        AIInstruction.created_at.desc()
    ).all()
    
    # Calculate stats
    stats = {
        'system': AIInstruction.query.filter_by(instruction_type='system', active=True).count(),
        'behavior': AIInstruction.query.filter_by(instruction_type='behavior', active=True).count(),
        'context': AIInstruction.query.filter_by(instruction_type='context', active=True).count(),
        'style': AIInstruction.query.filter_by(instruction_type='style', active=True).count(),
        'safety': AIInstruction.query.filter_by(instruction_type='safety', active=True).count(),
    }
    
    return render_template('admin/ai_instructions.html', 
                         instructions=instructions,
                         stats=stats)

@admin_bp.route('/ai-instructions/<int:instruction_id>')
@login_required
@admin_required
def get_ai_instruction(instruction_id):
    """Get single AI instruction"""
    from ai_instructions import AIInstruction
    
    instruction = AIInstruction.query.get_or_404(instruction_id)
    
    return jsonify({
        'id': instruction.id,
        'name': instruction.name,
        'instruction_type': instruction.instruction_type,
        'content': instruction.content,
        'priority': instruction.priority,
        'active': instruction.active,
        'conditions': instruction.conditions,
        'metadata': instruction.metadata,
        'created_at': instruction.created_at.isoformat(),
        'updated_at': instruction.updated_at.isoformat()
    })

@admin_bp.route('/ai-instructions', methods=['POST'])
@login_required
@admin_required
def create_ai_instruction():
    """Create new AI instruction"""
    from models import db, cache
    from ai_instructions import AIInstruction
    
    data = request.get_json()
    
    # Validate required fields
    if not data.get('name') or not data.get('instruction_type') or not data.get('content'):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Check if name already exists
    if AIInstruction.query.filter_by(name=data['name']).first():
        return jsonify({'error': 'Instruction with this name already exists'}), 400
    
    try:
        instruction = AIInstruction(
            name=data['name'],
            instruction_type=data['instruction_type'],
            content=data['content'],
            priority=data.get('priority', 1),
            active=data.get('active', True),
            conditions=data.get('conditions', {}),
            metadata=data.get('metadata', {}),
            created_by=str(current_user.id)
        )
        
        db.session.add(instruction)
        db.session.commit()
        
        # Clear cache
        cache.delete("ai_instructions:*")
        
        # Log action
        log_admin_action(f"Created AI instruction: {data['name']}", {
            'instruction_id': instruction.id,
            'type': data['instruction_type']
        })
        
        return jsonify({'success': True, 'id': instruction.id})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/ai-instructions/<int:instruction_id>', methods=['PUT'])
@login_required
@admin_required
def update_ai_instruction(instruction_id):
    """Update AI instruction"""
    from models import db, cache
    from ai_instructions import AIInstruction
    
    instruction = AIInstruction.query.get_or_404(instruction_id)
    data = request.get_json()
    
    # Check if changing name to one that already exists
    if data.get('name') != instruction.name:
        if AIInstruction.query.filter_by(name=data['name']).first():
            return jsonify({'error': 'Instruction with this name already exists'}), 400
    
    try:
        instruction.name = data.get('name', instruction.name)
        instruction.instruction_type = data.get('instruction_type', instruction.instruction_type)
        instruction.content = data.get('content', instruction.content)
        instruction.priority = data.get('priority', instruction.priority)
        instruction.active = data.get('active', instruction.active)
        instruction.conditions = data.get('conditions', instruction.conditions)
        instruction.metadata = data.get('metadata', instruction.metadata)
        instruction.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        # Clear cache
        cache.delete("ai_instructions:*")
        
        # Log action
        log_admin_action(f"Updated AI instruction: {instruction.name}", {
            'instruction_id': instruction.id
        })
        
        return jsonify({'success': True})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/ai-instructions/<int:instruction_id>/toggle', methods=['POST'])
@login_required
@admin_required
def toggle_ai_instruction(instruction_id):
    """Toggle AI instruction active status"""
    from models import db, cache
    from ai_instructions import AIInstruction
    
    instruction = AIInstruction.query.get_or_404(instruction_id)
    
    instruction.active = not instruction.active
    db.session.commit()
    
    # Clear cache
    cache.delete("ai_instructions:*")
    
    # Log action
    log_admin_action(
        f"{'Activated' if instruction.active else 'Deactivated'} AI instruction: {instruction.name}",
        {'instruction_id': instruction.id}
    )
    
    return jsonify({'success': True, 'active': instruction.active})

@admin_bp.route('/ai-instructions/<int:instruction_id>', methods=['DELETE'])
@login_required
@admin_required
def delete_ai_instruction(instruction_id):
    """Delete AI instruction"""
    from models import db, cache
    from ai_instructions import AIInstruction
    
    instruction = AIInstruction.query.get_or_404(instruction_id)
    
    # Prevent deletion of default instructions
    if instruction.metadata and instruction.metadata.get('is_default'):
        return jsonify({'error': 'Cannot delete default instructions'}), 400
    
    name = instruction.name
    db.session.delete(instruction)
    db.session.commit()
    
    # Clear cache
    cache.delete("ai_instructions:*")
    
    # Log action
    log_admin_action(f"Deleted AI instruction: {name}", {
        'instruction_id': instruction_id
    })
    
    return jsonify({'success': True})

@admin_bp.route('/ai-instructions/export')
@login_required
@admin_required
def export_ai_instructions():
    """Export all AI instructions"""
    from models import db, cache
    from ai_instructions import AIInstructionManager
    
    manager = AIInstructionManager(db, cache)
    export_data = manager.export_instructions()
    
    # Log action
    log_admin_action("Exported AI instructions", {
        'count': len(export_data['instructions'])
    })
    
    return jsonify(export_data)

@admin_bp.route('/ai-instructions/import', methods=['POST'])
@login_required
@admin_required
def import_ai_instructions():
    """Import AI instructions"""
    from models import db, cache
    from ai_instructions import AIInstructionManager
    
    data = request.get_json()
    
    if not data or 'instructions' not in data:
        return jsonify({'error': 'Invalid import data'}), 400
    
    try:
        manager = AIInstructionManager(db, cache)
        count = manager.import_instructions(data)
        
        # Log action
        log_admin_action("Imported AI instructions", {
            'count': count
        })
        
        return jsonify({'success': True, 'count': count})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/ai-instructions/initialize-defaults', methods=['POST'])
@login_required
@admin_required
def initialize_default_instructions():
    """Initialize default AI instructions"""
    from models import db, cache
    from ai_instructions import AIInstructionManager
    
    try:
        manager = AIInstructionManager(db, cache)
        manager.load_default_instructions_to_db()
        
        # Log action
        log_admin_action("Initialized default AI instructions")
        
        return jsonify({'success': True})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500