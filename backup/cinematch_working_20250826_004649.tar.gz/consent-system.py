# consent_system.py - Consent management and privacy disclosure

from flask import Blueprint, render_template, request, jsonify, session, make_response
from datetime import datetime, timedelta
import json
import hashlib

consent_bp = Blueprint('consent', __name__)

class ConsentManager:
    """Manage user consent for data collection"""
    
    CONSENT_VERSION = "1.0"  # Update when privacy policy changes
    
    @staticmethod
    def has_valid_consent(session_id):
        """Check if user has given valid consent"""
        from app import redis_client
        
        consent_key = f"consent:{session_id}"
        consent_data = redis_client.get(consent_key)
        
        if not consent_data:
            return False
            
        consent = json.loads(consent_data)
        
        # Check if consent version matches current version
        if consent.get('version') != ConsentManager.CONSENT_VERSION:
            return False
            
        # Check if consent hasn't expired (1 year)
        consent_date = datetime.fromisoformat(consent.get('timestamp'))
        if datetime.utcnow() - consent_date > timedelta(days=365):
            return False
            
        return consent.get('accepted', False)
    
    @staticmethod
    def record_consent(session_id, accepted, ip_address):
        """Record user's consent decision"""
        from app import redis_client, db
        from models import ConsentLog
        
        consent_data = {
            'accepted': accepted,
            'version': ConsentManager.CONSENT_VERSION,
            'timestamp': datetime.utcnow().isoformat(),
            'ip_address': ip_address,
            'purposes': {
                'security_logging': accepted,
                'ip_recording': accepted,
                'guardrail_chat_retention': accepted
            }
        }
        
        # Store in Redis for quick access
        redis_client.setex(
            f"consent:{session_id}",
            timedelta(days=365),
            json.dumps(consent_data)
        )
        
        # Also store in database for compliance
        consent_log = ConsentLog(
            session_id=session_id,
            consent_given=accepted,
            consent_version=ConsentManager.CONSENT_VERSION,
            ip_address=ip_address,
            purposes=json.dumps(consent_data['purposes']),
            timestamp=datetime.utcnow()
        )
        
        db.session.add(consent_log)
        db.session.commit()
        
        return consent_data
    
    @staticmethod
    def get_consent_status(session_id):
        """Get detailed consent status"""
        from app import redis_client
        
        consent_key = f"consent:{session_id}"
        consent_data = redis_client.get(consent_key)
        
        if not consent_data:
            return None
            
        return json.loads(consent_data)

# Routes
@consent_bp.route('/api/consent/check')
def check_consent():
    """Check if current session has consent"""
    session_id = session.get('session_id')
    if not session_id:
        return jsonify({'has_consent': False})
    
    has_consent = ConsentManager.has_valid_consent(session_id)
    return jsonify({'has_consent': has_consent})

@consent_bp.route('/api/consent/accept', methods=['POST'])
def accept_consent():
    """Accept privacy consent"""
    session_id = session.get('session_id')
    if not session_id:
        return jsonify({'error': 'No session found'}), 400
    
    data = request.get_json()
    accepted = data.get('accepted', False)
    
    # Record consent
    consent_data = ConsentManager.record_consent(
        session_id,
        accepted,
        request.remote_addr
    )
    
    # Set consent cookie
    response = make_response(jsonify({
        'success': True,
        'consent': consent_data
    }))
    
    if accepted:
        # Set a cookie to remember consent
        response.set_cookie(
            'cinematch_consent',
            value='accepted',
            max_age=31536000,  # 1 year
            httponly=True,
            secure=True,
            samesite='Strict'
        )
    
    return response

@consent_bp.route('/api/consent/withdraw', methods=['POST'])
def withdraw_consent():
    """Withdraw consent"""
    session_id = session.get('session_id')
    if not session_id:
        return jsonify({'error': 'No session found'}), 400
    
    # Record withdrawal
    ConsentManager.record_consent(
        session_id,
        False,
        request.remote_addr
    )
    
    # Clear consent cookie
    response = make_response(jsonify({'success': True}))
    response.set_cookie('cinematch_consent', '', expires=0)
    
    return response

# Database Model for Consent
from sqlalchemy import Column, String, Boolean, DateTime, Text
from models import db

class ConsentLog(db.Model):
    __tablename__ = 'consent_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.String(64), nullable=False)
    consent_given = db.Column(db.Boolean, nullable=False)
    consent_version = db.Column(db.String(10), nullable=False)
    ip_address = db.Column(db.String(45))
    purposes = db.Column(db.Text)  # JSON
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Index for quick lookups
    __table_args__ = (
        db.Index('idx_consent_session', 'session_id', 'timestamp'),
    )

# Modified logging functions that respect consent
class PrivacyRespectingLogger:
    """Only log when consent is given and guardrails triggered"""
    
    @staticmethod
    def should_log_chat(session_id, guardrail_triggered=False):
        """Determine if chat should be logged"""
        if not ConsentManager.has_valid_consent(session_id):
            return False
            
        # Only log chats when guardrails are triggered
        return guardrail_triggered
    
    @staticmethod
    def log_security_event(session_id, event_type, details, severity='info'):
        """Log security events (always allowed for security)"""
        from app import db
        from models import SecurityLog
        
        # Check consent for IP recording
        has_consent = ConsentManager.has_valid_consent(session_id)
        
        log = SecurityLog(
            session_id=session_id,
            event_type=event_type,
            ip_address=request.remote_addr if has_consent else None,
            user_agent=request.headers.get('User-Agent', ''),
            details=json.dumps(details),
            severity=severity,
            timestamp=datetime.utcnow()
        )
        
        db.session.add(log)
        db.session.commit()
    
    @staticmethod
    def log_guardrail_triggered_chat(session_id, user_input, bot_response, guardrail_details):
        """Log chat only when guardrails are triggered"""
        from app import db
        from models import GuardrailChatLog
        
        if not ConsentManager.has_valid_consent(session_id):
            # Still log the security event, but without chat content
            PrivacyRespectingLogger.log_security_event(
                session_id,
                'guardrail_triggered',
                {'type': guardrail_details.get('reason')},
                severity=guardrail_details.get('severity', 'warning')
            )
            return
        
        # Hash the chat content for privacy
        input_hash = hashlib.sha256(user_input.encode()).hexdigest()
        
        log = GuardrailChatLog(
            session_id=session_id,
            input_hash=input_hash,
            user_input=user_input,  # Only stored when consent given
            bot_response=bot_response,
            guardrail_type=guardrail_details.get('reason'),
            severity=guardrail_details.get('severity'),
            action_taken=guardrail_details.get('action'),
            ip_address=request.remote_addr,
            timestamp=datetime.utcnow()
        )
        
        db.session.add(log)
        db.session.commit()

# Add to models.py
class GuardrailChatLog(db.Model):
    """Only stores chats when guardrails are triggered"""
    __tablename__ = 'guardrail_chat_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.String(64), nullable=False)
    input_hash = db.Column(db.String(64), nullable=False)
    user_input = db.Column(db.Text)  # Encrypted in production
    bot_response = db.Column(db.Text)
    guardrail_type = db.Column(db.String(50))
    severity = db.Column(db.String(20))
    action_taken = db.Column(db.String(20))
    ip_address = db.Column(db.String(45))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed = db.Column(db.Boolean, default=False)
    
    # Auto-delete after 30 days unless marked for review
    retention_days = 30