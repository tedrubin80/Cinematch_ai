# age_verification.py - Comprehensive age verification system for Cinematch

import os
import secrets
import hashlib
import logging
from datetime import datetime, timedelta
from functools import wraps

from flask import request, session, jsonify, render_template, redirect, url_for, flash, g
from flask_login import current_user
import geoip2.database
import geoip2.errors

from models import db, AgeVerification

logger = logging.getLogger(__name__)

class AgeVerificationManager:
    """Centralized age verification management with legal compliance"""
    
    # Age requirements by country (ISO 3166-1 alpha-2)
    COUNTRY_AGE_REQUIREMENTS = {
        'US': 18,  # United States
        'GB': 18,  # United Kingdom  
        'CA': 18,  # Canada
        'AU': 18,  # Australia
        'DE': 18,  # Germany
        'FR': 18,  # France
        'IT': 18,  # Italy
        'ES': 18,  # Spain
        'NL': 18,  # Netherlands
        'SE': 18,  # Sweden
        'NO': 18,  # Norway
        'DK': 18,  # Denmark
        'FI': 18,  # Finland
        'BE': 18,  # Belgium
        'CH': 18,  # Switzerland
        'AT': 18,  # Austria
        'JP': 18,  # Japan
        'KR': 18,  # South Korea
        'SG': 18,  # Singapore
        'BR': 18,  # Brazil
        'MX': 18,  # Mexico
        'AR': 18,  # Argentina
        'CL': 18,  # Chile
        'IN': 18,  # India
        'ZA': 18,  # South Africa
        # Default for all other countries
        'DEFAULT': 18
    }
    
    VERIFICATION_EXPIRY_HOURS = 720  # 30 days
    MAX_VERIFICATION_ATTEMPTS = 3
    
    @classmethod
    def get_client_info(cls):
        """Extract client information for verification"""
        return {
            'ip_address': request.remote_addr,
            'user_agent': request.headers.get('User-Agent', ''),
            'session_id': session.get('session_id', cls.generate_session_id()),
            'country_code': cls.get_country_from_ip(request.remote_addr),
            'timestamp': datetime.utcnow()
        }
    
    @classmethod
    def generate_session_id(cls):
        """Generate secure session ID"""
        session_id = secrets.token_urlsafe(32)
        session['session_id'] = session_id
        return session_id
    
    @classmethod
    def generate_verification_token(cls, session_id, age, ip_address):
        """Generate tamper-proof verification token"""
        secret = os.environ.get('SECRET_KEY', 'fallback-secret')
        data = f"{session_id}:{age}:{ip_address}:{secret}"
        return hashlib.sha256(data.encode()).hexdigest()
    
    @classmethod
    def verify_token(cls, token, session_id, age, ip_address):
        """Verify token authenticity"""
        expected_token = cls.generate_verification_token(session_id, age, ip_address)
        return secrets.compare_digest(token, expected_token)
    
    @classmethod
    def get_country_from_ip(cls, ip_address):
        """Get country code from IP address using GeoIP"""
        try:
            # Try to use GeoIP2 database if available
            geoip_db_path = os.environ.get('GEOIP_DATABASE_PATH', '/usr/share/GeoIP/GeoLite2-Country.mmdb')
            if os.path.exists(geoip_db_path):
                with geoip2.database.Reader(geoip_db_path) as reader:
                    response = reader.country(ip_address)
                    return response.country.iso_code
        except (geoip2.errors.AddressNotFoundError, FileNotFoundError, Exception) as e:
            logger.debug(f"GeoIP lookup failed: {e}")
        
        # Fallback: check for common local/development IPs
        if ip_address in ['127.0.0.1', '::1', 'localhost'] or ip_address.startswith('192.168.') or ip_address.startswith('10.'):
            return 'US'  # Default for development
        
        return 'DEFAULT'
    
    @classmethod
    def get_minimum_age(cls, country_code=None):
        """Get minimum age requirement for country"""
        if not country_code:
            country_code = 'DEFAULT'
        return cls.COUNTRY_AGE_REQUIREMENTS.get(country_code, cls.COUNTRY_AGE_REQUIREMENTS['DEFAULT'])
    
    @classmethod
    def create_verification(cls, age, method='self_declaration'):
        """Create new age verification record"""
        client_info = cls.get_client_info()
        
        try:
            # Check for existing verification
            existing = AgeVerification.query.filter_by(
                session_id=client_info['session_id']
            ).first()
            
            if existing:
                existing.attempts += 1
                if existing.attempts > cls.MAX_VERIFICATION_ATTEMPTS:
                    logger.warning(f"Too many verification attempts from session {client_info['session_id']}")
                    return None, "Too many verification attempts. Please try again later."
                
                existing.age = age
                existing.verification_method = method
                existing.verified_at = client_info['timestamp']
            else:
                existing = AgeVerification(
                    session_id=client_info['session_id'],
                    ip_address=client_info['ip_address'],
                    user_agent=client_info['user_agent'],
                    country_code=client_info['country_code'],
                    age=age,
                    verification_method=method,
                    verified_at=client_info['timestamp'],
                    attempts=1
                )
                db.session.add(existing)
            
            # Check age requirement
            min_age = cls.get_minimum_age(client_info['country_code'])
            if age < min_age:
                existing.is_verified = False
                existing.verification_token = None
                db.session.commit()
                
                logger.info(f"Age verification failed: {age} < {min_age} for country {client_info['country_code']}")
                return None, f"You must be at least {min_age} years old to use this service."
            
            # Generate verification token and set expiry
            verification_token = cls.generate_verification_token(
                client_info['session_id'], 
                age, 
                client_info['ip_address']
            )
            
            existing.is_verified = True
            existing.verification_token = verification_token
            existing.expires_at = client_info['timestamp'] + timedelta(hours=cls.VERIFICATION_EXPIRY_HOURS)
            
            db.session.commit()
            
            # Store verification in session
            session['age_verified'] = True
            session['age_verification_token'] = verification_token
            session['age_verification_expires'] = existing.expires_at.isoformat()
            
            logger.info(f"Age verification successful for session {client_info['session_id']}")
            return existing, "Age verification successful"
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating age verification: {e}")
            return None, "Verification failed. Please try again."
    
    @classmethod
    def check_verification(cls, require_valid=True):
        """Check if current session is age verified"""
        client_info = cls.get_client_info()
        
        # Check session first for performance
        if session.get('age_verified'):
            token = session.get('age_verification_token')
            expires_str = session.get('age_verification_expires')
            
            if token and expires_str:
                try:
                    expires_at = datetime.fromisoformat(expires_str)
                    if datetime.utcnow() < expires_at:
                        if not require_valid:
                            return True, None
                        
                        # Verify token authenticity for sensitive operations
                        verification = AgeVerification.query.filter_by(
                            session_id=client_info['session_id'],
                            verification_token=token
                        ).first()
                        
                        if verification and verification.is_valid:
                            return True, verification
                except (ValueError, TypeError):
                    pass
        
        # Fallback to database lookup
        verification = AgeVerification.query.filter_by(
            session_id=client_info['session_id']
        ).first()
        
        if verification and verification.is_valid:
            # Update session cache
            session['age_verified'] = True
            session['age_verification_token'] = verification.verification_token
            session['age_verification_expires'] = verification.expires_at.isoformat()
            return True, verification
        
        return False, None
    
    @classmethod
    def invalidate_verification(cls, session_id=None):
        """Invalidate age verification"""
        if not session_id:
            client_info = cls.get_client_info()
            session_id = client_info['session_id']
        
        try:
            verification = AgeVerification.query.filter_by(session_id=session_id).first()
            if verification:
                verification.is_verified = False
                verification.verification_token = None
                db.session.commit()
            
            # Clear session
            session.pop('age_verified', None)
            session.pop('age_verification_token', None)
            session.pop('age_verification_expires', None)
            
            logger.info(f"Age verification invalidated for session {session_id}")
            
        except Exception as e:
            logger.error(f"Error invalidating verification: {e}")
    
    @classmethod
    def get_verification_stats(cls, days=30):
        """Get verification statistics for admin dashboard"""
        try:
            from sqlalchemy import func
            
            since = datetime.utcnow() - timedelta(days=days)
            
            stats = db.session.query(
                func.count(AgeVerification.id).label('total_attempts'),
                func.sum(func.case([(AgeVerification.is_verified == True, 1)], else_=0)).label('successful_verifications'),
                func.sum(func.case([(AgeVerification.age < 18, 1)], else_=0)).label('underage_attempts'),
                func.count(func.distinct(AgeVerification.ip_address)).label('unique_ips'),
                func.count(func.distinct(AgeVerification.country_code)).label('unique_countries')
            ).filter(AgeVerification.verified_at >= since).first()
            
            # Country breakdown
            country_stats = db.session.query(
                AgeVerification.country_code,
                func.count(AgeVerification.id).label('count')
            ).filter(
                AgeVerification.verified_at >= since
            ).group_by(AgeVerification.country_code).all()
            
            return {
                'total_attempts': stats.total_attempts or 0,
                'successful_verifications': stats.successful_verifications or 0,
                'underage_attempts': stats.underage_attempts or 0,
                'unique_ips': stats.unique_ips or 0,
                'unique_countries': stats.unique_countries or 0,
                'success_rate': (stats.successful_verifications / max(stats.total_attempts, 1)) * 100,
                'country_breakdown': [
                    {'country': country.country_code, 'count': country.count}
                    for country in country_stats
                ],
                'period_days': days
            }
            
        except Exception as e:
            logger.error(f"Error getting verification stats: {e}")
            return None


# Decorator for age verification requirement
def age_verified_required(f):
    """Decorator to require age verification before accessing endpoint"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        verified, verification = AgeVerificationManager.check_verification()
        
        if not verified:
            # Store the intended destination
            session['age_verification_next'] = request.url
            
            if request.is_json:
                return jsonify({
                    'error': 'Age verification required',
                    'message': 'You must verify your age to access this content',
                    'verification_url': '/age-verification',
                    'required': True
                }), 403
            
            return redirect(url_for('age_verification.verify_age'))
        
        # Store verification info in g for use in the route
        g.age_verification = verification
        return f(*args, **kwargs)
    
    return decorated_function


def age_verified_api_required(f):
    """API-specific age verification decorator with JSON responses"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        verified, verification = AgeVerificationManager.check_verification()
        
        if not verified:
            return jsonify({
                'error': 'Age verification required',
                'code': 'AGE_VERIFICATION_REQUIRED',
                'message': 'You must be 18+ to access this service',
                'verification_url': '/api/age-verification',
                'required_age': AgeVerificationManager.get_minimum_age()
            }), 403
        
        g.age_verification = verification
        return f(*args, **kwargs)
    
    return decorated_function


# Flask Blueprint for age verification routes
from flask import Blueprint

age_verification_bp = Blueprint('age_verification', __name__)

@age_verification_bp.route('/age-verification', methods=['GET', 'POST'])
def verify_age():
    """Age verification page and form handler"""
    if request.method == 'GET':
        # Check if already verified
        verified, _ = AgeVerificationManager.check_verification(require_valid=False)
        if verified:
            next_url = session.pop('age_verification_next', url_for('index'))
            return redirect(next_url)
        
        # Get minimum age for user's location
        client_info = AgeVerificationManager.get_client_info()
        min_age = AgeVerificationManager.get_minimum_age(client_info['country_code'])
        
        return render_template('age_verification/verify.html', 
                             min_age=min_age,
                             country_code=client_info['country_code'])
    
    elif request.method == 'POST':
        try:
            # Get age from form
            age_input = request.form.get('age', '').strip()
            
            if not age_input.isdigit():
                flash('Please enter a valid age.', 'error')
                return render_template('age_verification/verify.html')
            
            age = int(age_input)
            
            # Validate age range
            if age < 13 or age > 120:
                flash('Please enter a valid age between 13 and 120.', 'error')
                return render_template('age_verification/verify.html')
            
            # Create verification
            verification, message = AgeVerificationManager.create_verification(age)
            
            if verification:
                flash('Age verification successful! Welcome to Cinematch.', 'success')
                
                # Redirect to intended destination
                next_url = session.pop('age_verification_next', url_for('index'))
                return redirect(next_url)
            else:
                flash(message, 'error')
                
                # For underage users, show specific message
                if 'must be at least' in message:
                    return render_template('age_verification/underage.html', message=message)
                
                return render_template('age_verification/verify.html')
                
        except Exception as e:
            logger.error(f"Age verification error: {e}")
            flash('An error occurred during verification. Please try again.', 'error')
            return render_template('age_verification/verify.html')


@age_verification_bp.route('/api/age-verification', methods=['POST'])
def api_verify_age():
    """API endpoint for age verification"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        age_input = data.get('age')
        if not isinstance(age_input, int) or age_input < 13 or age_input > 120:
            return jsonify({'error': 'Invalid age provided'}), 400
        
        verification, message = AgeVerificationManager.create_verification(age_input)
        
        if verification:
            return jsonify({
                'success': True,
                'message': message,
                'expires_at': verification.expires_at.isoformat(),
                'country_code': verification.country_code
            })
        else:
            return jsonify({
                'success': False,
                'error': message,
                'required_age': AgeVerificationManager.get_minimum_age()
            }), 403
            
    except Exception as e:
        logger.error(f"API age verification error: {e}")
        return jsonify({'error': 'Verification failed'}), 500


@age_verification_bp.route('/api/age-verification/status')
def api_verification_status():
    """Check current age verification status"""
    try:
        verified, verification = AgeVerificationManager.check_verification()
        
        if verified and verification:
            return jsonify({
                'verified': True,
                'expires_at': verification.expires_at.isoformat() if verification.expires_at else None,
                'country_code': verification.country_code,
                'method': verification.verification_method
            })
        else:
            client_info = AgeVerificationManager.get_client_info()
            return jsonify({
                'verified': False,
                'required_age': AgeVerificationManager.get_minimum_age(client_info['country_code']),
                'country_code': client_info['country_code']
            })
            
    except Exception as e:
        logger.error(f"Error checking verification status: {e}")
        return jsonify({'error': 'Status check failed'}), 500


@age_verification_bp.route('/age-verification/underage')
def underage_notice():
    """Page for users who are underage"""
    return render_template('age_verification/underage.html')


# Middleware for automatic age verification checking
def init_age_verification_middleware(app):
    """Initialize age verification middleware"""
    
    @app.before_request
    def check_age_verification():
        """Check age verification before each request"""
        # Skip verification for certain endpoints
        if request.endpoint in [
            'static',
            'age_verification.verify_age',
            'age_verification.api_verify_age', 
            'age_verification.api_verification_status',
            'age_verification.underage_notice',
            'health_check'
        ]:
            return
        
        # Skip for OPTIONS requests
        if request.method == 'OPTIONS':
            return
        
        # For API endpoints, check if verification is required
        if request.path.startswith('/api/') and request.endpoint != 'age_verification.api_verify_age':
            verified, _ = AgeVerificationManager.check_verification()
            if not verified:
                return jsonify({
                    'error': 'Age verification required',
                    'code': 'AGE_VERIFICATION_REQUIRED',
                    'verification_url': '/api/age-verification'
                }), 403
        
        # For regular web requests to protected content
        elif request.path not in ['/', '/age-verification', '/age-verification/underage']:
            verified, _ = AgeVerificationManager.check_verification()
            if not verified:
                session['age_verification_next'] = request.url
                return redirect(url_for('age_verification.verify_age'))
    
    logger.info("Age verification middleware initialized")


# Utility functions
def is_age_verified():
    """Simple utility to check if current session is age verified"""
    verified, _ = AgeVerificationManager.check_verification(require_valid=False)
    return verified


def get_verification_info():
    """Get current verification information"""
    verified, verification = AgeVerificationManager.check_verification()
    return verification if verified else None


def require_age_verification_for_content():
    """Context processor to add age verification info to templates"""
    return {
        'age_verified': is_age_verified(),
        'age_verification_info': get_verification_info()
    }