# app.py - Cinematch Flask Application
import os
import logging
from datetime import datetime
from flask import Flask, render_template, jsonify, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_required, current_user
from flask_migrate import Migrate
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix
from config import config
import redis
from celery import Celery

# Initialize extensions
migrate = Migrate()
login_manager = LoginManager()
limiter = Limiter(key_func=get_remote_address)

def create_celery_app(app=None):
    """Create Celery application"""
    app = app or create_app()
    celery = Celery(
        app.import_name,
        broker=app.config.get('REDIS_URL', 'redis://localhost:6379/0'),
        backend=app.config.get('REDIS_URL', 'redis://localhost:6379/0')
    )
    celery.conf.update(app.config)
    
    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)
    
    celery.Task = ContextTask
    return celery

def create_app(config_name=None):
    """Application factory pattern"""
    app = Flask(__name__)
    
    # Load configuration
    config_name = config_name or os.environ.get('FLASK_ENV', 'production')
    app.config.from_object(config[config_name])
    
    # Security: Handle proxy headers correctly
    if app.config.get('FORCE_HTTPS'):
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)
    
    # Import db from models and initialize extensions with app
    from models import db
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    limiter.init_app(app)
    
    # Configure CORS
    CORS(app, 
         origins=app.config.get('CORS_ORIGINS', ['*']),
         supports_credentials=True)
    
    # Configure login manager
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.session_protection = 'strong'
    
    # Set up logging
    setup_logging(app)
    
    # Register error handlers
    register_error_handlers(app)
    
    # Register blueprints
    register_blueprints(app)
    
    # Register CLI commands
    register_cli_commands(app)
    
    # Add security headers
    @app.after_request
    def add_security_headers(response):
        if app.config.get('FLASK_ENV') == 'production':
            headers = app.config.get('SECURITY_HEADERS', {})
            for header, value in headers.items():
                response.headers[header] = value
        
        # Add cache-busting headers for HTML pages to prevent caching issues
        if response.content_type and 'text/html' in response.content_type:
            response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate, max-age=0'
            response.headers['Pragma'] = 'no-cache'
            response.headers['Expires'] = '0'
        
        return response
    
    # Health check endpoint
    @app.route('/health')
    @limiter.exempt
    def health_check():
        """Health check endpoint for monitoring"""
        try:
            # Check database connection
            from sqlalchemy import text
            from models import db
            db.session.execute(text('SELECT 1'))
            db_status = 'healthy'
        except Exception as e:
            db_status = f'unhealthy: {str(e)}'
        
        # Check Redis connection
        try:
            redis_client = redis.from_url(app.config.get('REDIS_URL', 'redis://localhost:6379/0'))
            redis_client.ping()
            redis_status = 'healthy'
        except Exception as e:
            redis_status = f'unhealthy: {str(e)}'
        
        health_status = {
            'status': 'healthy' if db_status == 'healthy' and redis_status == 'healthy' else 'unhealthy',
            'timestamp': datetime.utcnow().isoformat(),
            'services': {
                'database': db_status,
                'redis': redis_status
            }
        }
        
        status_code = 200 if health_status['status'] == 'healthy' else 503
        return jsonify(health_status), status_code
    
    # Main route
    @app.route('/')
    def index():
        """Main application page"""
        if app.config.get('MAINTENANCE_MODE'):
            return render_template('maintenance.html'), 503
        return render_template('index.html')
    
    return app

def setup_logging(app):
    """Configure application logging"""
    if not app.debug and not app.testing:
        # Create logs directory if it doesn't exist
        if not os.path.exists('logs'):
            os.makedirs('logs')
        
        # Set up file handler
        file_handler = logging.handlers.RotatingFileHandler(
            'logs/cinematch.log',
            maxBytes=10485760,  # 10MB
            backupCount=10
        )
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
        ))
        
        # Set logging level
        log_level = getattr(logging, app.config.get('LOG_LEVEL', 'INFO'))
        file_handler.setLevel(log_level)
        app.logger.addHandler(file_handler)
        app.logger.setLevel(log_level)
        app.logger.info('Cinematch startup')

def register_error_handlers(app):
    """Register error handlers"""
    
    @app.errorhandler(404)
    def not_found_error(error):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Resource not found'}), 404
        return render_template('errors/404.html'), 404
    
    @app.errorhandler(403)
    def forbidden_error(error):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Forbidden'}), 403
        return render_template('errors/403.html'), 403
    
    @app.errorhandler(500)
    def internal_error(error):
        from models import db
        db.session.rollback()
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Internal server error'}), 500
        return render_template('errors/500.html'), 500
    
    @app.errorhandler(429)
    def ratelimit_handler(error):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Rate limit exceeded', 'message': str(error.description)}), 429
        return render_template('errors/429.html'), 429

def register_blueprints(app):
    """Register application blueprints"""
    # Import blueprints
    from auth import auth_bp
    from admin_routes import admin_bp
    from admin_routes_extended import admin_extended_bp
    from admin_api_management import api_mgmt_bp
    from seo_routes import seo_bp
    
    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/auth')
    
    # Admin routes with secret path
    admin_path = app.config.get('ADMIN_SECRET_PATH', 'admin')
    app.register_blueprint(admin_bp, url_prefix=f'/{admin_path}')
    app.register_blueprint(admin_extended_bp, url_prefix=f'/{admin_path}/extended')
    app.register_blueprint(api_mgmt_bp, url_prefix=f'/{admin_path}')
    
    # SEO routes
    app.register_blueprint(seo_bp)
    
    # Initialize safety systems (this will register safety blueprint)
    try:
        from safety_integration import integrate_safety_systems
        integrate_safety_systems(app)
        app.logger.info("Safety systems integrated successfully")
    except ImportError as e:
        app.logger.warning(f"Safety integration not available: {e}")
    except Exception as e:
        app.logger.error(f"Failed to integrate safety systems: {e}")
        # Don't fail app startup if safety systems fail to load
    
    # API routes
    @app.route('/api/chat', methods=['POST'])
    @login_required
    @limiter.limit("30 per minute")
    def chat_api():
        """Main chat API endpoint"""
        from movie_agent import MovieAgent
        
        data = request.get_json()
        user_input = data.get('message', '')
        temperature = data.get('temperature', 0.7)
        top_k = data.get('top_k', 20)
        
        if not user_input:
            return jsonify({'error': 'Message is required'}), 400
        
        try:
            # Initialize movie agent
            agent = MovieAgent()
            
            # Get response
            response = agent.get_recommendation(
                user_input=user_input,
                temperature=temperature,
                top_k=top_k,
                session_id=request.headers.get('X-Session-ID')
            )
            
            return jsonify({
                'response': response,
                'timestamp': datetime.utcnow().isoformat()
            })
            
        except Exception as e:
            app.logger.error(f"Chat API error: {str(e)}")
            return jsonify({'error': 'Failed to process request'}), 500

def register_cli_commands(app):
    """Register CLI commands"""
    
    @app.cli.command()
    def init_db():
        """Initialize the database"""
        from models import db, User, Session, APIKey, ContentKeyword
        db.create_all()
        print("Database initialized!")
    
    @app.cli.command()
    def create_admin():
        """Create admin user"""
        from models import User, db
        import getpass
        
        username = input("Admin username: ")
        email = input("Admin email: ")
        password = getpass.getpass("Admin password: ")
        
        admin = User(
            username=username,
            email=email,
            is_admin=True
        )
        admin.set_password(password)
        
        db.session.add(admin)
        db.session.commit()
        print(f"Admin user {username} created successfully!")
    
    @app.cli.command()
    def load_default_keywords():
        """Load default content filtering keywords"""
        from models import ContentKeyword, db
        
        # Default keywords for content filtering
        keywords = [
            ('mature', 'violence', 1.0),
            ('mature', 'gore', 1.5),
            ('mature', 'horror', 0.8),
            ('restricted', 'explicit', 2.0),
            ('restricted', 'adult', 2.0),
            ('family', 'animated', -1.0),
            ('family', 'disney', -1.0),
            ('family', 'pixar', -1.0),
        ]
        
        for category, keyword, weight in keywords:
            kw = ContentKeyword(
                category=category,
                keyword=keyword,
                weight=weight
            )
            db.session.add(kw)
        
        db.session.commit()
        print("Default keywords loaded!")

# Create application instance
app = create_app()
celery = create_celery_app(app)

# Import models to ensure they're registered
with app.app_context():
    from models import User, Session, APIKey, ContentKeyword, MovieDocument, ChatLog

@login_manager.user_loader
def load_user(user_id):
    """Load user for Flask-Login"""
    from models import User
    return User.query.get(user_id)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)