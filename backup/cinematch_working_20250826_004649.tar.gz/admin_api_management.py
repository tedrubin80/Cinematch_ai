# admin_api_management.py - Secure API Key Management Backend

from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash
from flask_login import login_required, current_user
from datetime import datetime
import os
import re
from cryptography.fernet import Fernet
import json
import secrets
import requests

# Import decorators and models
from auth import admin_required

api_mgmt_bp = Blueprint('api_management', __name__, url_prefix='/admin/api')

# Encryption key for API keys (from .env)
ENCRYPTION_KEY = os.environ.get('ENCRYPTION_KEY')
if ENCRYPTION_KEY:
    fernet = Fernet(ENCRYPTION_KEY.encode())
else:
    raise ValueError("ENCRYPTION_KEY not found in environment variables")

# API Key validation patterns
API_PATTERNS = {
    'openai': r'^sk-[a-zA-Z0-9\-]{20,}$',
    'anthropic': r'^sk-ant-api03-[a-zA-Z0-9\-_]{50,}$',
    'google': r'^[a-zA-Z0-9_\-]{39}$',
    'llm_service': r'^LLM\|[0-9]{13}\|[a-zA-Z0-9_\-]{20,}$'
}

def encrypt_api_key(api_key):
    """Encrypt API key for secure storage"""
    return fernet.encrypt(api_key.encode()).decode()

def decrypt_api_key(encrypted_key):
    """Decrypt API key for usage"""
    return fernet.decrypt(encrypted_key.encode()).decode()

def validate_api_key_format(provider, api_key):
    """Validate API key format based on provider"""
    pattern = API_PATTERNS.get(provider.lower())
    if not pattern:
        return False
    return bool(re.match(pattern, api_key))

def test_api_key(provider, api_key):
    """Test API key functionality"""
    try:
        if provider.lower() == 'openai':
            headers = {'Authorization': f'Bearer {api_key}'}
            response = requests.get('https://api.openai.com/v1/models', headers=headers, timeout=10)
            return response.status_code == 200
            
        elif provider.lower() == 'anthropic':
            headers = {'x-api-key': api_key, 'Content-Type': 'application/json'}
            data = {'model': 'claude-3-haiku-20240307', 'max_tokens': 1, 'messages': [{'role': 'user', 'content': 'Hi'}]}
            response = requests.post('https://api.anthropic.com/v1/messages', headers=headers, json=data, timeout=10)
            return response.status_code in [200, 400]  # 400 is OK, means API is working but request format issue
            
        elif provider.lower() == 'google':
            response = requests.get(f'https://generativelanguage.googleapis.com/v1/models?key={api_key}', timeout=10)
            return response.status_code == 200
            
        else:
            return True  # Custom APIs, assume valid if format is correct
            
    except Exception as e:
        return False

@api_mgmt_bp.route('/')
@login_required
@admin_required
def api_dashboard():
    """API Management Dashboard"""
    # Get current API keys from .env (masked for display)
    env_file_path = '/var/www/cinematch/.env'
    api_keys = {}
    
    try:
        with open(env_file_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line.startswith('OPENAI_API_KEY='):
                    key = line.split('=', 1)[1]
                    api_keys['openai'] = {'key': mask_api_key(key), 'status': 'active' if key else 'missing'}
                elif line.startswith('ANTHROPIC_API_KEY='):
                    key = line.split('=', 1)[1]
                    api_keys['anthropic'] = {'key': mask_api_key(key), 'status': 'active' if key else 'missing'}
                elif line.startswith('GOOGLE_API_KEY='):
                    key = line.split('=', 1)[1]
                    api_keys['google'] = {'key': mask_api_key(key), 'status': 'active' if key else 'missing'}
                elif line.startswith('LLM_SERVICE_KEY='):
                    key = line.split('=', 1)[1]
                    api_keys['llm_service'] = {'key': mask_api_key(key), 'status': 'active' if key else 'missing'}
    except Exception as e:
        flash(f'Error reading API keys: {str(e)}', 'error')
    
    return render_template('admin/api_management.html', api_keys=api_keys)

def mask_api_key(api_key):
    """Mask API key for display"""
    if not api_key or len(api_key) < 10:
        return 'Not Set'
    return api_key[:6] + '*' * (len(api_key) - 10) + api_key[-4:]

@api_mgmt_bp.route('/update', methods=['POST'])
@login_required
@admin_required
def update_api_key():
    """Update API key securely"""
    try:
        provider = request.form.get('provider')
        new_api_key = request.form.get('api_key', '').strip()
        
        if not provider or not new_api_key:
            return jsonify({'success': False, 'error': 'Missing provider or API key'})
        
        # Validate API key format
        if not validate_api_key_format(provider, new_api_key):
            return jsonify({'success': False, 'error': 'Invalid API key format for this provider'})
        
        # Test API key functionality
        test_result = test_api_key(provider, new_api_key)
        if not test_result:
            return jsonify({'success': False, 'error': 'API key test failed - key may be invalid'})
        
        # Update .env file
        env_file_path = '/var/www/cinematch/.env'
        env_var_name = {
            'openai': 'OPENAI_API_KEY',
            'anthropic': 'ANTHROPIC_API_KEY',
            'google': 'GOOGLE_API_KEY',
            'llm_service': 'LLM_SERVICE_KEY'
        }.get(provider)
        
        if not env_var_name:
            return jsonify({'success': False, 'error': 'Unknown provider'})
        
        # Read current .env file
        env_lines = []
        with open(env_file_path, 'r') as f:
            env_lines = f.readlines()
        
        # Update or add the API key
        updated = False
        for i, line in enumerate(env_lines):
            if line.strip().startswith(f'{env_var_name}='):
                env_lines[i] = f'{env_var_name}={new_api_key}\n'
                updated = True
                break
        
        if not updated:
            env_lines.append(f'{env_var_name}={new_api_key}\n')
        
        # Write back to .env file
        with open(env_file_path, 'w') as f:
            f.writelines(env_lines)
        
        # Log the change
        from app import db
        try:
            from models import ActivityLog
        except ImportError:
            # ActivityLog model not available, skip logging
            ActivityLog = None
        
        if ActivityLog:
            log_entry = ActivityLog(
                user_id=current_user.id,
                action='api_key_update',
                details=f'Updated {provider} API key',
                ip_address=request.remote_addr,
                timestamp=datetime.utcnow()
            )
            db.session.add(log_entry)
            db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': f'{provider.title()} API key updated successfully',
            'masked_key': mask_api_key(new_api_key)
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': f'Server error: {str(e)}'})

@api_mgmt_bp.route('/test/<provider>', methods=['POST'])
@login_required
@admin_required
def test_api_key_endpoint(provider):
    """Test existing API key"""
    try:
        # Get API key from .env
        env_file_path = '/var/www/cinematch/.env'
        env_var_name = {
            'openai': 'OPENAI_API_KEY',
            'anthropic': 'ANTHROPIC_API_KEY',
            'google': 'GOOGLE_API_KEY',
            'llm_service': 'LLM_SERVICE_KEY'
        }.get(provider)
        
        if not env_var_name:
            return jsonify({'success': False, 'error': 'Unknown provider'})
        
        api_key = None
        with open(env_file_path, 'r') as f:
            for line in f:
                if line.strip().startswith(f'{env_var_name}='):
                    api_key = line.split('=', 1)[1].strip()
                    break
        
        if not api_key:
            return jsonify({'success': False, 'error': 'API key not found'})
        
        # Test the API key
        test_result = test_api_key(provider, api_key)
        
        return jsonify({
            'success': test_result,
            'message': 'API key is working!' if test_result else 'API key test failed'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': f'Test error: {str(e)}'})

@api_mgmt_bp.route('/generate-secure-password')
@login_required
@admin_required
def generate_secure_password():
    """Generate a secure password for admin use"""
    password = secrets.token_urlsafe(16)
    return jsonify({'password': password})

@api_mgmt_bp.route('/system-status')
@login_required
@admin_required
def system_status():
    """Get system status for monitoring"""
    try:
        import psutil
        import subprocess
        
        # Check service status
        services = ['postgresql', 'redis-server', 'nginx']
        service_status = {}
        
        for service in services:
            try:
                result = subprocess.run(['systemctl', 'is-active', service], 
                                      capture_output=True, text=True)
                service_status[service] = result.stdout.strip() == 'active'
            except:
                service_status[service] = False
        
        # System metrics
        system_info = {
            'cpu_percent': psutil.cpu_percent(interval=1),
            'memory_percent': psutil.virtual_memory().percent,
            'disk_percent': psutil.disk_usage('/').percent,
            'load_average': os.getloadavg()[0] if hasattr(os, 'getloadavg') else 0
        }
        
        return jsonify({
            'success': True,
            'services': service_status,
            'system': system_info,
            'timestamp': datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': f'Status check error: {str(e)}'})

# Note: ActivityLog model should be added to models.py if logging is desired