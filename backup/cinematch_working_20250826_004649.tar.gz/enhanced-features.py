# enhanced_features.py - Help system and theme management

from flask import Blueprint, render_template, jsonify, request, session, current_app
from datetime import datetime
from functools import wraps

# Help system blueprint
help_bp = Blueprint('help', __name__, url_prefix='/help')

@help_bp.route('/')
def help_center():
    """Main help center page"""
    return render_template('help/index.html')

@help_bp.route('/top-k')
def top_k_guide():
    """Top-K parameter guide"""
    return render_template('help/top_k.html')

@help_bp.route('/temperature')
def temperature_guide():
    """Temperature parameter guide"""
    return render_template('help/temperature.html')

@help_bp.route('/intent')
def intent_guide():
    """Intent understanding guide"""
    return render_template('help/intent.html')

@help_bp.route('/langchain')
def langchain_guide():
    """LangChain integration guide"""
    return render_template('help/langchain.html')

@help_bp.route('/api/search')
def search_help():
    """Search help articles"""
    query = request.args.get('q', '').lower()
    
    # Simple help article database
    articles = [
        {
            'id': 'top-k',
            'title': 'Understanding Top-K Parameter',
            'category': 'Parameters',
            'tags': ['top-k', 'diversity', 'creativity'],
            'description': 'Learn how Top-K affects response diversity'
        },
        {
            'id': 'temperature',
            'title': 'Temperature Settings',
            'category': 'Parameters',
            'tags': ['temperature', 'randomness', 'predictability'],
            'description': 'Control response randomness with temperature'
        },
        {
            'id': 'intent',
            'title': 'How AI Understands Your Requests',
            'category': 'AI Behavior',
            'tags': ['intent', 'understanding', 'nlp'],
            'description': 'Learn how the AI interprets your movie requests'
        },
        {
            'id': 'langchain',
            'title': 'LangChain Integration',
            'category': 'Technical',
            'tags': ['langchain', 'llm', 'orchestration'],
            'description': 'Advanced AI orchestration with LangChain'
        },
        {
            'id': 'best-practices',
            'title': 'Best Practices for Movie Recommendations',
            'category': 'Tips',
            'tags': ['tips', 'best practices', 'recommendations'],
            'description': 'Get better movie recommendations with these tips'
        }
    ]
    
    # Filter articles based on query
    if query:
        results = []
        for article in articles:
            if (query in article['title'].lower() or 
                query in article['description'].lower() or
                any(query in tag for tag in article['tags'])):
                results.append(article)
    else:
        results = articles
    
    return jsonify({'results': results})

@help_bp.route('/api/tutorial-progress', methods=['GET', 'POST'])
def tutorial_progress():
    """Track user's tutorial progress"""
    if request.method == 'GET':
        progress = session.get('tutorial_progress', {
            'completed_steps': [],
            'current_step': 'welcome'
        })
        return jsonify(progress)
    
    elif request.method == 'POST':
        data = request.get_json()
        step = data.get('step')
        
        if 'tutorial_progress' not in session:
            session['tutorial_progress'] = {
                'completed_steps': [],
                'current_step': 'welcome'
            }
        
        if step not in session['tutorial_progress']['completed_steps']:
            session['tutorial_progress']['completed_steps'].append(step)
        
        session['tutorial_progress']['current_step'] = data.get('next_step', step)
        session.modified = True
        
        return jsonify({'success': True})

# Theme system blueprint
theme_bp = Blueprint('theme', __name__, url_prefix='/theme')

# Available themes
THEMES = {
    'dark_modern': {
        'name': 'Dark Modern',
        'description': 'Sleek dark theme with red accents',
        'css_variables': {
            '--background': '#0f0f0f',
            '--surface': '#1a1a1a',
            '--surface-light': '#2a2a2a',
            '--text': '#ffffff',
            '--text-muted': '#a0a0a0',
            '--accent': '#ef4444',
            '--accent-hover': '#dc2626',
            '--border': '#333333',
            '--success': '#10b981',
            '--warning': '#f59e0b',
            '--error': '#ef4444'
        }
    },
    'light_clean': {
        'name': 'Light Clean',
        'description': 'Clean light theme for daytime use',
        'css_variables': {
            '--background': '#ffffff',
            '--surface': '#f9fafb',
            '--surface-light': '#f3f4f6',
            '--text': '#111827',
            '--text-muted': '#6b7280',
            '--accent': '#dc2626',
            '--accent-hover': '#b91c1c',
            '--border': '#e5e7eb',
            '--success': '#059669',
            '--warning': '#d97706',
            '--error': '#dc2626'
        }
    },
    'cyberpunk': {
        'name': 'Cyberpunk',
        'description': 'Neon-infused futuristic theme',
        'css_variables': {
            '--background': '#0a0a0a',
            '--surface': '#1a0f1f',
            '--surface-light': '#2a1f3f',
            '--text': '#e0f2fe',
            '--text-muted': '#94a3b8',
            '--accent': '#f0abfc',
            '--accent-hover': '#e879f9',
            '--border': '#4c1d95',
            '--success': '#34d399',
            '--warning': '#fbbf24',
            '--error': '#f87171'
        }
    },
    'forest': {
        'name': 'Forest',
        'description': 'Natural green theme',
        'css_variables': {
            '--background': '#0f1610',
            '--surface': '#1a2e1c',
            '--surface-light': '#2a4a2e',
            '--text': '#ecfdf5',
            '--text-muted': '#86efac',
            '--accent': '#4ade80',
            '--accent-hover': '#22c55e',
            '--border': '#166534',
            '--success': '#84cc16',
            '--warning': '#fbbf24',
            '--error': '#f87171'
        }
    },
    'ocean': {
        'name': 'Ocean',
        'description': 'Deep blue ocean theme',
        'css_variables': {
            '--background': '#0c1221',
            '--surface': '#1e293b',
            '--surface-light': '#334155',
            '--text': '#f1f5f9',
            '--text-muted': '#94a3b8',
            '--accent': '#38bdf8',
            '--accent-hover': '#0ea5e9',
            '--border': '#475569',
            '--success': '#34d399',
            '--warning': '#fbbf24',
            '--error': '#fb7185'
        }
    }
}

@theme_bp.route('/list')
def list_themes():
    """Get all available themes"""
    themes_list = []
    current_theme = session.get('theme', 'dark_modern')
    
    for theme_id, theme_data in THEMES.items():
        themes_list.append({
            'id': theme_id,
            'name': theme_data['name'],
            'description': theme_data['description'],
            'current': theme_id == current_theme
        })
    
    return jsonify({'themes': themes_list})

@theme_bp.route('/current')
def get_current_theme():
    """Get current theme settings"""
    theme_id = session.get('theme', 'dark_modern')
    theme = THEMES.get(theme_id, THEMES['dark_modern'])
    
    return jsonify({
        'id': theme_id,
        'name': theme['name'],
        'variables': theme['css_variables']
    })

@theme_bp.route('/set', methods=['POST'])
def set_theme():
    """Set user's theme preference"""
    data = request.get_json()
    theme_id = data.get('theme_id')
    
    if theme_id not in THEMES:
        return jsonify({'error': 'Invalid theme ID'}), 400
    
    session['theme'] = theme_id
    session.permanent = True
    
    # If user is logged in, save preference to database
    from flask_login import current_user
    if current_user.is_authenticated:
        from app import db
        from models import UserPreference
        
        pref = UserPreference.query.filter_by(user_id=current_user.id).first()
        if not pref:
            pref = UserPreference(user_id=current_user.id)
            db.session.add(pref)
        
        pref.theme = theme_id
        db.session.commit()
    
    return jsonify({
        'success': True,
        'theme': theme_id,
        'message': f'Theme changed to {THEMES[theme_id]["name"]}'
    })

@theme_bp.route('/preview/<theme_id>')
def preview_theme(theme_id):
    """Preview a theme without saving"""
    if theme_id not in THEMES:
        return jsonify({'error': 'Invalid theme ID'}), 404
    
    theme = THEMES[theme_id]
    
    # Generate CSS for preview
    css = ':root {\n'
    for var, value in theme['css_variables'].items():
        css += f'    {var}: {value};\n'
    css += '}'
    
    return jsonify({
        'theme_id': theme_id,
        'name': theme['name'],
        'css': css
    })

# Context processor to inject theme CSS into all templates
def inject_theme_css():
    """Inject theme CSS variables into templates"""
    theme_id = session.get('theme', 'dark_modern')
    theme = THEMES.get(theme_id, THEMES['dark_modern'])
    
    css = ':root {\n'
    for var, value in theme['css_variables'].items():
        css += f'    {var}: {value};\n'
    css += '}'
    
    return {
        'theme': theme_id,
        'theme_css': css
    }

# Interactive demos for help system
@help_bp.route('/api/simulate-topk', methods=['POST'])
def simulate_topk():
    """Simulate Top-K parameter effects"""
    data = request.get_json()
    top_k = data.get('top_k', 10)
    prompt = data.get('prompt', '')
    
    # Simulated responses based on Top-K value
    if top_k < 10:
        response = {
            'text': 'Based on your interest in Inception, I recommend The Matrix.',
            'explanation': 'Low Top-K produces focused, predictable recommendations.'
        }
    elif top_k < 40:
        response = {
            'text': 'You might enjoy Paprika, The Prestige, or Coherence - all mind-bending films like Inception.',
            'explanation': 'Medium Top-K balances relevance with variety.'
        }
    else:
        response = {
            'text': 'Check out The Fall for stunning visuals, or Holy Motors for surreal storytelling!',
            'explanation': 'High Top-K creates more diverse, unexpected suggestions.'
        }
    
    return jsonify(response)

@help_bp.route('/api/simulate-temperature', methods=['POST'])
def simulate_temperature():
    """Simulate temperature parameter effects"""
    data = request.get_json()
    temperature = data.get('temperature', 0.7)
    prompt = data.get('prompt', '')
    
    # Simulated responses based on temperature
    if temperature < 0.3:
        response = {
            'text': 'I recommend Blade Runner 2049.',
            'variations': ['I recommend Blade Runner 2049.', 'I recommend Blade Runner 2049.'],
            'explanation': 'Low temperature = consistent, deterministic responses'
        }
    elif temperature < 0.8:
        response = {
            'text': 'You might enjoy Blade Runner 2049 - a visually stunning sci-fi sequel.',
            'variations': [
                'Check out Arrival for thoughtful sci-fi.',
                'Ex Machina offers a cerebral AI thriller experience.'
            ],
            'explanation': 'Medium temperature = natural variation while maintaining coherence'
        }
    else:
        response = {
            'text': 'Oh wow! Blade Runner 2049 - neon-drenched cyberpunk masterpiece!',
            'variations': [
                'Sci-fi? Let\'s talk Coherence - mind-bending dinner party!',
                'District 9! Aliens, action, apartheid allegories!'
            ],
            'explanation': 'High temperature = creative, diverse responses'
        }
    
    return jsonify(response)

# Register context processor
def register_context_processors(app):
    """Register context processors with the Flask app"""
    app.context_processor(inject_theme_css)

# Interactive tutorial system
@help_bp.route('/tutorial')
def interactive_tutorial():
    """Interactive tutorial for new users"""
    return render_template('help/tutorial.html')

@help_bp.route('/api/tips')
def get_tips():
    """Get contextual tips based on user activity"""
    context = request.args.get('context', 'general')
    
    tips = {
        'general': [
            'Try being specific about genres or moods',
            'Mention movies you\'ve enjoyed for better recommendations',
            'Use temperature settings to control response variety'
        ],
        'first_chat': [
            'Start with something like "I\'m in the mood for a thriller"',
            'Mention your favorite movies for personalized suggestions',
            'Don\'t forget to verify your age first!'
        ],
        'advanced': [
            'Adjust Top-K for more creative recommendations',
            'Use lower temperature for consistent results',
            'Try cross-validation mode for important queries'
        ]
    }
    
    return jsonify({
        'tips': tips.get(context, tips['general'])
    })

# Export functions for app initialization
__all__ = ['help_bp', 'theme_bp', 'register_context_processors', 'THEMES']