# backup.py - Automated backup script for Cinematch

import os
import sys
import boto3
import subprocess
from datetime import datetime, timedelta
import gzip
import shutil
import json
from pathlib import Path

class CinematchBackup:
    def __init__(self):
        self.backup_dir = Path("/app/backups")
        self.backup_dir.mkdir(exist_ok=True)
        
        # DigitalOcean Spaces configuration
        self.do_spaces_key = os.environ.get('DO_SPACES_KEY')
        self.do_spaces_secret = os.environ.get('DO_SPACES_SECRET')
        self.do_spaces_region = 'nyc3'
        self.do_spaces_endpoint = 'https://nyc3.digitaloceanspaces.com'
        self.do_spaces_bucket = os.environ.get('DO_SPACES_BUCKET', 'cinematch-backups')
        
        # Database configuration
        self.db_url = os.environ.get('DATABASE_URL')
        
        # Parse database URL
        if self.db_url:
            self._parse_db_url()
    
    def _parse_db_url(self):
        """Parse PostgreSQL URL"""
        # postgresql://user:pass@host:port/dbname
        from urllib.parse import urlparse
        
        result = urlparse(self.db_url)
        self.db_config = {
            'host': result.hostname,
            'port': result.port or 5432,
            'user': result.username,
            'password': result.password,
            'database': result.path[1:]  # Remove leading slash
        }
    
    def backup_database(self):
        """Backup PostgreSQL database"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_file = self.backup_dir / f"db_backup_{timestamp}.sql"
        compressed_file = self.backup_dir / f"db_backup_{timestamp}.sql.gz"
        
        print(f"Backing up database to {backup_file}")
        
        # Build pg_dump command
        env = os.environ.copy()
        env['PGPASSWORD'] = self.db_config['password']
        
        cmd = [
            'pg_dump',
            '-h', self.db_config['host'],
            '-p', str(self.db_config['port']),
            '-U', self.db_config['user'],
            '-d', self.db_config['database'],
            '--no-owner',
            '--no-acl',
            '-f', str(backup_file)
        ]
        
        try:
            subprocess.run(cmd, env=env, check=True, capture_output=True, text=True)
            print("Database backup completed")
            
            # Compress the backup
            print("Compressing backup...")
            with open(backup_file, 'rb') as f_in:
                with gzip.open(compressed_file, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            
            # Remove uncompressed file
            backup_file.unlink()
            
            return compressed_file
            
        except subprocess.CalledProcessError as e:
            print(f"Database backup failed: {e}")
            print(f"Error output: {e.stderr}")
            return None
    
    def backup_files(self):
        """Backup important files"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_file = self.backup_dir / f"files_backup_{timestamp}.tar.gz"
        
        print(f"Backing up files to {backup_file}")
        
        # Files to backup
        files_to_backup = [
            '.env',
            'config.py',
            'gunicorn.conf.py',
            'requirements.txt'
        ]
        
        # Create tar archive
        cmd = ['tar', '-czf', str(backup_file)] + files_to_backup
        
        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True)
            print("File backup completed")
            return backup_file
        except subprocess.CalledProcessError as e:
            print(f"File backup failed: {e}")
            return None
    
    def upload_to_spaces(self, file_path):
        """Upload backup to DigitalOcean Spaces"""
        if not all([self.do_spaces_key, self.do_spaces_secret]):
            print("DigitalOcean Spaces credentials not configured")
            return False
        
        print(f"Uploading {file_path} to Spaces...")
        
        # Initialize S3 client for DigitalOcean Spaces
        s3_client = boto3.client(
            's3',
            region_name=self.do_spaces_region,
            endpoint_url=self.do_spaces_endpoint,
            aws_access_key_id=self.do_spaces_key,
            aws_secret_access_key=self.do_spaces_secret
        )
        
        # Generate S3 key
        file_name = file_path.name
        s3_key = f"backups/{datetime.now().strftime('%Y/%m/%d')}/{file_name}"
        
        try:
            # Upload file
            s3_client.upload_file(
                str(file_path),
                self.do_spaces_bucket,
                s3_key,
                ExtraArgs={
                    'ACL': 'private',
                    'StorageClass': 'STANDARD_IA'  # Infrequent access for backups
                }
            )
            print(f"Upload successful: {s3_key}")
            return True
            
        except Exception as e:
            print(f"Upload failed: {e}")
            return False
    
    def cleanup_old_backups(self, days=7):
        """Remove local backups older than specified days"""
        print(f"Cleaning up backups older than {days} days...")
        
        cutoff_date = datetime.now() - timedelta(days=days)
        
        for backup_file in self.backup_dir.glob("*.gz"):
            # Get file modification time
            file_time = datetime.fromtimestamp(backup_file.stat().st_mtime)
            
            if file_time < cutoff_date:
                print(f"Removing old backup: {backup_file}")
                backup_file.unlink()
    
    def cleanup_remote_backups(self, days=30):
        """Remove remote backups older than specified days"""
        if not all([self.do_spaces_key, self.do_spaces_secret]):
            return
        
        print(f"Cleaning up remote backups older than {days} days...")
        
        s3_client = boto3.client(
            's3',
            region_name=self.do_spaces_region,
            endpoint_url=self.do_spaces_endpoint,
            aws_access_key_id=self.do_spaces_key,
            aws_secret_access_key=self.do_spaces_secret
        )
        
        cutoff_date = datetime.now() - timedelta(days=days)
        
        try:
            # List objects in backup folder
            paginator = s3_client.get_paginator('list_objects_v2')
            pages = paginator.paginate(
                Bucket=self.do_spaces_bucket,
                Prefix='backups/'
            )
            
            objects_to_delete = []
            
            for page in pages:
                if 'Contents' in page:
                    for obj in page['Contents']:
                        # Check if object is older than cutoff
                        if obj['LastModified'].replace(tzinfo=None) < cutoff_date:
                            objects_to_delete.append({'Key': obj['Key']})
            
            # Delete old objects
            if objects_to_delete:
                print(f"Deleting {len(objects_to_delete)} old remote backups...")
                s3_client.delete_objects(
                    Bucket=self.do_spaces_bucket,
                    Delete={'Objects': objects_to_delete}
                )
                
        except Exception as e:
            print(f"Remote cleanup failed: {e}")
    
    def create_backup_report(self, results):
        """Create a backup report"""
        report_file = self.backup_dir / f"backup_report_{datetime.now().strftime('%Y%m%d')}.json"
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'backups': results,
            'disk_usage': self._get_disk_usage(),
            'backup_sizes': self._get_backup_sizes()
        }
        
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        return report
    
    def _get_disk_usage(self):
        """Get disk usage statistics"""
        import shutil
        
        total, used, free = shutil.disk_usage("/")
        
        return {
            'total_gb': round(total / (1024**3), 2),
            'used_gb': round(used / (1024**3), 2),
            'free_gb': round(free / (1024**3), 2),
            'percent_used': round((used / total) * 100, 2)
        }
    
    def _get_backup_sizes(self):
        """Get sizes of all backups"""
        sizes = {}
        total_size = 0
        
        for backup_file in self.backup_dir.glob("*.gz"):
            size = backup_file.stat().st_size
            sizes[backup_file.name] = round(size / (1024**2), 2)  # MB
            total_size += size
        
        sizes['total_mb'] = round(total_size / (1024**2), 2)
        return sizes
    
    def run(self):
        """Run the complete backup process"""
        print(f"Starting Cinematch backup at {datetime.now()}")
        
        results = {
            'database': {'success': False},
            'files': {'success': False},
            'uploads': []
        }
        
        # Backup database
        db_backup = self.backup_database()
        if db_backup:
            results['database']['success'] = True
            results['database']['file'] = str(db_backup)
            results['database']['size_mb'] = round(db_backup.stat().st_size / (1024**2), 2)
            
            # Upload to Spaces
            if self.upload_to_spaces(db_backup):
                results['uploads'].append(str(db_backup))
        
        # Backup files
        files_backup = self.backup_files()
        if files_backup:
            results['files']['success'] = True
            results['files']['file'] = str(files_backup)
            results['files']['size_mb'] = round(files_backup.stat().st_size / (1024**2), 2)
            
            # Upload to Spaces
            if self.upload_to_spaces(files_backup):
                results['uploads'].append(str(files_backup))
        
        # Cleanup old backups
        self.cleanup_old_backups(days=7)
        self.cleanup_remote_backups(days=30)
        
        # Create report
        report = self.create_backup_report(results)
        
        print(f"Backup completed at {datetime.now()}")
        print(f"Report: {json.dumps(report, indent=2)}")
        
        # Return success if at least one backup succeeded
        return results['database']['success'] or results['files']['success']


if __name__ == "__main__":
    backup = CinematchBackup()
    success = backup.run()
    sys.exit(0 if success else 1)