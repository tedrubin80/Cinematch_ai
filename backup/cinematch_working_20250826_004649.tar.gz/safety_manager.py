# safety_manager.py - Age verification and safety management

from datetime import datetime, timedelta
from typing import Dict, Tuple, Optional
import hashlib
import json

class SafetyManager:
    """Comprehensive safety and age verification system"""
    
    @staticmethod
    def verify_age(session_id: str, age: int) -> Tuple[bool, str]:
        """Verify user age and update session"""
        from models import Session
        from app import db
        
        # Validate age input
        if not isinstance(age, int) or age < 1 or age > 150:
            return False, "Please enter a valid age."
        
        if age < 18:
            # Log attempted underage access (anonymized)
            SafetyManager._log_age_verification_attempt(session_id, age, False)
            return False, "This service is only available to users 18 and older. We appreciate your understanding."
        
        # Update session with age verification
        session = Session.query.get(session_id)
        if session:
            session.age_verified = True
            session.age_verified_at = datetime.utcnow()
            db.session.commit()
            
            # Log successful verification
            SafetyManager._log_age_verification_attempt(session_id, age, True)
            
            return True, "Age verified successfully. Welcome to Cinematch!"
        
        return False, "Session not found. Please refresh and try again."
    
    @staticmethod
    def check_session_safety(session_id: str) -> Dict:
        """Check if session is safe to continue"""
        from models import SafetyLog, Session
        from datetime import datetime, timedelta
        
        # Check if session exists
        session = Session.query.get(session_id)
        if not session:
            return {
                'safe': False,
                'reason': 'invalid_session',
                'message': 'Invalid session. Please refresh the page.'
            }
        
        # Check age verification
        if not session.age_verified:
            return {
                'safe': False,
                'reason': 'age_not_verified',
                'message': 'Age verification required.'
            }
        
        # Check if age verification is still valid (24 hours)
        if session.age_verified_at and datetime.utcnow() - session.age_verified_at > timedelta(hours=24):
            session.age_verified = False
            from app import db
            db.session.commit()
            return {
                'safe': False,
                'reason': 'age_verification_expired',
                'message': 'Age verification has expired. Please verify again.'
            }
        
        # Check recent violations
        recent_violations = SafetyLog.query.filter(
            SafetyLog.session_id == session_id,
            SafetyLog.timestamp >= datetime.utcnow() - timedelta(hours=1),
            SafetyLog.severity.in_(['high', 'critical']),
            SafetyLog.action == 'block'
        ).count()
        
        if recent_violations >= 3:
            return {
                'safe': False,
                'reason': 'too_many_violations',
                'message': 'Your session has been temporarily suspended due to policy violations. Please try again later.'
            }
        
        # Check for ban
        ban_status = SafetyManager._check_ban_status(session_id)
        if ban_status['banned']:
            return {
                'safe': False,
                'reason': 'banned',
                'message': ban_status['message']
            }
        
        return {
            'safe': True,
            'age_verified': True,
            'violations': recent_violations
        }
    
    @staticmethod
    def _check_ban_status(session_id: str) -> Dict:
        """Check if session or IP is banned"""
        from models import Session, SecurityLog
        from